# Chapter 12: Agent Orchestration with LangGraph

## Topic 2: Defining State, Nodes, and Edges for the Email Pipeline

---

### 1. Concept, Intuition, and Why It Exists

- Topic 1 introduced state, nodes, and edges conceptually and sketched a first version. This topic treats state schema design specifically as its own engineering discipline — directly analogous to Chapter 10 Topic 3's tool-schema design rigor, now applied to the shape of the data flowing through this project's entire pipeline rather than a single tool's arguments.
- The core question this topic answers: given everything this project's pipeline actually needs to track — the rule engine's verdict, MuRIL's prediction and confidence, the GenAI agent's full tool-use trace (Chapter 10's `validate_fd_reference`, `search_knowledge_base`, `lookup_product_catalog`, `check_sender_history`), and Chapter 11's memory lookups — what does a *complete, correct* state schema actually need to contain, and how should it be structured for correctness, debuggability, and maintainability?
- Why this deserves its own dedicated topic: a poorly-designed state schema is a subtle, compounding liability — missing fields force awkward workarounds later, overly-broad fields (like storing entire raw email content in every node's output when only a summary is needed) bloat the state unnecessarily, and inconsistent field naming or typing across nodes creates exactly the kind of integration bugs that are hard to trace once the pipeline has many nodes.

---

### 2. Internal Working — Step by Step

**Designing the complete state schema for this project's real pipeline:**

1. **Input fields** (populated once, at the start, never modified by later nodes): `email_text`, `sender_email`, `email_subject`, `received_timestamp` — the raw, immutable facts about the incoming request.
2. **Per-stage output fields** (each node populates its own): `rule_result` (from the rules node), `ml_prediction` / `ml_confidence` (from the ML node), `sender_history` (from a memory-lookup node, per Chapter 11), `genai_tool_trace` / `genai_final_answer` (from the GenAI node, capturing not just the final answer but the full tool-call sequence for debugging, per Chapter 10 Topic 6's tracing discipline).
3. **Final decision fields** (populated by the finalize node, synthesizing everything above): `final_label`, `final_source` (which stage's output was authoritative), `final_reason`.
4. **Metadata/observability fields** (useful for debugging and monitoring, not part of the core business logic): `processing_start_time`, `nodes_visited` (a list tracking which nodes actually ran for this request — directly useful for the per-node monitoring Topic 1 flagged as a graph-representation benefit), `errors_encountered` (any node-level errors, following Chapter 10 Topic 4's structured-error philosophy now applied at the pipeline level).

**Designing nodes as pure, testable functions of state:**

1. Every node should be a **pure function of the state it receives** — given the same input state, it should always produce the same output state (aside from genuinely non-deterministic operations like an LLM call, which introduce controlled, expected non-determinism, not implicit hidden dependencies on external mutable variables).
2. Every node should **only modify the fields it's responsible for**, never fields owned by other nodes — the `ml_node` should never touch `rule_result`, for instance — this discipline (analogous to Chapter 10 Topic 2's single-responsibility principle for tool functions) keeps the state's evolution traceable and prevents nodes from having confusing, hidden side effects on unrelated parts of the pipeline's data.
3. Every node should **handle its own failure modes gracefully** (Chapter 10 Topic 4's discipline, now applied per-node) — if the ML model fails to load or the GenAI agent's underlying API call errors out, the node should populate an `errors_encountered` field and allow the graph's conditional routing to decide how to proceed (perhaps escalating to a different stage, or routing to a human-review terminal state), rather than raising an uncaught exception that crashes the entire graph execution.

**Designing edges — the routing logic that decides node sequencing:**

1. **Simple edges**: an unconditional "always go to node B after node A" connection — used when there's no decision to make, just a fixed sequence (e.g. `genai_escalation` always leads to `finalize`).
2. **Conditional edges**: a function examining the current state and returning the name of the next node — this is where the cascade's actual decision logic lives (Topic 1's `route_after_rules`, `route_after_ml` functions), and should be kept as simple, focused decision functions, ideally each handling exactly one specific routing decision rather than combining several unrelated conditions into one large routing function.

---

### 3. How It Is Implemented in This Project

```python
from typing import TypedDict, Optional, List, Dict, Any
from datetime import datetime

class EmailClassificationState(TypedDict):
    """The COMPLETE state schema for this project's real pipeline --
    extending Topic 1's initial sketch with memory (Chapter 11), full
    tool-trace observability (Chapter 10 Topic 6), and error tracking
    (Chapter 10 Topic 4's discipline applied at the pipeline level)."""

    # --- Input fields: populated once, never modified afterward ---
    email_text: str
    email_subject: str
    sender_email: str
    received_timestamp: str

    # --- Rules stage output ---
    rule_result: Optional[str]  # "FD" / "Non-FD" / "Multiple Category" / "ambiguous" / None if not yet run

    # --- ML stage output ---
    ml_prediction: Optional[str]
    ml_confidence: Optional[float]

    # --- Memory stage output (Chapter 11) ---
    sender_history: Optional[Dict[str, Any]]  # check_sender_history()'s result

    # --- GenAI stage output (Chapters 3, 9-11) ---
    genai_tool_trace: Optional[List[Dict[str, Any]]]  # full sequence of tool calls made
    genai_final_answer: Optional[Dict[str, Any]]

    # --- Final decision (populated by finalize_node) ---
    final_label: Optional[str]
    final_source: Optional[str]
    final_reason: Optional[str]

    # --- Observability / metadata (not business logic, purely for debugging/monitoring) ---
    nodes_visited: List[str]
    errors_encountered: List[Dict[str, str]]
    processing_start_time: float


def create_initial_state(email_text: str, email_subject: str, sender_email: str) -> EmailClassificationState:
    """Constructs the STARTING state -- only input fields populated,
    everything else explicitly None/empty, never left undefined."""
    return {
        "email_text": email_text,
        "email_subject": email_subject,
        "sender_email": sender_email,
        "received_timestamp": datetime.now().isoformat(),
        "rule_result": None,
        "ml_prediction": None,
        "ml_confidence": None,
        "sender_history": None,
        "genai_tool_trace": None,
        "genai_final_answer": None,
        "final_label": None,
        "final_source": None,
        "final_reason": None,
        "nodes_visited": [],
        "errors_encountered": [],
        "processing_start_time": datetime.now().timestamp(),
    }


def rules_node(state: EmailClassificationState) -> EmailClassificationState:
    """A PURE, single-responsibility node: reads email_text, writes ONLY
    rule_result and appends to nodes_visited. Never touches ml_*, genai_*,
    or final_* fields -- those belong to OTHER nodes."""
    try:
        result = classify_by_keyword_rules(state["email_text"])
        return {**state, "rule_result": result, "nodes_visited": state["nodes_visited"] + ["rules_node"]}
    except Exception as e:
        error_entry = {"node": "rules_node", "error_type": type(e).__name__, "message": str(e)}
        return {**state, "rule_result": None,
                "nodes_visited": state["nodes_visited"] + ["rules_node"],
                "errors_encountered": state["errors_encountered"] + [error_entry]}


def memory_node(state: EmailClassificationState) -> EmailClassificationState:
    """Chapter 11's check_sender_history(), wired as its OWN node --
    runs EARLY, per Chapter 10 Topic 5's sequencing guidance, gathering
    context before the classification decision itself is made."""
    try:
        history = check_sender_history(state["sender_email"])
        return {**state, "sender_history": history, "nodes_visited": state["nodes_visited"] + ["memory_node"]}
    except Exception as e:
        error_entry = {"node": "memory_node", "error_type": type(e).__name__, "message": str(e)}
        return {**state, "sender_history": {"is_repeat_sender": False},  # SAFE DEFAULT on failure
                "nodes_visited": state["nodes_visited"] + ["memory_node"],
                "errors_encountered": state["errors_encountered"] + [error_entry]}
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **State bloat over time**: as this project's pipeline grows (more nodes, more tools per Chapter 10 Topic 5's trajectory), the temptation to keep adding fields to one ever-growing state schema is real — at some point, a genuinely large state object adds its own overhead (serialization cost if state is persisted or logged, cognitive overhead for anyone reading the schema) that should be actively managed, potentially by periodically reviewing whether every field is still genuinely needed or whether some can be derived on demand rather than stored.
- **The `nodes_visited` and `errors_encountered` observability fields have real, concrete monitoring value**: these directly enable the per-node monitoring Topic 1 flagged as a graph-representation benefit — tracking which nodes ran for what fraction of requests (how often does the cascade escalate all the way to GenAI, versus resolving at the cheap rules stage) is exactly the kind of operational visibility this project's earlier chapters (Chapter 1's cascade design) would have benefited from having built in from the start.
- **Safe-default behavior on node failure, made concrete in `memory_node`**: when `check_sender_history()` fails (Chapter 10 Topic 4's error categories), the node doesn't propagate the failure — it substitutes a safe default (`is_repeat_sender: False`) so the rest of the pipeline can proceed without depending on memory context that couldn't be retrieved, while still recording the failure in `errors_encountered` for monitoring. This is a deliberate design choice: memory lookup failure shouldn't block the entire classification pipeline, since the pipeline can still function (less optimally) without it.
- **Debugging with the full state trace**: when a specific request produces an incorrect final classification, having the complete state object (not just the final answer) available for inspection — every stage's output, the full tool trace, any errors encountered — makes root-cause diagnosis dramatically more direct than needing to reconstruct what happened from scattered logs across a nested-conditional implementation.
- **Monitoring**: track state field population rates over time (what fraction of requests actually reach the `genai_final_answer` field being populated, indicating escalation to the expensive GenAI stage) and `errors_encountered` rates per node, as concrete, directly-derivable operational metrics from the state schema's own structure.
- **Cost and latency**: the state schema itself has negligible direct cost or latency impact (it's just a data structure) — but a well-designed schema that enables clear per-node monitoring can indirectly help *identify* cost and latency issues (e.g. discovering the GenAI escalation happens more often than expected, driving up cost, is only possible with the `nodes_visited` tracking this schema provides).
- **Security**: the state schema, once it includes fields like `sender_email` and `sender_history` (which may contain distilled but still customer-specific information per Chapter 11 Topic 1), is itself a structure containing customer PII — if this state is ever logged, persisted, or transmitted for debugging/monitoring purposes, it inherits the same access-control and governance requirements established for customer data throughout this project (Chapter 6 Topic 9, Chapter 11 Topic 2).

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **Flat state schema (all fields at the top level, as shown) vs. nested/namespaced state (e.g. `state["ml"]["prediction"]`, `state["ml"]["confidence"]`)**: a flat schema is simpler to read and access but can become unwieldy as field count grows and namespace collisions become a real risk (two different stages both wanting a field called `confidence`, for instance); a nested schema groups related fields naturally and avoids collision risk, at the cost of slightly more verbose access patterns (`state["ml"]["confidence"]` vs `state["ml_confidence"]`). For this project's current scale, the flat schema shown is reasonable, but nesting by stage becomes worth considering as field count grows substantially.
- **How much of the GenAI stage's tool trace to retain in the state vs. logging it separately**: retaining the full `genai_tool_trace` directly in the state (as shown) makes it available to any downstream node or the finalize step without a separate lookup, at the cost of a potentially large state object for complex multi-tool GenAI interactions (Chapter 10 Topic 5's multi-tool sequencing scenarios). An alternative keeps only a reference/ID in the state, with the full trace logged separately and retrievable on demand for debugging — trading state size for an extra lookup step when the full trace is actually needed.
- **Whether nodes should be allowed to see the FULL state or only the specific fields they need**: allowing full state visibility (as shown, where every node receives the complete `EmailClassificationState`) is simpler to implement but risks a node accidentally depending on or being confused by fields it doesn't actually need. A stricter design could pass each node only the specific subset of state fields it requires (and expect only its own output fields back) — more disciplined, closer to genuine single-responsibility enforcement, at the cost of more boilerplate to define per-node input/output projections.

---

### 6. Alternatives and When to Use Each

- **A single flat TypedDict state schema (this project's demonstrated approach)**: appropriate for a pipeline of this project's current and near-term scale, where the total field count remains manageable and namespace collisions are unlikely.
- **A nested/namespaced state schema**: worth adopting once field count grows large enough that a flat structure becomes hard to navigate, or once multiple stages risk field-naming collisions.
- **Strict per-node input/output projection (only exposing relevant state subsets to each node)**: worth adopting once the team wants stronger, enforced guarantees about node isolation, particularly valuable in a larger team where different engineers own different nodes and accidental cross-node field dependencies become a genuine risk to guard against structurally rather than just through code review discipline.

---

### 7. Common Mistakes and Production Failures

- Letting a node modify a field it doesn't own (e.g. the ML node accidentally overwriting `rule_result`), creating confusing, hard-to-trace bugs where a node's output appears to change for reasons unrelated to its own logic.
- Not including observability fields (`nodes_visited`, `errors_encountered`) from the start, then having to retrofit them later once the operational need for per-node monitoring becomes apparent — a much more disruptive change once the pipeline is already in production with an established state schema.
- Allowing state bloat to grow unchecked, adding new fields for every new capability without periodically reviewing whether the schema still makes sense as a coherent whole.
- Not handling node-level failures gracefully with safe defaults where appropriate (as `memory_node` demonstrates), letting a non-critical stage's failure unnecessarily block or crash the entire pipeline.
- Treating the state object casually with respect to PII, logging or persisting it without the same access-control discipline applied to the underlying customer data it contains.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: What are the three main categories of fields in this project's `EmailClassificationState` schema, and why is this categorization useful?**
A: Input fields (immutable facts about the request, populated once), per-stage output fields (each node's specific results), and observability/metadata fields (tracking which nodes ran and what errors occurred, not part of the core business logic). This categorization clarifies ownership — which node is responsible for which fields — and makes it clear which fields should never change after initial population versus which are expected to be populated progressively as the pipeline executes.

**Q: Why should each node only modify the state fields it's specifically responsible for?**
A: This is a single-responsibility discipline applied to pipeline stages, directly analogous to Chapter 10 Topic 2's separation-of-concerns principle for tool functions — if the ML node could modify `rule_result`, tracing why a specific field changed would require checking every node's code rather than just the one node genuinely responsible for it, making debugging significantly harder as the pipeline grows more complex.

**Intermediate:**

**Q: Why does `memory_node` substitute a safe default (`is_repeat_sender: False`) rather than propagating a failure when `check_sender_history()` fails?**
A: Memory lookup is a genuinely non-critical enhancement to the classification decision — the pipeline can still function, just without the benefit of repeat-sender context, if this lookup fails. Propagating the failure (crashing the node, or blocking the pipeline) would make classification depend on memory infrastructure availability, an unnecessary and unjustified coupling given the actual criticality of this specific piece of context. This mirrors Chapter 10 Topic 4's broader principle of distinguishing which failures should block a request versus which should degrade gracefully.

**Q: What operational value does the `nodes_visited` field provide beyond what a nested-conditional implementation could easily offer?**
A: It directly enables tracking, for the full population of production requests, what fraction resolve at each stage of the cascade (rules-only, rules-then-ML, full escalation to GenAI) — a concrete, directly queryable operational metric. A nested-conditional implementation could technically log similar information, but doing so requires deliberately adding logging statements at every branch point, which is easy to miss or do inconsistently; the graph representation with a dedicated state field makes this observability a structural property of the design rather than something bolted on separately.

**Advanced:**

**Q: Design the state schema changes needed to support Chapter 10 Topic 5's multi-tool sequencing (validate_fd_reference, lookup_product_catalog, search_knowledge_base potentially all called within one GenAI escalation) with full observability.**
A: The `genai_tool_trace` field should be a list of structured records, each capturing the tool name called, the arguments passed, the result returned, and a timestamp — exactly the format needed for Chapter 10 Topic 6's regression testing methodology (Selection Accuracy, Argument Correctness, Order Correctness) to be computed directly from the state's own recorded trace, without needing separate, parallel logging infrastructure. This makes the state schema itself double as the source of truth for both real-time pipeline execution and offline evaluation, a valuable design property — the same data structure serves both purposes rather than requiring the evaluation harness to reconstruct execution details from disparate logs.

**Q: A teammate proposes storing the full state object (including complete tool traces) in a database after every request, for audit and debugging purposes. What design considerations would you raise?**
A: This is a reasonable and often valuable practice for auditability, especially in a regulated financial domain, but requires the same PII governance discipline established throughout this project (Chapter 6 Topic 9, Chapter 11 Topic 2) — the persisted state contains customer email content, sender identity, and potentially sensitive tool-call results (FD account details), so this audit log itself needs appropriate access control, encryption, and retention/deletion policies, including right-to-be-forgotten compliance. Additionally, the storage cost and query patterns for this audit log (how often is it actually queried, for what purpose, by whom) should inform its own schema design — a full nested JSON blob per request might be simplest to write but harder to query efficiently at scale compared to extracting key fields (final_label, final_source, error occurrence) into indexed columns with the full state as a supplementary JSON field for deep-dive debugging when needed.

**Scenario-based:**

**Q: A specific customer's classification result is disputed — they believe their email was miscategorized. You have the full state object for this request available. Walk through your investigation.**
A: Start with `final_label` and `final_source` to see which stage's output was authoritative. If `final_source` is "rules," inspect `rule_result` directly and cross-reference against `fd_keyword_groups.txt`/`fd_negation_phrases.txt` to understand why the rule engine reached this conclusion (Chapter 7 Topic 5's reframing of the rule engine applies directly here). If `final_source` is "ml," check `ml_confidence` — a borderline confidence value close to the escalation threshold might indicate this was a genuinely hard case that arguably should have escalated further. If `final_source` is "genai," the `genai_tool_trace` becomes the primary investigation artifact — checking which tools were called, with what arguments, and whether the final synthesis correctly used the gathered information (Chapter 10 Topic 6's Terminal Outcome Accuracy concern) or whether a tool-calling or synthesis error contributed to the disputed outcome. Throughout, also check `errors_encountered` for any node-level failures that might have silently degraded the pipeline's behavior for this specific request without necessarily causing an obvious crash.

---

### 9. Hidden Concepts and Prerequisites

- **This topic is a direct application of general data modeling and schema design discipline** — the same principles that guide good database schema design (clear field ownership, appropriate normalization, avoiding redundant or ambiguous fields) apply directly to designing a pipeline's shared state schema, just in the context of an in-memory or transient data structure rather than a persistent database table.
- **The "pure function" principle for nodes connects to functional programming concepts** — designing nodes to be deterministic functions of their input state (aside from genuinely non-deterministic operations like LLM calls) makes the pipeline's behavior easier to reason about and test, drawing on a long-established programming paradigm's benefits (predictability, testability) without requiring the team to adopt functional programming as a general practice.
- **This connects directly forward to Topics 3-5 of this chapter**, which build the complete graph (all nodes, all conditional edges) using this topic's state schema as the foundation, and then run it end-to-end against real emails — this topic deliberately focused on getting the state/node/edge design principles right before assembling them into the complete, working pipeline.

---

### 10. Revision Summary

> A well-designed state schema for this project's pipeline categorizes fields into immutable inputs, per-stage outputs (owned exclusively by their respective node), final decision fields, and observability metadata (`nodes_visited`, `errors_encountered`) that directly enable the per-node monitoring Topic 1 identified as a core graph-representation benefit. Nodes should be pure, single-responsibility functions — reading the state they need, writing only the fields they own, and handling their own failure modes gracefully with safe defaults where the failure is non-critical to the overall pipeline (as `memory_node` demonstrates for Chapter 11's `check_sender_history()`). Edges, particularly conditional edges, should be simple, focused decision functions, each handling one specific routing decision rather than combining unrelated conditions. This schema design directly enables Chapter 10 Topic 6's regression testing methodology to operate on the state's own recorded tool trace, and provides the complete debugging artifact needed to investigate any disputed or unexpected classification outcome by tracing exactly which stages ran, what each produced, and what (if any) errors occurred along the way.

---
