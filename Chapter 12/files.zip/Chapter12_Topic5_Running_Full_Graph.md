# Chapter 12: Agent Orchestration with LangGraph

## Topic 5: Running the Full Graph End to End on Real Emails from the CSV

---

### 1. Concept, Intuition, and Why It Exists

- Topics 1-4 designed and built the complete graph conceptually and structurally. This topic is where all of that gets validated the way every other major design decision in this project has been validated: against real data, specifically this project's actual `fd_dataset_messy.csv` (2,500 labeled emails, 40.1% FD / 30.0% Multiple Category / 29.9% Non-FD, 64.4% Hinglish, ~31-word average length).
- This is directly analogous to Chapter 9 Topic 8's "Smart Saver FD" proof — a single, well-constructed demonstration is persuasive, but the *real* validation this project has consistently demanded (Chapter 7 Topic 9's Recall@K/MRR/NDCG@K, Chapter 8 Topic 3's faithfulness/relevance/correctness, Chapter 10 Topic 6's tool-calling regression suite) is a systematic run across a representative, labeled dataset, producing concrete metrics: what fraction of the 2,500 emails resolve at each cascade stage, what's the accuracy at each stage, and does the complete graph's end-to-end accuracy meet or exceed the standalone baselines established in earlier chapters (Chapter 1's MuRIL 0.97 FD Recall, Chapter 2's prompted-Claude 0.50-0.80 FD Recall).
- Why this topic closes Chapter 12 appropriately: everything from Topic 1's conceptual argument through Topic 4's bypass/circuit-breaker mechanisms remains a set of design *hypotheses* until they're run against real data and produce measured evidence — this topic is where the chapter's claims become falsifiable, testable facts about this project's actual system.

---

### 2. Internal Working — Step by Step

**The evaluation methodology, directly extending this project's established evaluation disciplines:**

1. **Run the complete compiled graph** (from Topic 3, with Topic 4's bypass/circuit-breaker logic integrated) against every email in `fd_dataset_messy.csv`, recording the complete `EmailClassificationState` for each — not just the final label, but `final_source`, `nodes_visited`, `errors_encountered`, and (for GenAI-escalated cases) the full `genai_tool_trace`.
2. **Compute cascade-level metrics**: what fraction of the 2,500 emails resolve at `rules`, `ml`, `genai`, `spam_bypass`, or `human_review_required` — this is the concrete realization of the cost-optimization goal the entire cascade architecture exists to achieve, giving a real number for "how often do we actually pay for the expensive stage."
3. **Compute per-stage accuracy**: for each `final_source` category, compare `final_label` against the ground-truth label in the CSV — does the rules stage's resolved subset actually have high accuracy (validating that confident rule-engine results are trustworthy), does the ML stage's resolved subset meet its expected ~0.90+ confidence-implied accuracy, and critically, does the GenAI-escalated subset (the hardest cases, by construction, since they're exactly the ones the cheaper stages couldn't confidently resolve) achieve accuracy that justifies its cost.
4. **Compute overall, end-to-end accuracy** across all 2,500 emails, and compare directly against Chapter 1's MuRIL-alone baseline (0.97 FD Recall) and Chapter 2's prompted-Claude-alone baseline (0.50-0.80 FD Recall) — this is the single most important comparison this topic produces: does the full cascade (cheap stages plus GenAI escalation for hard cases) meet or exceed the best single-method baseline, ideally at lower average cost than always using the most capable method.

---

### 3. How It Is Implemented in This Project

```python
import pandas as pd

def run_graph_on_dataset(compiled_graph, dataset_path: str = "fd_dataset_messy.csv") -> pd.DataFrame:
    """Runs the complete Chapter 12 graph across every labeled email,
    recording full state for later analysis -- exactly the systematic,
    dataset-wide evaluation discipline established since Chapter 7 Topic 9."""

    df = pd.read_csv(dataset_path)
    results = []

    for _, row in df.iterrows():
        initial_state = create_initial_state(
            email_text=row["content"], email_subject=row["subject"], sender_email=row["sender_email"]
        )
        final_state = compiled_graph.invoke(initial_state)

        results.append({
            "email_id": row.get("id"),
            "ground_truth_label": row["label"],
            "predicted_label": final_state["final_label"],
            "final_source": final_state["final_source"],
            "nodes_visited": final_state["nodes_visited"],
            "had_errors": len(final_state["errors_encountered"]) > 0,
            "correct": final_state["final_label"] == row["label"],
        })

    return pd.DataFrame(results)


def compute_cascade_metrics(results_df: pd.DataFrame) -> dict:
    """Extends Chapter 2's classification evaluation methodology with
    CASCADE-SPECIFIC metrics -- resolution distribution and per-stage
    accuracy, the concrete evidence this chapter's design decisions need."""

    total = len(results_df)

    # Resolution distribution: WHERE did each email actually get resolved?
    resolution_distribution = results_df["final_source"].value_counts(normalize=True).to_dict()

    # Per-stage accuracy: is each stage's OWN resolved subset actually reliable?
    per_stage_accuracy = {}
    for source in results_df["final_source"].unique():
        subset = results_df[results_df["final_source"] == source]
        per_stage_accuracy[source] = subset["correct"].mean()

    overall_accuracy = results_df["correct"].mean()

    return {
        "total_emails": total,
        "resolution_distribution": resolution_distribution,
        "per_stage_accuracy": per_stage_accuracy,
        "overall_accuracy": overall_accuracy,
        "error_rate": results_df["had_errors"].mean(),
    }


def compare_against_baselines(cascade_accuracy: float) -> dict:
    """Direct comparison against THIS PROJECT'S OWN established baselines --
    Chapter 1's MuRIL (0.97 FD Recall) and Chapter 2's prompted-Claude
    (0.50-0.80 FD Recall) -- the exact numbers this project has carried
    forward since its earliest chapters."""
    return {
        "cascade_accuracy": cascade_accuracy,
        "muril_baseline": 0.97,
        "prompted_claude_baseline_range": (0.50, 0.80),
        "cascade_meets_muril_baseline": cascade_accuracy >= 0.97,
        "cascade_exceeds_prompted_claude_alone": cascade_accuracy > 0.80,
    }
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **Running the full 2,500-email dataset through the GenAI stage for any email that escalates incurs real API cost**: unlike the rules and ML stages (essentially free, local computation), every GenAI-escalated email in this evaluation run makes real `claude-haiku-4-5-20251001` API calls — this evaluation run's own cost should be estimated and budgeted for before running it at full scale, and a smaller, representative sample could be used for iterative development before committing to a full 2,500-email run.
- **Per-stage accuracy interpretation requires care**: a *low* accuracy specifically within the GenAI-escalated subset is not automatically alarming — these are, by construction, the hardest cases the cheaper stages couldn't confidently resolve, so some accuracy degradation relative to the rules/ML stages' own (much easier) resolved subsets is expected and doesn't necessarily indicate a problem with the GenAI stage itself; the meaningful comparison is whether GenAI's accuracy on these hard cases still exceeds what the cheap stages would have achieved on the *same* hard cases if forced to resolve them without escalation (a counterfactual that requires deliberately also running the cheap stages' raw predictions on the escalated subset for comparison, even though the cascade's actual routing bypassed them).
- **Debugging cases where the cascade produces a wrong result despite each individual stage seemingly "working correctly"**: this requires exactly the full-state tracing methodology established in Chapter 12 Topic 2 — reviewing `nodes_visited`, each stage's specific output, and (for GenAI cases) the full `genai_tool_trace`, to determine whether the error originated in the routing decision itself (a case that should have escalated further but didn't) or in the resolving stage's own output (a stage that ran and produced a wrong answer despite reasonable confidence).
- **Monitoring**: this dataset-wide evaluation run should be re-executed periodically (not just once) as this project's underlying components evolve — a change to `fd_keyword_groups.txt` (Chapter 7 Topic 5), a MuRIL model update, a system prompt change to the GenAI agent, or a confidence-threshold adjustment (Topic 3) should each trigger a re-run of this evaluation to confirm the change's actual measured impact on cascade-level metrics, exactly the before-and-after evaluation discipline established throughout this project.
- **Cost**: the resolution distribution computed here (Section 2, point 2) directly informs this project's actual, ongoing production cost model — knowing that, say, 70% of emails resolve at the free rules stage, 20% at the cheap ML stage, and only 10% require GenAI escalation gives a concrete basis for cost forecasting at the project's actual production volume (8,000-12,000 emails/day), extending Chapter 9 Topic 3's cost-tracking discussion with real, measured proportions rather than assumptions.
- **Security**: running this evaluation against real (even if historical, labeled) customer email data requires the same PII handling discipline established throughout this project — the evaluation results themselves (which may include email content snippets for debugging misclassified cases) should be handled with appropriate access control, not treated as casually shareable engineering artifacts.
- **Deployment**: this evaluation methodology, once built, should become a standing regression suite — run automatically before deploying any change to the cascade's nodes, routing logic, or thresholds, mirroring Chapter 10 Topic 6's tool-calling regression suite discipline now applied at the full pipeline level.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **Full 2,500-email evaluation vs. a smaller, representative sample for faster iteration**: a full run gives the most statistically reliable results but costs more (in GenAI API calls) and takes longer — a smaller, carefully stratified sample (ensuring representative coverage of FD/Non-FD/Multiple Category, Hinglish/English, and known-hard-case patterns) is appropriate for rapid iteration during development, reserving full-dataset runs for validating a change before actual production deployment, exactly the same cost-vs-thoroughness trade-off Chapter 7 Topic 9 discussed for building evaluation sets generally.
- **Should the counterfactual comparison (what would the cheap stages have predicted on GenAI-escalated cases, even though they didn't actually resolve them) be computed routinely?**: this adds real complexity and cost (running the cheap stages' predictions even on cases that will be discarded in favor of GenAI's answer) but provides valuable insight into how much value GenAI escalation is actually adding for the hardest cases — worth computing periodically as a diagnostic exercise, even if not part of the standard production pipeline's normal operation.
- **How to handle disagreement between the ground-truth label and what a careful human review would conclude**: this project's dataset labels, like any labeled dataset, may themselves contain some labeling errors or genuinely ambiguous cases where reasonable humans could disagree — a very low accuracy on a small subset of cases might reflect dataset label quality issues rather than genuine cascade failures, worth investigating specifically for persistently low-accuracy patterns before assuming the fault lies entirely with the cascade's own logic.

---

### 6. Alternatives and When to Use Each

- **Full dataset evaluation (this topic's primary methodology)**: the correct approach for validating a cascade design before production deployment or after a significant change, providing the most statistically reliable evidence.
- **Stratified sampling for rapid iteration**: appropriate during active development when many design variations need quick comparative evaluation, reserving full-dataset runs for final validation.
- **Live production A/B testing (a more advanced technique, forward-looking for this project)**: running the new cascade design alongside the existing approach on a small percentage of live traffic, comparing real-world outcomes directly — more rigorous than offline dataset evaluation (which uses historical, potentially stale data) but carries real deployment risk and is appropriate only once offline evaluation has already validated the design is reasonable to test live.

---

### 7. Common Mistakes and Production Failures

- Running this expensive, GenAI-API-cost-incurring full evaluation repeatedly during early, rapid iteration rather than using a smaller representative sample, incurring unnecessary cost for validation cycles that don't yet need full statistical rigor.
- Interpreting lower accuracy on the GenAI-escalated subset as a problem with the GenAI stage itself, without accounting for the fact that these are, by construction, the hardest cases the cheaper stages couldn't resolve.
- Not re-running this evaluation after changes to any cascade component (keyword lists, model versions, thresholds, system prompts), missing regressions that a full evaluation run would have caught before production deployment.
- Treating the dataset's ground-truth labels as infallible, missing the possibility that some accuracy shortfalls reflect genuine dataset labeling ambiguity rather than cascade design flaws.
- Not handling PII appropriately when reviewing or sharing evaluation results that include real customer email content for debugging misclassified cases.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: Why is running the complete graph against the full labeled dataset the appropriate way to validate this chapter's design decisions, rather than relying on the conceptual arguments from Topics 1-4 alone?**
A: Every claim made in Topics 1-4 — that the graph representation improves clarity, that specific confidence thresholds are well-calibrated, that bypass rules correctly identify their intended cases — is a hypothesis until validated against real data. Running the complete graph on the labeled `fd_dataset_messy.csv` produces concrete, falsifiable evidence: actual resolution distribution across cascade stages, actual per-stage accuracy, and a direct comparison against this project's own established baselines (MuRIL's 0.97, prompted-Claude's 0.50-0.80), turning design intentions into measured facts.

**Q: Why might lower accuracy specifically within the GenAI-escalated subset of emails not indicate a problem with the GenAI stage itself?**
A: The GenAI-escalated subset consists, by the cascade's own design, of exactly the hardest cases that the cheaper rules and ML stages couldn't confidently resolve — some accuracy degradation relative to the (much easier) rules/ML-resolved subsets is expected and doesn't automatically indicate the GenAI stage is malfunctioning. The meaningful question is whether GenAI's accuracy on these specific hard cases exceeds what the cheaper stages would have achieved on the same cases if forced to resolve them without escalation — a genuinely different, more informative comparison than simply looking at GenAI's absolute accuracy number in isolation.

**Intermediate:**

**Q: How would you determine whether this project's complete cascade meets or exceeds the accuracy of always using the single most capable method (GenAI for every email)?**
A: This requires the counterfactual comparison discussed in Section 5 — computing what GenAI would have predicted for every email, not just the ones the cascade actually escalated to it, and comparing that "GenAI for everything" accuracy against the cascade's actual, mixed-resolution accuracy. If the cascade's accuracy is comparable to or only marginally lower than the "GenAI for everything" baseline, while resolving the majority of emails via free or cheap stages, this validates the cascade's core cost-optimization premise — achieving comparable quality at meaningfully lower average cost, rather than sacrificing meaningful accuracy for cost savings.

**Q: Why should this evaluation be re-run after any change to `fd_keyword_groups.txt`, a MuRIL model update, or a confidence threshold adjustment, rather than trusting that such changes are safe based on their individual, isolated testing?**
A: Each of these components interacts with the others within the cascade — a change to the keyword list could shift which emails the rules stage confidently resolves versus passes to ML, which in turn changes the ML stage's actual workload and potentially its accuracy on that shifted subset, which changes GenAI escalation rate and cost. Testing each component in isolation (as Chapter 7 Topic 5 or Chapter 1's own evaluation might do) doesn't capture these cascade-level interaction effects — only re-running the complete, end-to-end evaluation reveals whether a component-level change that tested fine in isolation actually improves or regresses the full system's real-world behavior.

**Advanced:**

**Q: Design a continuous evaluation strategy for this project's cascade, given it will continue evolving (new products per Chapter 9 Topic 8, growing toolset per Chapter 10 Topic 5, memory architecture per Chapter 11) after this initial validation.**
A: Establish this dataset-wide evaluation as a standing, automated regression suite (mirroring Chapter 10 Topic 6's tool-calling regression discipline, now at the full-pipeline level) that runs automatically before any production deployment touching cascade logic, thresholds, or underlying models — comparing new-version metrics (resolution distribution, per-stage accuracy, overall accuracy, cost implications) against the previous version's baseline, flagging any statistically meaningful regression for human review before deployment proceeds. Complement this offline evaluation with production monitoring of the same core metrics (Topic 3's `final_source` distribution tracking) on live traffic, since the offline dataset, however comprehensive at the time it was built, will inevitably become somewhat stale relative to evolving real customer email patterns — the two together (pre-deployment regression testing plus ongoing production monitoring) provide both a safety gate before changes ship and continuous visibility into how the system is actually performing on genuinely current traffic.

**Q: A stakeholder is skeptical of the cascade's added complexity (multiple stages, confidence gates, bypass rules, circuit breakers) compared to simply using MuRIL alone, given MuRIL's already-strong 0.97 baseline established in Chapter 1. How do you make the case for the cascade using this topic's evaluation results?**
A: The case rests on demonstrating what MuRIL alone cannot do that the cascade specifically addresses — MuRIL, as a fixed, trained classifier, has no mechanism for handling genuinely novel product names or policy questions requiring retrieval-augmented reasoning (Chapter 9 Topic 8's Smart Saver FD proof directly demonstrates this gap), no ability to use tools for exact-match verification (Chapter 10's `validate_fd_reference`), and no adaptability to compliance-sensitive routing needs (Topic 4's bypass logic) — capabilities that specifically require the GenAI escalation tier. This topic's evaluation should show that the cascade achieves comparable or better real-world accuracy than MuRIL alone specifically because it can escalate the genuinely hard, novel, or compliance-sensitive cases MuRIL alone would misclassify, while still resolving the large majority of "easy" cases at MuRIL's own proven accuracy level (or even faster, cheaper rule-based resolution) — the cascade isn't replacing MuRIL's strength, it's extending coverage to cases MuRIL structurally cannot handle well, which is precisely what this topic's per-stage accuracy breakdown and resolution distribution are designed to make concrete and measurable rather than asserted.

**Scenario-based:**

**Q: After running this full evaluation, you discover the rules stage's resolved subset has surprisingly low accuracy (85%) despite the rule engine reporting confident, non-ambiguous results for these cases. Diagnose and propose next steps.**
A: This is a serious finding, since the rules stage's entire design premise (Chapter 1, Chapter 7 Topic 5) is that a confident, non-ambiguous rule-engine result should be highly reliable — an 85% accuracy on this specific subset suggests either the confidence gate's assumption ("non-ambiguous rule result implies high accuracy") no longer holds for the current email distribution, or `fd_keyword_groups.txt`/`fd_negation_phrases.txt` have specific patterns producing confident-but-wrong results. Sample the specific misclassified cases within this subset and look for a common pattern (a specific keyword group firing incorrectly, a negation phrase list gap) — this directly extends Chapter 7 Topic 5's evidence-based keyword-list maintenance methodology. Given the severity (this is the cheapest, most-trusted stage in the cascade, and 15% error on its own resolved subset is a meaningful, real business cost), this warrants immediate investigation and likely a keyword-list revision, re-validated against this same evaluation methodology before considering the fix complete.

---

### 9. Hidden Concepts and Prerequisites

- **This topic is the direct, concrete application of the "measure before and after any change" discipline this entire project has consistently modeled** — from Chapter 7's BM25/RRF/MMR parameter tuning through Chapter 10's tool-calling regression suite, this chapter's dataset-wide cascade evaluation is simply that same discipline applied at the highest level of this project's architecture: the complete, assembled system.
- **The counterfactual evaluation technique** (what would a bypassed stage have predicted, even though it didn't actually run) connects to causal inference concepts more broadly — understanding what a system would have done under a different condition than what actually happened is a recurring, valuable analytical technique across data science and machine learning evaluation generally, not unique to this specific cascade architecture.
- **This closes Chapter 12's full arc and connects forward to Chapter 13 (Agentic RAG)**, which will build on this validated cascade architecture by making the RAG retrieval decision itself (Chapter 9 Topic 1's retrieval triggering) more dynamically agentic within this graph structure — this chapter's validated, working graph is the foundation that chapter's more sophisticated agentic retrieval logic will extend.

---

### 10. Revision Summary

> Running the complete Chapter 12 graph against all 2,500 labeled emails in `fd_dataset_messy.csv` transforms every design decision from Topics 1-4 into measured, falsifiable evidence: the actual resolution distribution across cascade stages (how often the expensive GenAI stage is genuinely needed), per-stage accuracy (validating whether confident rule-engine and ML results are actually reliable, and whether GenAI escalation earns its cost on the hardest cases), and a direct comparison against this project's own established baselines from Chapter 1 (MuRIL's 0.97) and Chapter 2 (prompted-Claude's 0.50-0.80). Lower accuracy specifically within the GenAI-escalated subset is expected, not alarming, given these are by construction the hardest cases the cheaper stages couldn't resolve — the meaningful comparison is against what the cheap stages would have achieved on the same hard cases, not an absolute accuracy threshold. This evaluation must become a standing regression suite, re-run before any deployment touching cascade logic, thresholds, or underlying models, since component-level changes can have cascade-level interaction effects that isolated component testing cannot reveal. This validated, measured cascade is the foundation Chapter 13's more dynamically agentic retrieval decisions will build upon.

---
