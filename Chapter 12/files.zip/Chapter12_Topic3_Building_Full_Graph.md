# Chapter 12: Agent Orchestration with LangGraph

## Topic 3: Building the Rules → ML → Confidence-Gate → GenAI → Tools Graph

---

### 1. Concept, Intuition, and Why It Exists

- Topics 1 and 2 established why a graph representation helps and designed the state schema and node/edge principles. This topic assembles the **complete, actual graph** for this project's full cascade — every node from Topic 2, wired together with the correct conditional routing, including the memory lookup (Chapter 11) and the full multi-tool GenAI escalation (Chapters 9-10) as a genuinely complex sub-flow, not a single opaque node.
- The specific engineering challenge this topic addresses: the GenAI escalation stage is not actually one atomic operation — it's itself `run_agent()`'s internal tool-calling loop (Chapter 10 Topic 1), which can call `validate_fd_reference`, `search_knowledge_base`, `lookup_product_catalog`, and reach a terminal `finalize_classification` or `refuse_out_of_scope` call, potentially across several loop iterations. This topic addresses whether and how to represent that internal complexity within the outer graph, versus treating the entire GenAI stage as one black-box node.
- Why "confidence-gate" deserves explicit naming as a distinct concept: the transition from the ML stage to GenAI escalation is not a simple pass-through — it's a genuine *decision point* based on a confidence threshold (this project's existing 0.90 threshold, or whatever value evaluation determines is appropriate), and naming this explicitly as a "confidence gate" node or edge makes the threshold itself a visible, tunable, testable part of the graph's structure rather than a magic number buried inside a conditional.

---

### 2. Internal Working — Step by Step

**The complete graph structure, node by node:**

1. **Entry point**: `memory_node` — per Chapter 10 Topic 5's sequencing guidance ("call `check_sender_history` early"), this runs first, gathering repeat-sender context before any classification decision is attempted, since this context could in principle inform how subsequent stages interpret the email (though in this project's current design, it primarily flows through to the final synthesis and doesn't change the rules/ML stages' own logic).
2. **`rules_node`**: runs `classify_by_keyword_rules()`.
3. **Confidence gate 1 (conditional edge)**: routes to `finalize` if the rule engine produced a confident, non-ambiguous result; otherwise routes to `ml_node`.
4. **`ml_node`**: runs MuRIL inference.
5. **Confidence gate 2 (conditional edge)**: routes to `finalize` if ML confidence exceeds the threshold; otherwise routes to `genai_node`.
6. **`genai_node`**: invokes `run_agent()` — internally, this is where the tool-calling loop happens (Chapter 10 Topic 1's mechanics), but from the *outer* graph's perspective, this can be represented as a single node whose internal complexity is encapsulated, since the outer graph doesn't need to make routing decisions based on which specific tool the GenAI agent chose to call internally.
7. **`finalize_node`**: synthesizes whichever stage's output was authoritative into the final result.

**The key architectural decision: should the GenAI stage's internal tool-calling loop be its own sub-graph, or a single encapsulated node?**

- **Single encapsulated node (this project's recommended default)**: `genai_node` calls `run_agent()` as a complete, self-contained unit — the outer graph doesn't need visibility into or control over individual tool calls within that invocation, since `run_agent()`'s own internal loop (Chapter 10 Topic 1) already handles that correctly. This keeps the outer graph's structure focused on the *cascade-level* decision (rules vs. ML vs. GenAI), which is genuinely the level of abstraction this chapter's topic is about.
- **A full sub-graph for the GenAI stage** (representing each tool call as its own node within a nested graph): this becomes worth considering specifically if the outer pipeline needs to make routing decisions *based on* which tools the GenAI stage calls (e.g., "if `search_knowledge_base` returns `found: False`, route to a different fallback node before even reaching `finalize`") — a genuine architectural escalation only justified if such cross-cutting routing decisions actually become necessary, which this project's current design doesn't yet require.

---

### 3. How It Is Implemented in This Project

```python
from langgraph.graph import StateGraph, END

# -----------------------------------------------------------------------
# All node functions -- rules_node and memory_node from Topic 2, plus
# the remaining nodes completing the full cascade
# -----------------------------------------------------------------------

def ml_node(state: EmailClassificationState) -> EmailClassificationState:
    try:
        prediction, confidence = run_muril_classifier(state["email_text"])
        return {**state, "ml_prediction": prediction, "ml_confidence": confidence,
                "nodes_visited": state["nodes_visited"] + ["ml_node"]}
    except Exception as e:
        error_entry = {"node": "ml_node", "error_type": type(e).__name__, "message": str(e)}
        return {**state, "ml_prediction": None, "ml_confidence": 0.0,
                "nodes_visited": state["nodes_visited"] + ["ml_node"],
                "errors_encountered": state["errors_encountered"] + [error_entry]}


def genai_node(state: EmailClassificationState) -> EmailClassificationState:
    """The GenAI escalation stage -- ENCAPSULATES run_agent()'s entire
    internal tool-calling loop (Chapter 10 Topic 1) as ONE node from the
    outer graph's perspective. The outer graph doesn't need to know
    WHICH tools were called internally -- only the final outcome."""
    try:
        result = run_agent(state["email_text"], state["sender_email"])
        return {**state, "genai_tool_trace": result.get("tool_trace", []),
                "genai_final_answer": result,
                "nodes_visited": state["nodes_visited"] + ["genai_node"]}
    except Exception as e:
        error_entry = {"node": "genai_node", "error_type": type(e).__name__, "message": str(e)}
        # Safe fallback: if the ENTIRE GenAI stage fails, route toward
        # human review rather than crashing -- Chapter 10 Topic 4's
        # discipline, now protecting the pipeline's MOST expensive,
        # most complex stage
        return {**state, "genai_final_answer": {"label": None, "requires_human_review": True},
                "nodes_visited": state["nodes_visited"] + ["genai_node"],
                "errors_encountered": state["errors_encountered"] + [error_entry]}


def finalize_node(state: EmailClassificationState) -> EmailClassificationState:
    """Synthesizes whichever stage's output was authoritative -- now ALSO
    incorporating sender_history context (Chapter 11) into the final
    reasoning, and handling the genai_node failure fallback."""
    if state.get("rule_result") not in (None, "ambiguous"):
        return {**state, "final_label": state["rule_result"], "final_source": "rules",
                "final_reason": "Confident rule-based match"}

    if state.get("ml_confidence", 0) > 0.90:
        return {**state, "final_label": state["ml_prediction"], "final_source": "ml",
                "final_reason": f"ML confidence {state['ml_confidence']:.2f} exceeds threshold"}

    genai_answer = state.get("genai_final_answer", {})
    if genai_answer.get("requires_human_review"):
        return {**state, "final_label": None, "final_source": "human_review_required",
                "final_reason": "GenAI stage failed -- routed to human review"}

    return {**state, "final_label": genai_answer.get("label"), "final_source": "genai",
            "final_reason": "Resolved via full GenAI agent with tool access"}


# -----------------------------------------------------------------------
# CONFIDENCE GATES -- explicitly named conditional edges, making the
# threshold-based decision points visible, tunable structure rather
# than buried magic numbers
# -----------------------------------------------------------------------

RULE_CONFIDENCE_GATE_APPLIES = lambda state: state.get("rule_result") not in (None, "ambiguous")
ML_CONFIDENCE_THRESHOLD = 0.90  # a NAMED, tunable constant -- not a magic number in a conditional

def confidence_gate_1_rules(state: EmailClassificationState) -> str:
    """CONFIDENCE GATE 1: does the rule engine's result meet the bar to finalize?"""
    return "finalize" if RULE_CONFIDENCE_GATE_APPLIES(state) else "ml_check"

def confidence_gate_2_ml(state: EmailClassificationState) -> str:
    """CONFIDENCE GATE 2: does ML confidence meet the threshold to finalize?"""
    return "finalize" if state.get("ml_confidence", 0) > ML_CONFIDENCE_THRESHOLD else "genai_escalation"


# -----------------------------------------------------------------------
# ASSEMBLING THE COMPLETE GRAPH
# -----------------------------------------------------------------------

graph = StateGraph(EmailClassificationState)

graph.add_node("memory_check", memory_node)
graph.add_node("rules_check", rules_node)
graph.add_node("ml_check", ml_node)
graph.add_node("genai_escalation", genai_node)
graph.add_node("finalize", finalize_node)

graph.set_entry_point("memory_check")
graph.add_edge("memory_check", "rules_check")  # simple edge -- always proceeds to rules after memory
graph.add_conditional_edges("rules_check", confidence_gate_1_rules,
                             {"finalize": "finalize", "ml_check": "ml_check"})
graph.add_conditional_edges("ml_check", confidence_gate_2_ml,
                             {"finalize": "finalize", "genai_escalation": "genai_escalation"})
graph.add_edge("genai_escalation", "finalize")
graph.add_edge("finalize", END)

compiled_graph = graph.compile()
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **The "encapsulated node vs. sub-graph" decision has real, concrete consequences for debugging**: with `genai_node` as a single encapsulated call, debugging a GenAI-stage issue requires drilling into `genai_tool_trace` (Chapter 10 Topic 6's tracing data) separately from the outer graph's own execution trace — this is a deliberate, reasonable trade-off for this project's current needs, but is worth explicitly recognizing as a two-level debugging structure (outer graph trace, plus inner tool-call trace within the GenAI node) rather than one unified trace.
- **Named, tunable thresholds (`ML_CONFIDENCE_THRESHOLD`) as explicit constants, not buried literals**: this directly supports the evaluation-driven tuning discipline established throughout this project (Chapter 7's BM25/RRF/MMR parameters, Chapter 9's retrieval triggers) — having `0.90` as a named constant makes it a visible, easily-locatable, easily-testable parameter rather than a magic number that could be scattered or duplicated inconsistently across the codebase.
- **The `genai_node` failure fallback (`requires_human_review`) is a critical production safety net**: if the entire GenAI stage fails (not just an individual tool within it, which `run_agent()` itself already handles per Chapter 10 Topic 4, but a catastrophic failure of the agent call itself), the graph doesn't simply crash or produce an undefined result — it explicitly routes to a "needs human attention" terminal state, exactly the kind of graceful degradation this project has consistently prioritized.
- **Monitoring**: track the distribution of `final_source` values across production traffic (what fraction resolve at rules, ML, or full GenAI escalation) — this is the concrete business metric this entire cascade architecture exists to optimize (minimizing expensive GenAI escalation while maintaining accuracy), and the graph's explicit structure with `nodes_visited` tracking (Topic 2) makes this metric directly and easily derivable.
- **Latency**: the `memory_check` node running unconditionally at the start (per Chapter 10 Topic 5's "always call this early" guidance for `check_sender_history`) adds its latency to every single request, even ones that will resolve quickly at the rules stage — this is exactly the cost/value trade-off Chapter 11 Topic 1 and Chapter 10 Topic 5 already flagged as needing empirical validation, now made concrete in the graph's actual execution order.
- **Cost**: the confidence gates are the direct mechanism controlling this project's overall cost profile — a threshold set too low sends too many cases to the expensive GenAI stage unnecessarily; set too high, and genuinely uncertain cases get finalized on insufficiently confident ML output, a correctness risk. This threshold tuning is a genuine, ongoing cost-vs-accuracy trade-off that should be validated against real labeled data (extending Chapter 2's evaluation methodology to this specific threshold).
- **Security**: no new security concerns beyond what's already established for each individual node's underlying operations (Chapters 6, 9, 10, 11) — the graph structure itself doesn't introduce new PII exposure risk, provided each node continues to respect the access-scoping principles already established.
- **Deployment**: the compiled graph becomes this project's actual production entry point for email classification — deploying a change to any node's logic, or to a confidence threshold, now goes through this single, well-defined graph structure, making deployment and rollback conceptually cleaner than coordinating changes across scattered nested-conditional code.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **Should `memory_check` really run unconditionally first, or only when a downstream stage's routing might benefit from it?**: this project's current design runs it unconditionally, per Chapter 10 Topic 5's guidance — but this pays its cost on every request, including the majority likely resolved by the cheap rules stage where sender history arguably isn't needed at all for the *decision* (though it is used in `finalize_node`'s reasoning if the email does escalate). A more selective design could defer the memory lookup until *after* the confidence gates determine escalation is actually happening, running it only as part of the GenAI stage's own context-gathering — reducing unnecessary cost for the majority of quickly-resolved requests, at the cost of `finalize_node` no longer having sender history available for rules/ML-resolved cases if that context ever proves valuable there too. This is exactly the kind of trade-off that should be validated with production data (how often would sender history have changed a rules/ML-resolved case's outcome) rather than decided by intuition.
- **Confidence gate thresholds as static constants vs. dynamically tuned values**: a static `ML_CONFIDENCE_THRESHOLD = 0.90` is simple and auditable, but a more sophisticated design could adjust this threshold based on context (e.g., a lower threshold — more escalation to GenAI — for email patterns associated with higher historical error rates, informed by Chapter 7 Topic 9-style evaluation data) — added complexity that should be justified by measured evidence the static threshold is leaving meaningful accuracy or cost improvements on the table.
- **Single encapsulated `genai_node` vs. exposing its internal tool-calling structure to the outer graph**: as discussed in Section 2, this project's current choice (encapsulation) is the right default until the outer graph genuinely needs to make routing decisions based on the GenAI stage's internal tool-calling behavior — a decision that should be revisited if such cross-cutting needs materialize, not preemptively over-engineered now.

---

### 6. Alternatives and When to Use Each

- **This project's rules → memory → ML → confidence-gates → GenAI → finalize graph structure**: the correct architecture for this project's actual cascade, balancing cost (cheap stages first) against accuracy (escalation only when needed) with explicit, tunable, testable gating logic.
- **A simpler two-stage cascade (skip ML, go straight from rules to GenAI)**: appropriate if MuRIL's specific accuracy/cost trade-off (Chapter 1's original baseline) doesn't justify its place in the cascade for this project's actual traffic patterns — a hypothesis that should be tested against real data (does removing the ML stage measurably hurt accuracy or increase GenAI escalation cost) rather than assumed either way.
- **A more granular, multi-level confidence-gated cascade (e.g. a fast, cheap embedding-similarity pre-check before even the rules stage)**: worth considering if evaluation data shows the current three-stage cascade still sends too many cases to the expensive GenAI stage unnecessarily — an even cheaper, coarser pre-filter could catch additional easy cases before reaching the rules stage, though this adds another stage's worth of complexity that should be justified by measured need.

---

### 7. Common Mistakes and Production Failures

- Burying confidence thresholds as unnamed magic numbers scattered through conditional logic rather than named, centrally-defined, easily-tunable constants.
- Not providing a safe fallback (like `requires_human_review`) for catastrophic failure of the most expensive, most complex stage (GenAI escalation), risking an undefined or crashed pipeline state for exactly the hardest, highest-stakes cases that reached this stage in the first place.
- Prematurely exposing the GenAI stage's internal tool-calling complexity to the outer graph as a full sub-graph, before any genuine cross-cutting routing need justifies that additional architectural complexity.
- Running expensive or unnecessary stages (like an unconditional memory lookup) without validating their actual cost/value trade-off against real production data.
- Not tracking `final_source` distribution in production, missing the direct, concrete signal needed to understand and optimize the cascade's actual cost and escalation behavior over time.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: What is a "confidence gate" in this project's graph, and why is it useful to name it explicitly as a distinct concept?**
A: A confidence gate is a conditional edge that decides whether to finalize the current stage's result or escalate to a more expensive stage, based on a confidence threshold (e.g. ML confidence exceeding 0.90). Naming it explicitly, with the threshold as a visible, centrally-defined constant, makes this decision point a tunable, testable, auditable part of the graph's structure — rather than a magic number buried inside conditional logic that's harder to locate, understand, and adjust based on evaluation evidence.

**Q: Why does this project's `genai_node` encapsulate `run_agent()`'s entire internal tool-calling loop as a single node, rather than exposing each tool call as its own node in the outer graph?**
A: The outer graph's decision-making (rules vs. ML vs. GenAI escalation) doesn't need visibility into which specific tools the GenAI stage calls internally — `run_agent()`'s own loop (Chapter 10 Topic 1) already correctly handles that internal complexity. Encapsulating it as one node keeps the outer graph focused on the cascade-level abstraction this chapter addresses, avoiding unnecessary complexity unless a genuine need arises for the outer graph to route based on the GenAI stage's internal tool-calling behavior.

**Intermediate:**

**Q: Why does `genai_node` have its own try/except fallback (`requires_human_review`) in addition to the error handling already inside `run_agent()`'s own tool-calling loop?**
A: `run_agent()`'s internal error handling (Chapter 10 Topic 4) handles failures of individual tool calls within its own loop, allowing the loop to continue or make a different decision. `genai_node`'s outer try/except handles a catastrophic failure of the ENTIRE `run_agent()` invocation itself — for instance, if the underlying Claude API call fails entirely, not just one tool within an otherwise-functioning loop. This is a different failure layer requiring its own handling, ensuring even a complete GenAI-stage failure doesn't crash the outer graph, instead routing to a safe human-review fallback.

**Q: How would you decide whether `memory_check` should continue running unconditionally at the start of every request, versus only when the cascade actually escalates to GenAI?**
A: This requires measuring, on real production data, how often sender history context would have changed the outcome for requests resolved at the cheap rules or ML stages versus only mattering for GenAI-escalated cases — if sender history rarely if ever changes a rules/ML-resolved outcome, moving the memory lookup to run only as part of GenAI escalation reduces unnecessary cost for the (likely majority) of quickly-resolved requests without a measurable accuracy cost. This is exactly the kind of architecture decision that should be validated with evidence rather than decided by the intuition that "more context is always better," following this project's consistent evaluation-driven discipline.

**Advanced:**

**Q: Design an evaluation methodology to determine the optimal value for `ML_CONFIDENCE_THRESHOLD`, balancing cost (GenAI escalation is expensive) against accuracy (a wrong ML-resolved decision has a real business cost too).**
A: Build a labeled evaluation set (extending Chapter 2's classification evaluation methodology) covering a representative range of ML confidence values, with ground-truth correct labels for each case. Sweep the threshold across a range of candidate values (e.g. 0.80, 0.85, 0.90, 0.95) and for each, compute both the resulting accuracy (does the ML-resolved subset at this threshold actually match ground truth reliably) and the escalation rate (what fraction of cases would be sent to the more expensive GenAI stage at this threshold) — plotting these together reveals the actual cost-accuracy trade-off curve for this specific corpus, rather than assuming any particular threshold value is universally correct. The final choice should weigh the measured accuracy loss from a lower threshold against the measured cost savings from reduced GenAI escalation, ideally translated into concrete business terms (cost per avoided escalation vs. cost of an incorrect ML-resolved classification) to make the trade-off decision explicit and defensible.

**Q: A stakeholder asks why this project doesn't simply always use the most accurate stage (GenAI) for every single email, given it presumably produces the best individual classification quality. How do you respond?**
A: This conflates individual-case accuracy with overall system design — while GenAI likely does produce the most accurate result for any single case given its full tool access and reasoning capability, using it for every email at this project's production volume (8,000-12,000 emails/day) would incur dramatically higher cost and latency for the large fraction of cases that the cheap rules or ML stages already resolve correctly and confidently. The cascade's entire design principle — established since Chapter 1 — is to reserve the most expensive, most capable stage for genuinely hard cases where its additional capability provides real, needed value, while resolving easy cases cheaply and quickly. This mirrors a well-established engineering principle: optimize for the common case cheaply, and pay extra cost only where it's genuinely earning its keep, validated through the confidence-gate thresholds' evaluation-driven tuning rather than defaulting to "always use the best available tool" regardless of cost.

**Scenario-based:**

**Q: Production monitoring shows the `final_source: "genai"` rate has crept up from 5% to 15% of all requests over several months, with no corresponding change to the rules or ML stage's own logic. Diagnose.**
A: This pattern — rising escalation rate with no upstream logic changes — suggests either the incoming email distribution has shifted (new phrasing patterns, new products per Chapter 9 Topic 8's ongoing scenario, that the rules and ML stages weren't trained or tuned to handle confidently) or a subtle regression in the rules or ML stage's own performance (perhaps a keyword list going stale, per Chapter 7 Topic 5's maintenance discussion, or model drift in MuRIL's underlying assumptions about the input distribution). Investigate by sampling recent GenAI-escalated cases and checking whether they share a common pattern (a specific new product name, a specific phrasing style) that the rules/ML stages should arguably have caught but didn't — this points to either a keyword-list update need or a case for re-evaluating and potentially retraining the ML stage against more recent, representative data, following the same evidence-based diagnostic process established throughout this project's evaluation-driven chapters.

---

### 9. Hidden Concepts and Prerequisites

- **This topic is a direct application of general "fail fast, escalate only when needed" cost-optimization architecture**, a pattern common well beyond LLM systems — caching layers, circuit breakers, and tiered service architectures in general distributed systems engineering all apply the same core principle of resolving requests as cheaply as possible and reserving expensive resources for genuinely hard cases.
- **The distinction between individual-case optimality and system-level optimality** (raised in the stakeholder interview question) is a recurring theme in engineering trade-off discussions generally — a locally "best" choice for any single case doesn't necessarily produce the best overall system design once cost, latency, and volume are considered holistically, a mental model valuable well beyond this specific project.
- **This connects directly forward to Topics 4-5 of this chapter**: Topic 4 goes deeper on the conditional routing logic itself (when an email should skip GenAI entirely, generalizing beyond just confidence thresholds), and Topic 5 runs this complete graph against real emails from the dataset, providing the empirical validation this topic's design choices call for throughout.

---

### 10. Revision Summary

> The complete graph assembles Topic 2's nodes (`memory_check`, `rules_check`, `ml_check`, `genai_escalation`, `finalize`) with explicitly named, tunable confidence gates as conditional edges — making the cascade's cost-vs-accuracy trade-off points visible, testable structure rather than buried magic numbers. `genai_node` encapsulates `run_agent()`'s entire internal tool-calling complexity (Chapter 10 Topic 1) as a single node from the outer graph's perspective, appropriate until a genuine need arises for the outer graph to route based on internal tool-calling behavior specifically. A dedicated failure fallback (`requires_human_review`) protects against catastrophic failure of the most expensive, highest-stakes stage, ensuring the pipeline degrades gracefully rather than crashing or producing an undefined result. Whether the memory lookup should run unconditionally at the start (this project's current choice, per Chapter 10 Topic 5's guidance) or only as part of GenAI escalation is a genuine, evidence-requiring trade-off between cost (paid on every request) and value (context that may only matter for the hardest, escalated cases) — exactly the kind of decision this project's evaluation-driven discipline should resolve with real production data, not assumption.

---
