# Chapter 12: Agent Orchestration with LangGraph

## Topic 1: Why a Graph Instead of Nested If/Else — Mapping Your Existing Cascade onto Nodes and Edges

---

### 1. Concept, Intuition, and Why It Exists

- This project's actual classification pipeline, built up chapter by chapter, is already a cascade: `classify_by_keyword_rules()` (Chapter 1's rules layer) runs first; if it can't confidently decide, MuRIL (the ML layer) runs; if confidence is still low, the GenAI agent (`run_agent()`, Chapters 3, 9, 10, 11) runs with its full tool-calling capability. This cascade currently lives as nested conditional logic — `if rule_result is not None: return rule_result; elif ml_confidence > threshold: return ml_result; else: run_agent(...)` — a structure that works, but becomes harder to reason about, test, and modify as more stages, conditions, and tools accumulate (exactly the tool-count and complexity growth already flagged in Chapter 10 Topic 5).
- **LangGraph** (or the general "agent as a graph" pattern it implements) represents this same cascade as an explicit graph: **nodes** are units of work (a rules check, an ML classification, a GenAI agent call, a tool call), and **edges** are the transitions between them, including **conditional edges** that decide which node runs next based on the current state. This is not a different capability from nested if/else — it is a different *representation* of the same control flow, chosen because that representation has specific engineering advantages as complexity grows.
- Why this deserves to replace nested conditionals specifically once complexity crosses a threshold: nested if/else scales poorly in *readability* and *testability* as the number of branches grows — a five-level-deep nested conditional with several conditions at each level becomes difficult to trace by reading, difficult to test exhaustively (many branch combinations), and difficult to modify safely (adding a new branch risks breaking an existing one in a way that's not obvious from a glance). A graph makes the *same* logic explicit and inspectable as a structure you can enumerate, visualize (conceptually, even without a rendered diagram), and test node-by-node.

---

### 2. Internal Working — Step by Step

**Mapping this project's actual cascade onto graph concepts, precisely:**

1. **State**: a single, evolving data structure (a Python dict or a defined schema) that flows through every node — for this project, this would carry the email text, sender metadata, the rule-engine's verdict (if any), the ML model's confidence and prediction (if computed), any GenAI/tool-call results, and the final classification — every node reads from and writes to this shared state, rather than passing scattered individual arguments between nested function calls.
2. **Nodes**: each stage of the cascade becomes one node — a `rules_node` (runs `classify_by_keyword_rules()`), an `ml_node` (runs MuRIL inference), a `genai_node` (runs the full `run_agent()` tool-calling loop), and a `finalize_node` (produces the final output). Each node is a self-contained function: takes the current state, does its specific work, returns an updated state.
3. **Edges**: the connections between nodes — a simple edge unconditionally moves from one node to the next; a **conditional edge** evaluates the current state (e.g. "did the rules node produce a confident verdict?") and decides which node to go to next, replacing what would have been an `if/elif` branch in the nested-conditional version.
4. **The graph's entry and exit points**: a defined start node (where every request begins — the `rules_node`, given this project's cascade always starts with the cheapest check) and one or more end states (a `finalize_node` producing the final classification, reached via different paths depending on which stage's output was confident enough to stop early).

**Why this specific representation change helps, mechanically:**

- **Explicit, enumerable structure**: the full set of possible paths through the cascade (rules-only, rules-then-ML, rules-then-ML-then-GenAI, etc.) becomes a property of the graph's structure itself, inspectable by listing nodes and edges, rather than something you'd need to trace through nested conditional logic to discover.
- **Node-level testability**: because each node is a self-contained function operating on a well-defined state schema, it can be unit tested in isolation (give it a specific state, check the state it returns) — directly extending the same node-level testing rigor Chapter 10 Topic 6 established for individual tools, now applied to pipeline stages themselves.
- **Modification safety**: adding a new stage (say, a new intermediate confidence check) means adding a new node and rewiring a few edges — a change that's structurally visible and doesn't require re-reading and re-verifying a long nested conditional chain to ensure the new branch doesn't interfere with existing ones.

---

### 3. How It Is Implemented in This Project

```python
# BEFORE: this project's cascade as nested conditional logic (conceptually,
# what has existed implicitly since Chapter 1's rules + Chapter 2's ML
# + later chapters' GenAI layer)

def classify_email_nested(email_text: str, sender_email: str) -> dict:
    rule_result = classify_by_keyword_rules(email_text)
    if rule_result is not None and rule_result != "ambiguous":
        return {"label": rule_result, "source": "rules"}

    ml_prediction, ml_confidence = run_muril_classifier(email_text)
    if ml_confidence > 0.90:
        return {"label": ml_prediction, "source": "ml"}

    # Low confidence from both cheap stages -- escalate to the full GenAI agent
    genai_result = run_agent(email_text, sender_email)
    return {"label": genai_result["label"], "source": "genai"}


# AFTER: the SAME logic, represented as an explicit graph (using LangGraph's
# actual API conventions -- StateGraph, add_node, add_conditional_edges)

from langgraph.graph import StateGraph, END
from typing import TypedDict, Optional

class EmailClassificationState(TypedDict):
    """The SHARED state every node reads from and writes to -- replaces
    the scattered local variables (rule_result, ml_confidence, etc.)
    the nested-conditional version used."""
    email_text: str
    sender_email: str
    rule_result: Optional[str]
    ml_prediction: Optional[str]
    ml_confidence: Optional[float]
    genai_result: Optional[dict]
    final_label: Optional[str]
    final_source: Optional[str]


def rules_node(state: EmailClassificationState) -> EmailClassificationState:
    """Node 1: exactly Chapter 1's classify_by_keyword_rules(), now
    wrapped to read/write the SHARED state instead of taking/returning
    a bare string."""
    result = classify_by_keyword_rules(state["email_text"])
    return {**state, "rule_result": result}


def ml_node(state: EmailClassificationState) -> EmailClassificationState:
    """Node 2: MuRIL inference, same wrapping pattern."""
    prediction, confidence = run_muril_classifier(state["email_text"])
    return {**state, "ml_prediction": prediction, "ml_confidence": confidence}


def genai_node(state: EmailClassificationState) -> EmailClassificationState:
    """Node 3: the full run_agent() tool-calling loop (Chapters 3, 9-11)."""
    result = run_agent(state["email_text"], state["sender_email"])
    return {**state, "genai_result": result}


def finalize_node(state: EmailClassificationState) -> EmailClassificationState:
    """Node 4: picks whichever stage's result is authoritative, based on
    which stages actually ran and produced a confident answer."""
    if state.get("rule_result") not in (None, "ambiguous"):
        return {**state, "final_label": state["rule_result"], "final_source": "rules"}
    if state.get("ml_confidence", 0) > 0.90:
        return {**state, "final_label": state["ml_prediction"], "final_source": "ml"}
    return {**state, "final_label": state["genai_result"]["label"], "final_source": "genai"}


def route_after_rules(state: EmailClassificationState) -> str:
    """CONDITIONAL EDGE -- replaces the nested `if rule_result is not None`
    branch. Returns the NAME of the next node to visit."""
    if state.get("rule_result") not in (None, "ambiguous"):
        return "finalize"
    return "ml_check"


def route_after_ml(state: EmailClassificationState) -> str:
    """CONDITIONAL EDGE -- replaces the nested `elif ml_confidence > 0.90` branch."""
    if state.get("ml_confidence", 0) > 0.90:
        return "finalize"
    return "genai_escalation"


# Building the graph: nodes plus conditional edges, mirroring the
# nested-conditional version's EXACT logic, now as explicit structure
graph = StateGraph(EmailClassificationState)
graph.add_node("rules_check", rules_node)
graph.add_node("ml_check", ml_node)
graph.add_node("genai_escalation", genai_node)
graph.add_node("finalize", finalize_node)

graph.set_entry_point("rules_check")
graph.add_conditional_edges("rules_check", route_after_rules, {"finalize": "finalize", "ml_check": "ml_check"})
graph.add_conditional_edges("ml_check", route_after_ml, {"finalize": "finalize", "genai_escalation": "genai_escalation"})
graph.add_edge("genai_escalation", "finalize")
graph.add_edge("finalize", END)

compiled_graph = graph.compile()
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **The graph representation adds a real, upfront learning and setup cost**: for a cascade as simple as this project's current three-stage version, nested if/else is genuinely simpler to write and understand at a glance — the graph's value proposition specifically depends on complexity that justifies the added structure, and adopting it prematurely for a genuinely simple cascade is real, avoidable overhead, echoing this project's consistent evidence-before-architecture-change discipline (Chapter 11 Topic 3's identical reasoning about MCP adoption timing).
- **State schema design becomes a first-class concern**: unlike scattered local variables in nested conditional code, the graph's `EmailClassificationState` TypedDict is now an explicit contract every node must respect — this is genuinely more disciplined (Chapter 10 Topic 3's schema-design rigor, now applied to pipeline state rather than tool arguments) but also a new thing to design correctly and maintain as the pipeline evolves.
- **Debugging a graph-based pipeline requires tracing state across nodes**: instead of stepping through nested conditional branches in a debugger, you now trace how the shared state object changes as it flows through each node — LangGraph provides built-in tracing/visualization support for this, but it's a genuinely different debugging mental model than following nested if/else branches directly in code.
- **Latency**: representing the cascade as a graph does not inherently change its latency — the same nodes execute in the same order for the same inputs; the graph is a structural change, not a performance change. Any perceived latency difference should be attributed to the underlying node implementations, not the graph structure itself.
- **Monitoring**: a graph-based pipeline naturally supports per-node monitoring (how often does each node run, how long does each node take, what's each node's output distribution) — a monitoring granularity that's harder to achieve cleanly from nested conditional code without significant additional instrumentation scattered throughout the branches.
- **Cost**: no direct cost difference from the graph representation itself — the same underlying operations (rule check, ML inference, GenAI call) cost the same regardless of how the control flow connecting them is expressed.
- **Security**: no direct security implications from choosing graph representation over nested conditionals — this is a control-flow and code-organization decision, orthogonal to the security considerations already established for the underlying nodes' operations (tool access scoping, PII handling, etc., from Chapters 9-11).

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **When does this project's cascade complexity actually justify migrating from nested conditionals to a graph?**: the honest answer, applying this project's consistent evidence-based discipline, is: not necessarily yet, for the three-stage cascade shown above — that specific logic is genuinely simple enough that nested conditionals remain clear and maintainable. The graph representation earns its complexity once the cascade grows further — additional confidence-gating stages, additional tool-calling branches, or once Chapter 10's growing toolset (Topic 5's six-tool scenario) starts requiring genuinely complex conditional routing that nested if/else would make hard to follow.
- **Full graph migration vs. incremental adoption**: exactly like Chapter 11 Topic 3's MCP adoption reasoning, migrating the entire pipeline to LangGraph all at once is a bigger, riskier change than adopting it incrementally — starting with the graph representation for the most complex part of the cascade (likely the GenAI/tool-calling portion, which already has real branching complexity per Chapter 9's retrieval-trigger and Chapter 10's multi-tool sequencing work) while leaving the simpler rules-and-ML prefix as straightforward conditional code, is a reasonable incremental path.
- **State schema granularity**: should the shared state carry every intermediate detail (raw rule-engine keyword matches, raw ML logits, etc.) or just the minimal decision-relevant summary at each stage? A more granular state aids debugging (more visibility into what happened at each stage) at the cost of a larger, more complex state schema to design and maintain — this project's `EmailClassificationState` example leans toward capturing decision-relevant summaries (predictions, confidence, results) rather than every raw intermediate value, a reasonable default that can be expanded if debugging needs prove it insufficient.

---

### 6. Alternatives and When to Use Each

- **Nested if/else (this project's current, actual implementation)**: appropriate for a cascade of this project's current complexity — three to four stages, straightforward confidence-threshold-based branching — where the control flow remains easy to read and reason about directly in code.
- **A graph-based orchestration framework like LangGraph (this topic's subject)**: appropriate once the cascade's complexity — number of stages, number of conditional branches, number of tools with complex sequencing needs (Chapter 10 Topic 5) — genuinely exceeds what nested conditionals can represent clearly, and once the benefits of node-level testability, explicit state management, and built-in tracing/visualization tooling become concretely valuable rather than theoretical.
- **A simpler custom state-machine implementation, without adopting a full framework**: a middle ground — implementing the same node/edge/state concepts as plain Python classes and dictionaries, without LangGraph's specific API and tooling, gains some of the structural clarity benefits without the dependency on and learning curve of a full framework — appropriate if the team wants the conceptual benefits of explicit graph structure without committing to LangGraph specifically, though this sacrifices LangGraph's built-in tracing, persistence, and visualization tooling that come with framework adoption.

---

### 7. Common Mistakes and Production Failures

- Migrating a genuinely simple cascade to a graph-based framework prematurely, paying real setup and learning-curve cost for a structural benefit the current complexity doesn't yet need.
- Designing an overly granular or overly sparse state schema without deliberate thought — too granular becomes unwieldy to maintain; too sparse loses the debugging visibility that's one of the graph representation's core benefits.
- Not unit testing individual nodes in isolation, missing the node-level testability benefit that's one of the graph representation's strongest justifications.
- Conflating "using LangGraph" with "the pipeline is now inherently better" — the graph is a representation choice, not a capability upgrade; the underlying nodes' correctness (the rules, the ML model, the GenAI agent) matters exactly as much as it did before.
- Not accounting for the genuine cost of the migration itself (rewriting existing, working nested-conditional logic into graph form) when deciding whether the migration is currently worthwhile.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: What is the fundamental difference between representing a cascade as nested if/else versus as a graph with nodes and edges?**
A: They express the same control flow, but nested if/else embeds the branching logic directly and implicitly within code structure, while a graph makes nodes (units of work) and edges (including conditional edges deciding what runs next) explicit, first-class, enumerable structures. This doesn't change what the cascade computes — it changes how legible, testable, and modifiable that computation's structure is as complexity grows.

**Q: Why might migrating this project's current three-stage cascade (rules, ML, GenAI) to LangGraph be premature?**
A: The current cascade's logic — three stages, simple confidence-threshold branching — remains clear and maintainable as nested conditional code. LangGraph's benefits (explicit state schema, node-level testability, built-in tracing) come with real setup and learning-curve costs that are better justified once the cascade's complexity genuinely exceeds what nested conditionals can represent clearly, following this project's consistent evidence-before-architecture-change principle.

**Intermediate:**

**Q: What is the "state" in a graph-based pipeline, and how does it differ from the scattered local variables used in a nested-conditional implementation?**
A: State is a single, well-defined, shared data structure that flows through every node, with each node reading relevant fields and writing its own results back into it — a genuine, versioned schema (like the `EmailClassificationState` TypedDict) rather than an implicit collection of local variables passed between nested function calls. This makes the full set of data available at any point in the pipeline explicit and inspectable, rather than requiring you to trace through nested scopes to understand what's available where.

**Q: How does a graph representation improve testability compared to nested conditional logic, concretely?**
A: Each node is a self-contained function with a well-defined input (the current state) and output (an updated state), meaning it can be unit tested by constructing a specific input state and asserting on the returned state — directly analogous to Chapter 10 Topic 6's tool-testing methodology, now applied to pipeline stages. Testing a specific branch of nested conditional logic in isolation typically requires either extracting that branch into its own function first (effectively recreating a node) or testing the entire nested structure end-to-end, which conflates the specific branch's correctness with the surrounding control flow's correctness.

**Advanced:**

**Q: Design the criteria for deciding whether a specific new addition to this project's pipeline (e.g. Chapter 10 Topic 5's `lookup_product_catalog` and `check_sender_history` tools, with their sequencing complexity) should push this project toward LangGraph adoption.**
A: The concrete trigger is whether the branching logic required to correctly sequence and conditionally invoke this project's growing toolset (Chapter 9's retrieval triggering, Chapter 10's multi-tool sequencing) has grown complex enough that nested conditionals require deep nesting levels or many interacting conditions to express correctly — a proxy metric worth tracking is simply counting the cyclomatic complexity (the number of independent branching paths) of the current nested-conditional implementation, and treating a number that's become hard to reason about or test exhaustively as the evidence-based signal to migrate, rather than migrating based on tool count alone, since tool count and branching complexity don't necessarily scale together.

**Q: A teammate argues that LangGraph should be adopted from the very start of any new agentic project, regardless of initial complexity, since it will be needed eventually anyway. How do you evaluate this argument?**
A: This is the same "adopt now for anticipated future need" argument already addressed for MCP (Chapter 11 Topic 3) and should be evaluated with the same rigor — adopting a framework before its structural benefits are needed pays real, avoidable setup and learning-curve costs immediately for benefits that are speculative until the pipeline's actual complexity grows to justify them. For a genuinely simple initial cascade, nested conditionals are more direct and require no new framework knowledge; migrating once complexity genuinely demands it is a well-defined migration (as this project's Section 3 code demonstrates, the underlying node logic — `classify_by_keyword_rules()`, `run_muril_classifier()`, `run_agent()` — doesn't need to change, only how they're wired together), making early adoption's "avoid a future migration" argument less compelling than it might first appear, since the actual migration cost is concentrated in re-wiring control flow, not rewriting core logic.

**Scenario-based:**

**Q: Six months after adopting LangGraph for this project's cascade, a new team member finds the graph-based implementation harder to understand at first glance than the original nested conditional version would have been, despite the pipeline's complexity genuinely having grown to justify the migration. How do you address this?**
A: This is a real, known trade-off of graph-based representations — while they scale better for genuinely complex control flow and offer superior testability and tooling, they do require learning a new mental model (nodes, edges, shared state) that isn't necessary for understanding simple nested conditionals. The right response isn't necessarily reverting the migration (if the complexity genuinely justifies it) but investing in clear documentation of the graph's structure (which nodes exist, what each does, how conditional edges route between them) and possibly a visual diagram (even if not rendered directly in version-controlled Markdown due to this project's git-rendering constraints, a diagram could be maintained separately, e.g. in a wiki or generated on demand) to help new team members build the necessary mental model faster — treating this as an onboarding and documentation investment the migration's complexity justifies, not evidence the migration itself was wrong.

---

### 9. Hidden Concepts and Prerequisites

- **This topic is a direct application of general finite state machine (FSM) and workflow orchestration concepts** — long predating LangGraph or agentic AI specifically, state machines and directed graphs are foundational computer science structures for representing control flow, used in everything from compiler design to business process management systems; LangGraph is a domain-specific (agentic AI) implementation of these much older, general ideas.
- **Cyclomatic complexity**, mentioned in the advanced interview answer above, is a formally defined, measurable software metric (the number of linearly independent paths through a program's control flow) — worth knowing this exists as an actual, calculable number (not just an intuitive feeling of "this code is getting complicated") that can inform exactly this kind of architecture-migration decision with real evidence rather than subjective judgment alone.
- **This connects directly forward to Topics 2-5 of this chapter**, which build out the concrete state schema, node implementations, and conditional routing logic for this project's actual pipeline in full depth — this topic deliberately stayed at the conceptual "why" level, with those following topics providing the complete "how."

---

### 10. Revision Summary

> A graph-based representation (nodes for units of work, edges — including conditional edges — for transitions between them, and a shared state flowing through every node) expresses the same control flow as nested if/else, but as an explicit, enumerable structure rather than implicit code nesting. This project's current cascade (rules → ML → GenAI escalation) is simple enough that nested conditionals remain clear, making immediate LangGraph adoption a real but currently unjustified cost — the migration earns its complexity once the cascade's branching logic (driven by Chapter 9's retrieval triggering and Chapter 10's growing, multi-tool sequencing complexity) genuinely exceeds what nested conditionals can represent clearly. The concrete benefits once that threshold is crossed: node-level unit testability (mirroring Chapter 10 Topic 6's tool-testing discipline), an explicit, versioned state schema replacing scattered local variables, and built-in tracing/visualization tooling for debugging a multi-stage pipeline. The underlying node logic (the rule engine, the ML classifier, the GenAI agent) does not need to change during this migration — only how these pieces are wired together changes, which is precisely why this represents a control-flow refactor, not a capability upgrade.

---
