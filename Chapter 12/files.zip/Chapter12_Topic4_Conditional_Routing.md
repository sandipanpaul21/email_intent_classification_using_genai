# Chapter 12: Agent Orchestration with LangGraph

## Topic 4: Conditional Routing — Deciding When an Email Skips GenAI Entirely

---

### 1. Concept, Intuition, and Why It Exists

- Topic 3 built confidence gates as the primary routing mechanism (rule-engine confidence, ML confidence). This topic generalizes conditional routing beyond simple confidence thresholds: are there *other*, non-confidence-based signals that should determine whether an email skips the expensive GenAI stage entirely, or conversely, whether an email should skip the cheap stages and go *straight* to GenAI regardless of what the rules/ML stages would have said?
- The core insight this topic adds: confidence-based routing (Topic 3) assumes the cheap stages' own confidence signal is the right basis for the escalation decision — but there are other, genuinely different signals worth routing on: explicit business rules (a known VIP customer segment always gets GenAI's more thorough handling, regardless of classification confidence), safety/compliance triggers (certain keywords or patterns — a mention of legal action, a regulatory complaint — should always escalate to GenAI or even directly to human review, regardless of how "confident" the cheap stages are), and cost-control circuit breakers (if GenAI escalation volume is unexpectedly spiking, a routing rule could temporarily raise the bar for escalation to protect against a cost runaway).
- Why this deserves its own topic distinct from Topic 3's confidence gates: these are *qualitatively different* routing signals — not "how confident is the cheap stage" but "are there other reasons, independent of confidence, to route this specific case differently" — and conflating them into one undifferentiated routing function would make the graph's decision logic harder to understand and maintain, exactly the clarity problem Topic 1 argued the graph representation should solve.

---

### 2. Internal Working — Step by Step

**Three distinct categories of non-confidence-based routing signals:**

1. **Bypass-to-GenAI triggers (skip the cheap stages entirely)**: certain patterns in the email should route directly to the full GenAI agent regardless of what a cheap rule or ML check might say — e.g. specific compliance-sensitive keywords ("legal action," "ombudsman," "regulatory complaint") where the business risk of a cheap-stage misclassification is high enough that skipping straight to the most capable, most auditable (via tool-use tracing, Chapter 10 Topic 6) stage is justified regardless of cost.
2. **Bypass-GenAI-entirely triggers (never escalate, even if confidence is low)**: certain patterns should be routed to a fixed fallback (e.g. an automatic "this appears to be spam/irrelevant" classification, or a direct human-review queue) without ever invoking the expensive GenAI stage, even if the rules/ML stages report low confidence — for instance, a detected pattern strongly associated with spam or abuse, where GenAI's sophisticated reasoning capability adds no value and its cost is simply wasted.
3. **Cost-control circuit breakers**: a dynamic, system-level check — not based on this specific email's content at all, but on the *aggregate* recent rate of GenAI escalations — that can temporarily tighten the routing criteria (effectively raising the ML confidence threshold, or routing a higher fraction of borderline cases to human review instead of GenAI) if escalation volume is spiking unexpectedly, protecting against a cost runaway from, for instance, an unusual influx of genuinely hard cases or a bug in the confidence-scoring logic itself.

**How these integrate into the graph structure from Topic 3:**

- Bypass-to-GenAI and bypass-GenAI-entirely triggers are implemented as **additional conditional edges evaluated early** in the graph (potentially even before the rules stage, since their triggering logic doesn't depend on the rules/ML stages' own output) — these are genuinely separate decision points from the confidence gates, evaluated independently.
- The cost-control circuit breaker is implemented as a **stateful, cross-request check** — unlike the other routing signals, which depend only on the current request's own state, this depends on aggregate, recent system-wide behavior (a count of recent escalations, tracked outside any single request's state) — a genuinely different kind of state than the per-request `EmailClassificationState` schema from Topic 2, requiring its own separate tracking mechanism (e.g. a simple in-memory counter with a time window, or a more robust distributed rate-limiting store at production scale).

---

### 3. How It Is Implemented in This Project

```python
import time
import re

# -----------------------------------------------------------------------
# BYPASS-TO-GENAI: compliance-sensitive patterns that should always
# get the most capable, most auditable handling, regardless of what
# cheap-stage confidence would suggest
# -----------------------------------------------------------------------
COMPLIANCE_SENSITIVE_PATTERNS = re.compile(
    r"\b(legal action|ombudsman|regulatory complaint|consumer court|lawsuit)\b", re.IGNORECASE
)

def check_compliance_bypass(state: EmailClassificationState) -> bool:
    """Returns True if this email should SKIP the cheap stages entirely
    and go straight to GenAI, regardless of confidence considerations."""
    return bool(COMPLIANCE_SENSITIVE_PATTERNS.search(state["email_text"]))


# -----------------------------------------------------------------------
# BYPASS-GENAI-ENTIRELY: patterns where GenAI's capability adds no value
# and its cost should never be paid, even at low cheap-stage confidence
# -----------------------------------------------------------------------
SPAM_PATTERNS = re.compile(r"\b(click here now|guaranteed winner|act immediately)\b", re.IGNORECASE)

def check_spam_bypass(state: EmailClassificationState) -> bool:
    """Returns True if this email should NEVER escalate to GenAI,
    routing instead to a fixed fallback regardless of confidence."""
    return bool(SPAM_PATTERNS.search(state["email_text"]))


# -----------------------------------------------------------------------
# COST-CONTROL CIRCUIT BREAKER: stateful, cross-request tracking --
# genuinely DIFFERENT from per-request state (Topic 2's schema)
# -----------------------------------------------------------------------
class EscalationRateTracker:
    """Tracks recent GenAI escalation rate across ALL requests, not just
    the current one -- a SEPARATE kind of state from EmailClassificationState,
    since it persists and aggregates ACROSS requests, not within one."""

    def __init__(self, window_seconds: int = 300, max_escalations_in_window: int = 500):
        self.window_seconds = window_seconds
        self.max_escalations_in_window = max_escalations_in_window
        self.escalation_timestamps = []

    def record_escalation(self) -> None:
        self.escalation_timestamps.append(time.time())
        self._prune_old_entries()

    def _prune_old_entries(self) -> None:
        cutoff = time.time() - self.window_seconds
        self.escalation_timestamps = [t for t in self.escalation_timestamps if t > cutoff]

    def is_circuit_breaker_active(self) -> bool:
        """Returns True if escalation rate is abnormally high -- if so,
        routing should temporarily become MORE conservative about
        sending additional cases to GenAI."""
        self._prune_old_entries()
        return len(self.escalation_timestamps) >= self.max_escalations_in_window


escalation_tracker = EscalationRateTracker()


# -----------------------------------------------------------------------
# INTEGRATED ROUTING LOGIC -- combining confidence gates (Topic 3) with
# these NEW, qualitatively different routing signals
# -----------------------------------------------------------------------

def early_bypass_check(state: EmailClassificationState) -> str:
    """Evaluated BEFORE the rules stage even runs -- these bypass
    decisions don't depend on rules/ML output at all."""
    if check_compliance_bypass(state):
        return "genai_escalation"  # skip straight to GenAI
    if check_spam_bypass(state):
        return "spam_fallback"     # never reaches GenAI at all
    return "rules_check"           # normal cascade proceeds as usual


def confidence_gate_2_ml_with_circuit_breaker(state: EmailClassificationState) -> str:
    """Extends Topic 3's confidence_gate_2_ml with the cost-control
    circuit breaker -- if escalation rate is abnormally high, raise
    the effective bar for escalation."""
    effective_threshold = ML_CONFIDENCE_THRESHOLD
    if escalation_tracker.is_circuit_breaker_active():
        effective_threshold = 0.75  # LOWER bar to finalize at ML stage,
                                      # i.e. HARDER to escalate to GenAI,
                                      # during a circuit-breaker event
    if state.get("ml_confidence", 0) > effective_threshold:
        return "finalize"
    escalation_tracker.record_escalation()
    return "genai_escalation"


def spam_fallback_node(state: EmailClassificationState) -> EmailClassificationState:
    """A FIXED fallback for spam-bypassed emails -- no GenAI cost paid."""
    return {**state, "final_label": "Non-FD", "final_source": "spam_bypass",
            "final_reason": "Matched spam pattern, routed without GenAI escalation",
            "nodes_visited": state["nodes_visited"] + ["spam_fallback_node"]}
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **Bypass rules need the same evidence-based maintenance discipline as `fd_keyword_groups.txt`**: `COMPLIANCE_SENSITIVE_PATTERNS` and `SPAM_PATTERNS` are keyword/regex-based, exactly like Chapter 1's rule engine, and inherit the same brittleness concerns already discussed at length in Chapter 7 Topic 5 — these lists need periodic review against real production patterns, not a one-time setup.
- **False positives on compliance bypass have a real, asymmetric cost profile**: incorrectly triggering the compliance bypass (routing a normal email to GenAI unnecessarily) wastes cost but causes no correctness harm. Incorrectly triggering the *spam* bypass (routing a genuine, legitimate customer email to the fixed fallback because it happened to match a spam pattern) is a real correctness failure with direct customer impact — this asymmetry should inform how conservatively each bypass rule is tuned, favoring precision (avoiding false positives) much more strongly for the spam bypass than for the compliance bypass, where a false positive is merely a cost inefficiency, not a customer-harming error.
- **The circuit breaker introduces genuinely new operational complexity**: unlike the per-request routing logic, `EscalationRateTracker` is stateful across requests and, in a real multi-instance production deployment (multiple agent processes handling concurrent traffic), this state needs to be shared or coordinated across instances (a distributed rate-limiter, e.g. backed by Redis) rather than each instance tracking its own local, incomplete view of the aggregate escalation rate — a local-only tracker like the one shown would only see a fraction of total system-wide escalations in a multi-instance deployment, undermining the circuit breaker's actual protective value.
- **Monitoring**: track bypass-rule trigger rates (compliance bypass, spam bypass) as distinct metrics from the standard confidence-gate-driven escalation rate — a spike in spam-bypass triggers might indicate a new spam campaign targeting this NBFC's customer-facing email address, worth flagging to security/abuse teams independent of the classification pipeline's own concerns. Also monitor circuit-breaker activation frequency — frequent activation suggests either the `max_escalations_in_window` threshold is mis-tuned for actual normal traffic patterns, or there's a genuine, recurring issue causing abnormal escalation spikes worth investigating at its root cause rather than just being absorbed by the circuit breaker repeatedly.
- **Cost**: the circuit breaker is specifically a cost-protection mechanism — its value is directly in preventing a runaway cost scenario (e.g. a bug causing every email to report low ML confidence, escalating the entire day's volume to GenAI unexpectedly) from becoming a full-blown budget incident before human intervention can occur.
- **Security**: the spam-bypass pattern list could, in principle, be probed or reverse-engineered by an adversary sending crafted emails to learn what triggers automatic non-GenAI handling — a low-severity but real information-disclosure-adjacent concern worth being aware of, though the practical risk for this project's specific use case (an NBFC support inbox) is likely low.
- **Deployment**: the circuit breaker's stateful tracking needs its own deployment consideration — restarting the agent application would reset a purely in-memory tracker's history, potentially masking an ongoing escalation spike right after a deployment; a persistent or shared tracking store avoids this gap.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **Where in the graph should bypass checks be evaluated — before the rules stage, or interleaved with confidence gates?**: this project's design evaluates bypass checks *before* the rules stage entirely, since their triggering logic is independent of what the rules/ML stages would say — this is the cleaner, more efficient design (avoiding wasted work running the rules/ML stages for an email that will bypass them anyway), though it does mean these bypass checks run on every single request as an additional, first-pass cost, which should itself be lightweight (as the regex-based checks shown are) to avoid adding meaningful overhead to every request.
- **Static bypass pattern lists vs. a more sophisticated, learned bypass classifier**: static regex/keyword patterns (this project's approach) are simple, fast, auditable, and directly maintainable using the same evidence-based process as `fd_keyword_groups.txt` — a more sophisticated approach could train a small, fast classifier specifically for "should this bypass to/from GenAI" as its own binary decision, potentially generalizing better to phrasing variations a static pattern list would miss, at the cost of needing labeled training data and its own evaluation/maintenance overhead. Given this project's consistent preference for starting simple and escalating complexity only when evidence justifies it, static patterns are the correct starting point.
- **Circuit breaker threshold tuning**: `max_escalations_in_window = 500` (in the illustrative code) is a placeholder that must be calibrated against this project's actual normal escalation rate and volume patterns — set too low, and the circuit breaker triggers during entirely normal traffic variation, unnecessarily degrading service quality; set too high, and it fails to protect against a genuine cost-runaway scenario before significant, unwanted cost has already been incurred. This calibration should be based on historical escalation-rate data (Topic 3's `final_source` distribution tracking provides exactly this data) rather than an arbitrary guess.

---

### 6. Alternatives and When to Use Each

- **No non-confidence-based routing, relying solely on Topic 3's confidence gates (a simpler baseline)**: appropriate for an initial deployment before evidence of a genuine need for compliance-sensitive bypass routing or cost-runaway protection has accumulated — not recommended as a permanent state once this project reaches production scale, given the real, asymmetric risks (a missed compliance-sensitive email handled by a cheap, less capable stage; an unprotected cost-runaway scenario) that these additional routing mechanisms specifically guard against.
- **Static keyword/regex-based bypass rules (this project's approach)**: the correct starting point, directly reusing the same maintenance discipline already established for `fd_keyword_groups.txt`.
- **A learned bypass classifier**: worth considering once static patterns prove measurably insufficient (a labeled evaluation set showing static rules miss too many genuine compliance-sensitive or spam cases) — a natural escalation path, not a default starting choice.
- **A distributed, production-grade circuit breaker (e.g. backed by Redis) vs. this project's illustrative in-memory tracker**: the in-memory version is appropriate only for single-instance deployments or early prototyping; any genuine multi-instance production deployment requires the shared, distributed version to make the circuit breaker's protection actually effective across the full system's aggregate behavior.

---

### 7. Common Mistakes and Production Failures

- Setting the spam-bypass pattern list too aggressively, causing genuine customer emails to be misrouted to a fixed fallback without ever receiving proper classification — a real correctness failure with direct customer impact, given the asymmetric cost of false positives discussed in Section 4.
- Implementing the circuit breaker as purely local, in-memory state in a multi-instance production deployment, giving each instance an incomplete view of aggregate system-wide escalation rate and undermining its protective purpose.
- Not monitoring bypass-rule trigger rates as their own distinct metrics, missing early signals of new spam campaigns or emerging compliance-sensitive patterns the current pattern lists don't yet cover.
- Setting circuit-breaker thresholds arbitrarily without calibrating against actual historical escalation-rate data, leading to either false-alarm triggering during normal variation or insufficient protection against genuine cost-runaway scenarios.
- Not treating bypass pattern lists with the same evidence-based, ongoing maintenance discipline established for `fd_keyword_groups.txt`, letting them go stale as language patterns and spam tactics evolve over time.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: What is the difference between Topic 3's confidence gates and this topic's bypass routing?**
A: Confidence gates route based on how confident a cheap stage's own output is (e.g. ML confidence exceeding a threshold) — they're a within-cascade decision based on the classification signal itself. Bypass routing decides to skip stages entirely based on signals independent of classification confidence — compliance-sensitive keywords warranting the most capable handling regardless of confidence, or spam patterns where no amount of GenAI capability would add value, or system-wide cost-control concerns unrelated to any single email's content.

**Q: Why is a false positive on the spam-bypass rule considered more serious than a false positive on the compliance-bypass rule?**
A: A compliance-bypass false positive (a normal email incorrectly triggering escalation straight to GenAI) wastes cost but causes no correctness harm — the email still gets a proper, capable classification, just via a more expensive path than strictly necessary. A spam-bypass false positive (a genuine customer email incorrectly routed to a fixed, non-classified fallback) is a real correctness failure — that customer's actual question or issue never receives proper handling at all, a direct customer-impacting error that should be avoided far more conservatively.

**Intermediate:**

**Q: Why must a production-grade escalation-rate circuit breaker use shared, distributed state rather than each agent instance's own local, in-memory counter?**
A: In a multi-instance production deployment handling concurrent traffic, each instance only sees the requests it personally handles — a local counter would dramatically undercount the true aggregate escalation rate across the whole system, meaning the circuit breaker could fail to activate even during a genuine system-wide cost-runaway event, since no single instance's local view would show the full picture. Shared, distributed state (e.g. backed by Redis) is necessary for the circuit breaker to actually reflect and protect against system-wide behavior, not just one instance's fraction of it.

**Q: How would you decide the correct threshold for `max_escalations_in_window` in the circuit breaker?**
A: This should be calibrated against actual historical escalation-rate data from this project's `final_source` distribution tracking (Topic 3) — establishing what a normal, expected escalation rate and its typical variance look like over comparable time windows, then setting the threshold high enough to avoid triggering during ordinary traffic fluctuation, but low enough to catch a genuine, abnormal spike before it causes significant unwanted cost. This is fundamentally the same evidence-based threshold-tuning discipline applied to Topic 3's `ML_CONFIDENCE_THRESHOLD`, now applied to a system-level rather than per-request signal.

**Advanced:**

**Q: Design the monitoring and alerting strategy specifically for this topic's bypass and circuit-breaker mechanisms, distinct from the standard cascade monitoring established in Topic 3.**
A: Track bypass-rule trigger rates (compliance bypass, spam bypass) as time-series metrics with alerting on significant deviations from historical baseline — a spike in spam-bypass triggers warrants a different investigation (potential spam campaign, worth flagging to security/abuse response) than a spike in compliance-bypass triggers (potentially a new regulatory concern pattern emerging among genuine customers, worth flagging to compliance/legal teams). Track circuit-breaker activation events explicitly, with each activation logged alongside the actual escalation-rate data that triggered it, enabling post-incident review of whether the threshold is well-calibrated or needs adjustment. Critically, ensure circuit-breaker activation itself generates an alert to the engineering team, since a temporarily raised escalation bar during an active circuit-breaker period represents a real, if deliberate and protective, degradation in service quality (some borderline cases that would normally escalate to GenAI are being resolved less capably during this period) that engineers should be aware is happening, not a silent, invisible background adjustment.

**Q: A stakeholder proposes adding many more bypass rules for various specific business scenarios (VIP customers, specific complaint types, seasonal promotional periods) directly into this routing logic. How do you evaluate scaling this approach?**
A: Each additional bypass rule adds to the routing logic's overall complexity, and if implemented as more ad hoc conditional checks layered onto the existing `early_bypass_check` function, risks recreating the exact "hard to read, test, and maintain" problem Topic 1 argued the graph representation should solve in the first place — a proliferation of bypass conditions could itself become an unmanageable nested-conditional structure, just relocated to a different part of the pipeline. I'd evaluate whether each new bypass rule is genuinely a distinct routing signal deserving its own conditional edge and clear naming (following this topic's established pattern), versus whether several related business rules could be consolidated into a more general, data-driven routing mechanism (e.g. a lookup table mapping specific business conditions to routing decisions, rather than an ever-growing sequence of individual regex checks) — a genuine architectural decision that should be revisited as the number of distinct bypass conditions grows, mirroring Chapter 10 Topic 5's discussion of when tool-count growth justifies a more sophisticated architecture.

**Scenario-based:**

**Q: The circuit breaker activates during a genuine traffic surge (e.g. following a marketing campaign driving increased customer inquiries), temporarily raising the bar for GenAI escalation and causing some borderline cases to be resolved less capably by the ML stage than they otherwise would have been. How do you evaluate whether this was the right trade-off?**
A: This requires distinguishing whether the circuit breaker did its intended job (protecting against a cost-runaway that would have been genuinely problematic) versus whether it triggered on a traffic pattern that was actually fine to handle at normal escalation rates, just higher in absolute volume. If the marketing campaign genuinely drove up the *rate* of hard, low-confidence cases (not just overall volume), the circuit breaker's protective trade-off was likely correct — some degraded accuracy on borderline cases during a temporary spike is a reasonable cost to avoid a much larger, uncontrolled cost overrun. If the campaign primarily drove up volume of genuinely easy, high-confidence cases (which shouldn't have been triggering escalation heavily in the first place), the circuit breaker's threshold may be miscalibrated relative to overall volume rather than genuine escalation rate specifically — worth investigating whether the threshold should be defined relative to a rate (escalations per total requests) rather than an absolute count, which would naturally scale with legitimate volume increases without unnecessarily triggering during them.

---

### 9. Hidden Concepts and Prerequisites

- **The circuit breaker pattern is a well-established, general distributed systems reliability concept**, directly borrowed from software engineering practices for protecting systems against cascading failures or resource exhaustion — this project's cost-control application is a specific instance of a much more general pattern used throughout production software engineering.
- **The asymmetric-cost-of-errors framing** (spam bypass false positives being worse than compliance bypass false positives) connects to decision theory and cost-sensitive classification concepts generally — recognizing that not all classification errors carry equal cost, and that routing/threshold decisions should account for this asymmetry explicitly rather than treating all errors as equivalent, is a valuable, transferable analytical framework beyond this specific application.
- **This connects directly forward to Topic 5**, which runs the complete graph — including all of this topic's bypass and circuit-breaker logic — against real emails from this project's dataset, providing the empirical grounding needed to actually calibrate the thresholds and pattern lists this topic introduces conceptually.

---

### 10. Revision Summary

> Conditional routing beyond Topic 3's confidence gates addresses three qualitatively different signals: bypass-to-GenAI (compliance-sensitive patterns warranting the most capable handling regardless of cheap-stage confidence), bypass-GenAI-entirely (spam or low-value patterns where GenAI's capability adds no value, requiring conservative tuning given the asymmetric cost of a false positive misrouting a genuine customer email), and cost-control circuit breakers (a stateful, cross-request mechanism protecting against escalation-rate runaways, requiring shared/distributed state in any genuine multi-instance production deployment, not local in-memory tracking). All three integrate into the graph structure from Topic 3 as additional conditional edges, evaluated early (before the rules stage) for the per-request bypass checks, and as a dynamic threshold adjustment for the circuit breaker. Static, keyword/regex-based bypass rules mirror the same evidence-based maintenance discipline already established for `fd_keyword_groups.txt`, and every threshold introduced here (circuit breaker limits, effective confidence thresholds during circuit-breaker activation) should be calibrated against real historical data rather than arbitrary defaults, following this project's consistent evaluation-driven engineering discipline.

---
