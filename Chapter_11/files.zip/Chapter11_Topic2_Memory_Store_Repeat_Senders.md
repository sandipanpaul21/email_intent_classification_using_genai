# Chapter 11: Memory in Agents + Model Context Protocol (MCP)

## Topic 2: Implementing a Memory Store for Repeat Senders

---

### 1. Concept, Intuition, and Why It Exists

- Topic 1 established the architectural distinction between short-term and long-term memory conceptually, with `LONG_TERM_MEMORY_STORE` as a placeholder Python dict. This topic is where that placeholder becomes a genuine, production-viable data store — schema design, indexing, concurrency handling, and the specific query patterns `check_sender_history` and the distillation write-path actually need.
- Why this deserves its own topic separate from Topic 1's conceptual treatment: "use a database" is not a complete answer — the *schema* (what fields, what types, what relationships), the *access pattern* (how this data gets read and written, at what frequency, by how many concurrent processes), and the *specific data-store technology* (a relational table vs. a document store vs. a key-value cache) are all real engineering decisions with consequences, directly analogous to the schema-design rigor Chapter 10 Topic 3 applied to tool schemas.
- The concrete motivating number, repeated from this project's own EDA throughout this project: 14% of senders are repeat senders. At production volume (8,000-12,000 emails/day, per Chapter 9 Topic 8's scenario), this means roughly 1,100-1,700 repeat-sender interactions per day — a real, non-trivial volume of reads against this memory store, alongside a write on every single conversation's completion (since distillation runs regardless of whether the sender turns out to be a repeat sender later).

---

### 2. Internal Working — Step by Step

**Schema design for the memory store:**

1. **Primary key**: sender email address (normalized — lowercased, whitespace-trimmed — to avoid the classic bug of `Customer@Example.com` and `customer@example.com` being treated as different keys).
2. **Per-interaction record fields**: date/timestamp, distilled topic summary, the classification label from that interaction (FD/Non-FD/Multiple Category — already computed during the original conversation, free to store alongside the summary), and optionally a reference to the specific FD account discussed if one was involved (linking back to `validate_fd_reference`'s data, without duplicating the full FD record itself).
3. **One-to-many relationship**: one sender can have many interaction records — this is a genuine one-to-many relational pattern, not a single flat record per sender, since the whole point is tracking a *history* of interactions, not just the most recent one.

**The specific access patterns to design for:**

1. **Write pattern**: one insert per completed conversation, asynchronously (Topic 1's design decision), keyed by sender email — a simple, high-frequency, low-complexity write.
2. **Read pattern**: `check_sender_history`'s lookup — given a sender email, fetch their most recent N interaction records, ordered by date — a simple, indexed, low-latency read that must complete quickly since it sits on the agent's tool-calling critical path (unlike the write, which is asynchronous).
3. **Retention/cleanup pattern**: periodically (not per-request), older records beyond some retention window might be archived or deleted — a batch, low-frequency operation, distinct from the per-request read/write patterns above.

---

### 3. How It Is Implemented in This Project

```python
import sqlite3
from datetime import datetime

def initialize_memory_store(db_path: str = "sender_memory.db") -> None:
    """Sets up the schema. SQLite is used here for local development
    simplicity -- production would use a real networked database
    (PostgreSQL, etc.), but the SCHEMA DESIGN principles are identical
    regardless of the underlying engine."""
    conn = sqlite3.connect(db_path)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sender_interactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender_email TEXT NOT NULL,
            interaction_date TEXT NOT NULL,
            topic_summary TEXT NOT NULL,
            classification_label TEXT,
            fd_reference_number TEXT
        )
    """)
    # INDEX on sender_email -- this is THE query pattern check_sender_history
    # uses, and without an index, this lookup degrades to a full table scan
    # as the table grows, exactly the kind of missing-index problem
    # Chapter 6 Topic 4 already flagged for Qdrant's payload filtering
    conn.execute("CREATE INDEX IF NOT EXISTS idx_sender_email ON sender_interactions(sender_email)")
    conn.commit()
    conn.close()


def write_interaction_record(sender_email: str, topic_summary: str,
                              classification_label: str = None, fd_reference_number: str = None,
                              db_path: str = "sender_memory.db") -> None:
    """The WRITE path -- called asynchronously after distillation (Topic 1)."""
    conn = sqlite3.connect(db_path)
    conn.execute(
        "INSERT INTO sender_interactions (sender_email, interaction_date, topic_summary, "
        "classification_label, fd_reference_number) VALUES (?, ?, ?, ?, ?)",
        (sender_email.strip().lower(), datetime.now().isoformat(), topic_summary,
         classification_label, fd_reference_number),
    )
    conn.commit()
    conn.close()


def check_sender_history(sender_email: str, limit: int = 3, db_path: str = "sender_memory.db") -> dict:
    """The READ path -- must be FAST since it's on the agent's tool-calling
    critical path (unlike the write, which is async)."""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT interaction_date, topic_summary, classification_label FROM sender_interactions "
        "WHERE sender_email = ? ORDER BY interaction_date DESC LIMIT ?",
        (sender_email.strip().lower(), limit),
    ).fetchall()
    conn.close()

    if not rows:
        return {"is_repeat_sender": False, "previous_interaction_count": 0}

    # Get the TOTAL count separately -- the LIMIT above only fetched the
    # most recent N for the topics list, but the customer may have MORE
    # total interactions than we're displaying
    conn = sqlite3.connect(db_path)
    total_count = conn.execute(
        "SELECT COUNT(*) FROM sender_interactions WHERE sender_email = ?",
        (sender_email.strip().lower(),),
    ).fetchone()[0]
    conn.close()

    return {
        "is_repeat_sender": True,
        "previous_interaction_count": total_count,
        "previous_topics": [row["topic_summary"] for row in rows],
        "last_interaction_date": rows[0]["interaction_date"],
    }
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **The missing-index mistake, made concrete**: without `idx_sender_email`, `check_sender_history`'s query degrades from an indexed lookup (fast, roughly constant time regardless of table size) to a full table scan (linear in the total number of interaction records across ALL senders) — at this project's production volume, the table grows by thousands of rows per day, meaning an unindexed lookup would get progressively, measurably slower over time, exactly the kind of silent performance degradation that's easy to miss in early testing (small table, scan is fast) and painful in production (large table, scan is slow).
- **Email normalization edge cases**: `Customer@Example.com`, `customer@example.com `, and `CUSTOMER@EXAMPLE.COM` must all resolve to the same memory-store key — the `.strip().lower()` normalization shown above handles the common cases, but real email addresses have subtler equivalence issues (e.g. `customer+tag@example.com` vs `customer@example.com`, which some email providers treat as the same inbox) that a production system may need a more sophisticated normalization strategy for, depending on how customers actually interact with this NBFC's support channels.
- **Concurrent write handling**: SQLite (used for local simplicity above) has real concurrency limitations under high write volume from multiple simultaneous processes — a production deployment handling 8,000-12,000 emails/day with potentially many concurrent agent instances needs a database engine designed for concurrent access (PostgreSQL, MySQL, or a managed cloud database), not SQLite's simpler, more limited concurrency model.
- **Monitoring**: track query latency for `check_sender_history` specifically as the table grows over time (confirming the index is actually working as expected, not silently degrading), track write failure rate for the asynchronous distillation-write path, and track table growth rate to inform retention policy decisions before storage becomes a genuine cost or performance concern.
- **Cost**: at scale, this is a real, if modest, ongoing database infrastructure cost (storage plus query volume) — distinct from and additional to the LLM API costs discussed throughout this project, worth tracking as its own budget line as the table grows into the millions of rows over years of operation.
- **Security**: this table is customer PII (email addresses, topic summaries potentially referencing sensitive account details) — it requires the same access controls, encryption at rest, and audit logging considerations Chapter 6 Topic 9 established for the FD customer records collection, and should never be treated as "just an internal cache" exempt from those requirements simply because it's derived/distilled data rather than the original structured records.
- **Deployment**: schema migrations (adding a new field to `sender_interactions` later, for instance) need a real migration strategy once this table has production data in it — unlike early development where `CREATE TABLE IF NOT EXISTS` is sufficient, a live table with real customer history needs proper schema versioning and migration tooling to evolve safely.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **SQLite vs. a networked database, even for this project's current scale**: SQLite is genuinely fine for local development and even modest production scale with a single server instance, but its concurrency model becomes a real limitation the moment multiple agent processes need concurrent write access — this project should treat the choice of SQLite here as explicitly a development-stage convenience, with a clear, anticipated migration path to a networked database (mirroring Chapter 6 Topic 10's "honest migration trigger" framework, now applied to this specific data store rather than the vector database).
- **Relational (one row per interaction) vs. document-style (one JSON blob per sender containing an array of interactions)**: the relational design shown above makes querying (e.g. "how many total interactions," "most recent N") straightforward via standard SQL, and scales cleanly as interaction counts grow. A document-store design (one record per sender, with an embedded array of interactions) can be simpler for very small interaction counts per sender but becomes awkward for queries needing to filter, sort, or paginate within that array, and document size grows unboundedly per sender without a separate retention mechanism — the relational design is the more conventional, more scalable choice for this project's access patterns.
- **Storing the classification label and FD reference number alongside the summary vs. keeping this table purely about the distilled text summary**: including these structured fields (as shown) makes some queries much more efficient (e.g. "find all past FD-related interactions for this sender" without needing to parse the summary text) at the cost of a slightly more complex schema and the discipline of keeping these fields correctly populated during the write path — a worthwhile trade-off given how directly useful structured filtering is for this project's actual use case.

---

### 6. Alternatives and When to Use Each

- **SQLite (this project's development-stage choice)**: appropriate for local development, prototyping, and even small-scale single-instance production deployments — not appropriate once multiple concurrent agent instances need reliable concurrent write access.
- **A managed relational database (PostgreSQL, MySQL, or a cloud-managed equivalent)**: the correct production choice once concurrency, scale, or operational reliability requirements exceed what SQLite comfortably provides — directly analogous to Chapter 6's discussion of migrating from in-memory Qdrant to a persistent, networked deployment.
- **A key-value store or cache (Redis, etc.) layered in front of the primary database**: worth considering specifically if `check_sender_history`'s read latency becomes a measured bottleneck at very high query volume — a cache holding recent lookups can reduce database load, at the cost of a cache-invalidation strategy (ensuring the cache reflects a customer's latest interaction promptly after it's written) that adds real complexity, appropriate only once genuinely justified by measured latency or database load concerns.

---

### 7. Common Mistakes and Production Failures

- Not indexing the `sender_email` column, causing query performance to silently degrade as the table grows, invisible in early testing with a small table.
- Inconsistent email normalization, causing the same real customer to appear as multiple different "senders" in the memory store due to case or whitespace variations.
- Using SQLite in a production deployment with genuine concurrent write load from multiple agent instances, risking write conflicts or degraded performance under concurrency SQLite isn't designed to handle at scale.
- Not having a retention or archival policy, allowing the table to grow indefinitely without bound as years of customer interactions accumulate.
- Treating this memory store as exempt from the PII governance and access-control requirements applied to the primary customer database, simply because it holds "derived" or "distilled" data rather than original records.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: Why is an index on `sender_email` critical for this table's performance?**
A: `check_sender_history`'s core query pattern is "find all interactions for this specific sender" — without an index on that column, the database must scan every row in the entire table to find matches, an operation whose cost grows linearly with total table size. With an index, this lookup is roughly constant-time regardless of how large the table grows, which matters enormously given this table accumulates thousands of new rows daily at this project's production volume.

**Q: Why does the schema use a relational design (one row per interaction) rather than storing an array of interactions in a single row per sender?**
A: The relational design makes standard SQL operations (counting total interactions, fetching the most recent N, filtering by classification label or date range) straightforward and efficient using the database's native indexing and query capabilities. A document-style design with an embedded array per sender would require parsing and filtering within that array for the same operations, which is less efficient and more awkward as interaction counts per sender grow, and doesn't naturally support standard database indexing on individual interaction fields.

**Intermediate:**

**Q: Why is SQLite explicitly flagged as a development-stage choice rather than this project's final production database technology?**
A: SQLite's concurrency model is more limited than networked database engines like PostgreSQL — it's well-suited to a single process accessing the database file, but genuine concurrent write access from multiple simultaneous agent instances (a realistic production requirement at this project's volume) can hit real limitations. This mirrors the same "honest migration trigger" reasoning from Chapter 6 Topic 10 — SQLite is the correct choice today given current scale and development-stage needs, with a clear, anticipated path to a networked database once concurrency or scale genuinely demands it, rather than either prematurely over-engineering with a networked database before it's needed, or ignoring the eventual need entirely.

**Q: How would you handle the email normalization edge case where a customer uses `customer+support@example.com` in one interaction and `customer@example.com` in another, if their email provider treats these as the same inbox?**
A: This requires understanding the actual email normalization rules relevant to this NBFC's customer base — if plus-addressing is a common pattern among customers, the normalization function should strip the `+tag` portion before the `@` symbol as part of standard normalization, in addition to the existing lowercase/whitespace handling. This is a data-quality investigation question as much as a coding question — before implementing broader normalization rules, I'd want evidence (from real customer email patterns) that this specific case actually occurs meaningfully often enough to justify the added normalization complexity and its own edge cases (some legitimate use cases DO rely on plus-addressing distinguishing different purposes for the same inbox).

**Advanced:**

**Q: Design a retention and archival policy for this memory store, considering both storage cost and the PII governance implications of retaining customer interaction history indefinitely.**
A: A reasonable policy: retain full-detail interaction records for an active window (e.g. the most recent 2-3 years, aligned with typical regulatory retention requirements for financial services communications, which should be confirmed with compliance/legal rather than assumed), after which records older than the window are either deleted entirely or further compressed into a coarser, less detailed summary (e.g. "customer had N interactions before [date], details archived/purged") that retains awareness a relationship history exists without retaining the specific granular content indefinitely. This should run as a periodic batch job (not per-request), and critically, must be coordinated with any explicit right-to-be-forgotten deletion requests, which should take precedence over the standard retention window and remove data immediately upon request rather than waiting for the next scheduled archival run.

**Q: A teammate proposes denormalizing this schema by storing a JSON blob of the customer's full FD record (from Chapter 6's structured database) directly alongside each interaction record, to avoid a separate lookup when displaying history. Evaluate this proposal.**
A: This trades query convenience (avoiding a join or separate lookup) for data staleness risk and storage duplication — the customer's FD record (status, amount) can change after the interaction record is written (e.g. their FD later matures or is closed), meaning a denormalized copy embedded in the interaction record would show stale, incorrect data if ever displayed later, unlike a live lookup via `validate_fd_reference` which always reflects current state. Storing only the `fd_reference_number` (as shown in the actual schema) and performing a live lookup when current status is needed avoids this staleness problem entirely, at the modest cost of an additional lookup when that current data is actually needed — the correct trade-off here favors correctness over the marginal query-convenience savings, especially given FD status is exactly the kind of field that legitimately changes over time.

**Scenario-based:**

**Q: In production, `check_sender_history` query latency has been growing steadily over several months, now measurably impacting overall agent response time. Diagnose and propose a fix.**
A: First, confirm the index on `sender_email` still exists and is being used by the query planner (some database engines can silently stop using an index under certain conditions, like severe table bloat or outdated statistics) — this is the first, cheapest thing to check given growing latency on an indexed lookup is unusual if the index is healthy. If the index is confirmed healthy and the issue is genuinely query volume or table size outgrowing the current database's capacity, this is the concrete evidence needed to justify migrating from SQLite (if still in use) to a networked database engine better suited to the current scale, following the honest-migration-trigger discipline from Chapter 6 Topic 10 — corpus/table growth alone isn't sufficient justification, but MEASURED, confirmed latency degradation that persists after ruling out simpler fixes (like a missing or degraded index) is exactly the kind of evidence that justifies the migration investment.

---

### 9. Hidden Concepts and Prerequisites

- **This topic is a direct, hands-on application of relational database schema design and indexing fundamentals** — normalization, primary/foreign key relationships, and index design are foundational database engineering skills, not LLM-specific concepts, and this topic demonstrates them in service of a genuinely LLM-agent-specific use case.
- **The concurrency limitations of SQLite versus networked databases connect to broader distributed systems concepts** (write locks, connection pooling, transaction isolation levels) that become increasingly relevant as this project's infrastructure matures beyond single-instance deployment — worth knowing these exist as a deeper layer beneath "just pick a database" that a Lead-level engineer should be able to reason about when genuinely needed.
- **This connects directly forward to Chapter 19's Observability & Guardrails and Chapter 20's Security & Responsible AI chapters** — this topic's PII governance concerns for the memory store are a specific, concrete instance of the data residency and audit trail requirements those later chapters will formalize at a whole-system level.

---

### 10. Revision Summary

> Implementing a real memory store for repeat senders requires genuine schema design: a relational table (one row per interaction, not a document blob per sender) keyed by normalized sender email, indexed on that key for fast lookup, with fields for the distilled topic summary plus structured metadata (classification label, referenced FD number) that make common queries efficient without needing to parse free text. SQLite is an appropriate development-stage choice but has real concurrency limitations that necessitate migration to a networked database (PostgreSQL or equivalent) once production concurrency and scale genuinely demand it — an honest-migration-trigger decision, not a premature one. The write path (asynchronous, after distillation) and read path (`check_sender_history`, synchronous and latency-sensitive since it's on the agent's tool-calling critical path) have genuinely different performance and reliability requirements. This table is customer PII requiring the same access control, encryption, and right-to-be-forgotten governance as the primary structured customer database — an easy thing to overlook since it holds "derived" rather than "original" data, but subject to identical regulatory and ethical obligations.

---
