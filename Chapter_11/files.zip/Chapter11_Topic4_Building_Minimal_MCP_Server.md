# Chapter 11: Memory in Agents + Model Context Protocol (MCP)

## Topic 4: Building a Minimal MCP Server Wrapping Your Tools

---

### 1. Concept, Intuition, and Why It Exists

- Topic 3 explained MCP conceptually. This topic makes it real: building an actual, working MCP server that exposes `validate_fd_reference` (chosen as the example — Chapter 10 Topic 2's already-well-designed, well-tested tool) as a standardized MCP tool, runnable and connectable by any MCP-compatible client, not just this project's own `run_agent()` loop.
- The core engineering task: take the existing, tightly-coupled tool wrapper (`validate_fd_reference()` Python function plus its Anthropic-specific `input_schema` dict) and re-express it using the MCP SDK's server-building conventions — registering the tool's name, description, and schema in MCP's own format, and wiring the actual backing logic (which, thanks to Chapter 10 Topic 2's separation-of-concerns design, is *already* cleanly separated as `get_fd_record()`) into the MCP server's tool-handling mechanism.
- Why this project's Chapter 10 Topic 2 design pays off directly here: because `get_fd_record()` was kept as pure, tool-calling-agnostic data access logic, wrapping it in an MCP server requires zero changes to that core logic — only a new, thin adapter layer (the MCP server itself) needs to be written, exactly the payoff of good separation-of-concerns design becoming concrete in a new context.

---

### 2. Internal Working — Step by Step

1. **Install and initialize an MCP server using the official SDK** (Python's `mcp` package) — this provides the scaffolding for handling MCP's protocol-level concerns (discovery requests, tool invocation requests, message formatting) so you don't need to implement JSON-RPC message handling from scratch.
2. **Register each tool** with the server, providing its name, description, and input schema in MCP's expected format (a JSON Schema-based `inputSchema`, structurally similar to but not identical in field-naming convention to Anthropic's `input_schema`).
3. **Implement the tool's handler function** — the actual Python code that runs when the server receives an invocation request for this tool. This is where `get_fd_record()` gets called, wrapped with the same defensive validation and structured response shaping Chapter 10 Topics 2 and 4 already established.
4. **Run the server**, typically over stdio for local development and testing (the simplest transport, appropriate for a single-machine setup where the client and server run as separate processes on the same machine) — Topic 5 covers actually connecting a client to this running server.

---

### 3. How It Is Implemented in This Project

```python
# validate_fd_reference_mcp_server.py
# A minimal, real MCP server exposing validate_fd_reference as a standardized tool.

import asyncio
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent
import json
import re

# -----------------------------------------------------------------------
# REUSED, UNCHANGED from Chapter 10 Topic 2 -- this is the entire payoff
# of that chapter's separation-of-concerns design: zero changes needed
# to the core data access and validation logic to expose it via MCP.
# -----------------------------------------------------------------------
FAKE_FD_DATABASE = {
    "BJ2019FD7717": {"status": "Closed (Premature)", "fd_amount_inr": 391000, "maturity_date": "2021-11-28"},
    "BJ2021FD4432": {"status": "Active", "fd_amount_inr": 250000, "maturity_date": "2024-06-15"},
}

REFERENCE_NUMBER_PATTERN = re.compile(r"^[A-Z]{2}\d{4}FD\d{4,}$")


def get_fd_record(reference_number: str) -> dict:
    """UNCHANGED from Chapter 10 Topic 2 -- pure data access logic."""
    return FAKE_FD_DATABASE.get(reference_number)


def validate_fd_reference(reference_number: str) -> dict:
    """UNCHANGED from Chapter 10 Topic 2 -- the tool wrapper's core logic."""
    if not reference_number or len(reference_number.strip()) < 6:
        return {"found": False, "reason": "format_invalid"}

    cleaned = reference_number.strip().upper()
    if not REFERENCE_NUMBER_PATTERN.match(cleaned):
        return {"found": False, "reason": "format_invalid"}

    record = get_fd_record(cleaned)
    if record is None:
        return {"found": False, "reason": "not_in_system"}

    return {"found": True, "status": record["status"], "fd_amount_inr": record["fd_amount_inr"],
            "maturity_date": record.get("maturity_date")}


# -----------------------------------------------------------------------
# NEW: the MCP server layer -- this is what Topic 4 actually adds
# -----------------------------------------------------------------------
app = Server("fd-tools-server")


@app.list_tools()
async def list_tools() -> list[Tool]:
    """Handles MCP's discovery request -- 'what tools do you have?'
    This is the MCP-native equivalent of Anthropic's TOOLS list,
    but in MCP's own schema convention."""
    return [
        Tool(
            name="validate_fd_reference",
            description=(
                "Call this whenever text contains something that looks like an FD "
                "reference number, before relying on it. Returns found=False if no "
                "such reference exists in the system."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "reference_number": {"type": "string", "description": "The candidate FD reference number."}
                },
                "required": ["reference_number"],
            },
        )
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Handles MCP's invocation request -- 'call this tool with these args.'
    This is the MCP-native equivalent of run_agent()'s if/elif block.name
    dispatch logic from Chapter 3/Chapter 10 Topic 1."""
    if name == "validate_fd_reference":
        result = validate_fd_reference(arguments["reference_number"])
        return [TextContent(type="text", text=json.dumps(result))]

    raise ValueError(f"Unknown tool: {name}")


async def main():
    """Runs the server over stdio -- the simplest transport for local
    development, appropriate when client and server run as separate
    processes on the same machine (Topic 5 connects a real client)."""
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


if __name__ == "__main__":
    asyncio.run(main())
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **Testing an MCP server independently of any specific client**: because the server is now a genuinely separate process with a well-defined protocol interface, it can be tested by any MCP-compatible test client, or even manually via tools designed for MCP server inspection — a real testing benefit distinct from Chapter 10 Topic 6's agent-integration-level testing, since the server's correctness (does `list_tools()` return the right schema, does `call_tool()` return the right structured result) can be verified independently of any specific consuming agent.
- **Error handling inside the MCP server needs the same discipline as Chapter 10 Topic 4, now applied at the protocol boundary**: an unhandled exception inside `call_tool()` needs to be caught and translated into a well-formed MCP error response, not allowed to crash the server process or return a malformed response the client can't parse — the same "never let it propagate uncaught" principle from Chapter 10 Topic 4, now applied specifically at this new architectural layer.
- **Process lifecycle management**: unlike a Python function living inside this project's main application process, an MCP server run as a separate process needs its own lifecycle management — startup, health monitoring, restart-on-crash behavior — genuinely new operational concerns a tightly-coupled tool never required.
- **Schema translation fidelity**: MCP's `inputSchema` and Anthropic's `input_schema` are structurally similar (both JSON Schema-based) but any translation layer (which Topic 5's client will need) must be carefully tested to ensure no information is lost or subtly altered in translation — a schema that's correctly disambiguated in MCP's format (per Chapter 10 Topic 3's discipline) must remain equally well-disambiguated after translation into whatever format the actual consuming LLM API needs.
- **Monitoring**: track the MCP server's own health and request volume independently of the consuming agent's metrics — since multiple different clients could potentially connect to the same server (Topic 3's reuse motivation), server-level monitoring needs to aggregate across all consumers, not just this project's own agent's usage.
- **Cost and latency**: running this as a genuinely separate process, even locally over stdio, introduces measurable overhead compared to an in-process function call (Topic 3's flagged trade-off) — this should be benchmarked concretely for this project's specific case (how much slower is a stdio-based MCP tool call than a direct Python function call) rather than assumed negligible.
- **Security**: even for a local, stdio-based server (not yet exposed over a network), the server process itself has access to `FAKE_FD_DATABASE` (or the real production database in a real deployment) — the same access-scoping and least-privilege principles from Chapter 9 Topic 4 apply to designing what this server process can and cannot access, independent of how it's invoked.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **One MCP server per tool vs. one server exposing multiple related tools**: the example above builds a single-tool server for simplicity and clarity — a real deployment might group several related tools (e.g. all of this project's FD-database-touching tools) into one server, since they likely share the same underlying data access dependencies and deployment lifecycle, reducing the number of separate processes to manage. This is a genuine design choice, analogous to deciding service boundaries in a microservices architecture — grouped too broadly, and the server loses the benefit of independent versioning for genuinely separate concerns; grouped too narrowly, and the operational overhead of managing many tiny separate server processes compounds unnecessarily.
- **Stdio vs. HTTP/SSE transport, decided now even though Topic 5 focuses on stdio**: stdio is simplest for local, same-machine client-server communication (this project's likely first real use case, if reuse starts within the same infrastructure) — HTTP/SSE becomes necessary the moment a client needs to connect to a server running on a genuinely different machine, which is the actual cross-team, cross-system reuse scenario Topic 3 motivated MCP with in the first place. Building the stdio version first is a reasonable incremental step, but the transport choice should be revisited once genuine remote-access reuse needs materialize.

---

### 6. Alternatives and When to Use Each

- **Building on the official MCP SDK (this topic's approach)**: the correct default — reuses well-tested, protocol-compliant scaffolding rather than reimplementing JSON-RPC message handling and MCP's specific conventions from scratch, reducing the risk of subtle protocol-compliance bugs.
- **Implementing the MCP protocol from scratch, without the SDK**: only justified if the official SDK is unavailable for a required language/platform, or has a specific, documented limitation that requires a custom implementation — otherwise, an unnecessary reinvention of well-established, tested infrastructure.
- **Skipping MCP and directly exposing a tool via a simple custom REST API instead**: achieves some of the same decoupling and reuse benefit without adopting MCP's specific protocol conventions, appropriate if MCP-compatibility with the broader ecosystem of MCP clients isn't actually valuable for this project's specific reuse case — but loses the standardization benefit of using a protocol other MCP-aware tools and clients already understand out of the box.

---

### 7. Common Mistakes and Production Failures

- Duplicating or reimplementing `get_fd_record()`'s logic inside the MCP server rather than reusing the existing, already-tested function — losing the payoff of Chapter 10 Topic 2's separation-of-concerns design and creating two divergent implementations that could drift out of sync.
- Not handling exceptions inside `call_tool()`, allowing an unexpected error to crash the server process or return a malformed response that breaks client-side parsing.
- Treating the MCP server as a "fire and forget" process with no lifecycle monitoring, missing crashes or hangs that would silently make the tool unavailable to every connected client.
- Grouping too many unrelated tools into one MCP server for convenience, losing the independent versioning and deployment benefits that motivated the decoupling in the first place.
- Not benchmarking the actual latency overhead of the MCP layer before assuming it's negligible, risking an unexpected production performance regression when migrating a previously in-process tool.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: Why does building the MCP server for `validate_fd_reference` require zero changes to `get_fd_record()`'s implementation?**
A: Chapter 10 Topic 2 deliberately kept `get_fd_record()` as pure data access logic with zero coupling to any tool-calling mechanism — the MCP server is simply a new, thin adapter layer that calls this already-existing, already-tested function, exactly the payoff of that earlier separation-of-concerns design decision. If the original design had tightly coupled data access directly into the tool-calling wrapper, extracting it into an MCP server would have required real refactoring rather than just adding a new adapter on top.

**Q: What are `list_tools()` and `call_tool()`, and what MCP protocol operations do they correspond to?**
A: `list_tools()` handles MCP's discovery mechanism — when a client connects and asks "what capabilities does this server expose," this function returns the server's tool definitions (name, description, schema) in MCP's standardized format. `call_tool()` handles actual tool invocation — when a client requests a specific tool be run with specific arguments, this function executes the corresponding backing logic and returns a structured result, analogous to the `if/elif block.name ==` dispatch logic in this project's original `run_agent()` loop, but now handling MCP's protocol-level invocation format instead of Anthropic's `tool_use` blocks directly.

**Intermediate:**

**Q: Why must exceptions inside `call_tool()` be caught and translated into structured MCP error responses, rather than allowed to propagate?**
A: An uncaught exception could crash the entire server process, making every tool it exposes unavailable to every currently-connected client, not just failing the single request that triggered it — a much more severe blast radius than an equivalent failure in this project's original in-process tool-calling pattern, where an unhandled exception would at most break one request within one agent's process. This is Chapter 10 Topic 4's error-handling discipline, now applied with even higher stakes given the shared, multi-client nature of an MCP server.

**Q: Why is stdio an appropriate transport choice for this project's first MCP server implementation, and when would you need to switch to HTTP/SSE?**
A: Stdio (standard input/output) is the simplest transport for client-server communication when both processes run on the same machine — no networking, authentication, or exposure concerns beyond the local process boundary. It's appropriate for this project's likely first real use case (a different local process or tool wanting to reuse `validate_fd_reference`). HTTP/SSE becomes necessary the moment a client needs to connect from a genuinely different machine — the actual cross-team, cross-system reuse scenario that originally motivated MCP's adoption in Topic 3 — since stdio has no mechanism for communication across a network boundary.

**Advanced:**

**Q: Design the error-handling and response-shaping strategy for `call_tool()`, ensuring it's consistent with the structured error philosophy established in Chapter 10 Topic 4, now applied at the MCP protocol boundary.**
A: Wrap the entire tool dispatch logic in a try/except block distinguishing transient errors (worth retrying, per Chapter 10 Topic 4's categorization, though retry logic itself might live either in the server or be left to the client's discretion — a design choice worth being explicit about) from persistent errors (fail fast, report clearly). Any exception should be caught and converted into a structured `TextContent` response containing a JSON-encoded error object (mirroring this project's existing `{"found": False, "error": True, "error_type": ..., "message": ...}` pattern) rather than allowed to propagate and crash the server process or return a raw, unstructured MCP-level error that the client has no principled way to reason about programmatically. This ensures the same clean success/failure response shape consistency established at the tool-wrapper level (Chapter 10 Topic 2) is preserved at this new protocol boundary too.

**Q: A teammate proposes exposing five of this project's tools through one single MCP server for operational simplicity. What specific trade-offs would you want to discuss before agreeing?**
A: The main question is whether these five tools share a genuinely coherent deployment lifecycle and ownership boundary, or whether grouping them is purely for the convenience of managing fewer separate processes. If they're all tightly related (e.g. all touching the same underlying FD database, likely to be updated and deployed together), grouping into one server is reasonable and reduces operational overhead without meaningfully sacrificing the benefits of decoupling. If they're genuinely independent capabilities with different rates of change, different ownership, or different reuse patterns (some tools reused broadly, others used only by this one agent), grouping them loses the independent-versioning benefit that motivated extracting them into MCP servers in the first place — a change to one tool's implementation would force redeploying and potentially disrupting availability for all five, even the four unrelated ones. I'd want to understand each tool's actual expected change frequency and reuse pattern before agreeing to a specific grouping.

**Scenario-based:**

**Q: In production, the MCP server exposing `validate_fd_reference` crashes silently, and several minutes pass before anyone notices customer-facing requests are failing. Diagnose the monitoring gap and propose a fix.**
A: This indicates a missing process-health-monitoring layer specifically for the MCP server, distinct from whatever monitoring already exists for the main agent application — since the server is now a genuinely separate process (Section 4's point), its crash doesn't necessarily surface through the same application-level error monitoring that would catch a failure inside the main agent's own process. The fix requires dedicated health checks (a periodic ping or heartbeat confirming the server process is alive and responsive) with alerting configured to fire quickly on failure, plus an automated restart mechanism (a process supervisor) so transient crashes self-heal without requiring manual intervention — genuinely new operational infrastructure this project didn't need before tools lived as separate server processes, and a concrete illustration of Topic 3's flagged "genuine operational overhead" that MCP's architectural benefits must be weighed against.

---

### 9. Hidden Concepts and Prerequisites

- **This topic is a hands-on application of general client-server and remote procedure call (RPC) architecture principles** — the specific mechanics (discovery, invocation, structured request/response) mirror decades of established distributed systems practice, with MCP providing an LLM-tooling-specific standardization on top of these long-established patterns.
- **Process supervision and health monitoring (flagged in the scenario-based question) is itself a well-established operational discipline** (tools like systemd, supervisord, or container orchestration health checks in a Kubernetes deployment) — worth knowing this exists as a solved, general problem in production infrastructure, not something this project needs to invent uniquely for MCP servers specifically.
- **This connects directly forward to Topic 5**, which builds the client side of this exact server — connecting this project's actual agent to the MCP server built here, completing the full client-server loop this chapter's Topics 3-5 progressively build toward.

---

### 10. Revision Summary

> Building a minimal MCP server means wrapping an existing tool's backing logic (here, `validate_fd_reference`, reusing Chapter 10 Topic 2's already-separated `get_fd_record()` unchanged) with MCP's standardized `list_tools()` (discovery) and `call_tool()` (invocation) handlers, using the official MCP SDK rather than reimplementing the protocol from scratch. This project's earlier separation-of-concerns design (data access logic kept independent of tool-calling mechanics) pays off directly here — zero changes needed to the core logic, only a new adapter layer. Running the server over stdio is the simplest choice for local, same-machine client-server communication, with HTTP/SSE needed only once genuine cross-machine reuse materializes. Error handling inside `call_tool()` requires the same structured-response discipline as Chapter 10 Topic 4, now with higher stakes since an uncaught exception can crash a server shared across multiple clients, not just fail one request. New operational concerns — process lifecycle management, independent health monitoring, and deployment/versioning separate from the main application — are the genuine, concrete costs of this architecture that must be weighed against its reuse benefits, exactly as Topic 3 anticipated conceptually.

---
