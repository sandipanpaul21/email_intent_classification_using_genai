# Chapter 11: Memory in Agents + Model Context Protocol (MCP)

## Topic 5: Connecting an Agent to the MCP Server End to End

---

### 1. Concept, Intuition, and Why It Exists

- Topic 4 built a real, working MCP server. This topic is where that server becomes actually useful: modifying this project's existing `run_agent()` loop (Chapter 3, extended through Chapters 9-10) to act as an **MCP client** — discovering `validate_fd_reference` from the running server at startup, translating its MCP schema into Anthropic's `tools` format, and routing the actual tool invocation through the MCP client connection rather than calling a local Python function directly.
- The core engineering task, precisely stated: everywhere `run_agent()` previously had `elif block.name == "validate_fd_reference": result = validate_fd_reference(...)` — a direct, in-process function call — it now needs `elif block.name == "validate_fd_reference": result = await mcp_client.call_tool("validate_fd_reference", block.input)` — a call routed through the MCP client to the separate server process built in Topic 4.
- Why this is the natural completion of this chapter's MCP arc: Topic 3 explained why, Topic 4 built the server half, and this topic builds the client half and wires them together — only once both halves exist and are connected does this project actually realize any of MCP's promised decoupling and reuse benefits; a server with no client, or vice versa, delivers nothing.

---

### 2. Internal Working — Step by Step

1. **Establish an MCP client session at agent startup**: connect to the running MCP server (launched as a subprocess, communicating over stdio, per Topic 4's transport choice) — this connection is typically established once, when the agent application starts, not per-request, since establishing a fresh connection for every single tool call would reintroduce significant, avoidable latency overhead.
2. **Discover available tools from the server**: call the client's equivalent of `list_tools()` once at startup, retrieving the server's tool definitions in MCP's schema format.
3. **Translate MCP tool definitions into Anthropic's `tools` format**: MCP's `inputSchema` and Anthropic's `input_schema` are structurally compatible (both JSON Schema) but this translation step must be explicit and correct — this is exactly the kind of schema-fidelity concern Topic 4 flagged, now actually implemented.
4. **Modify `run_agent()`'s dispatch logic**: replace the direct Python function call for MCP-managed tools with an async call through the MCP client session, awaiting the server's response before continuing the loop — exactly as before mechanically (Chapter 10 Topic 1's tool_use → execute → tool_result cycle), just with the "execute" step now routed through a network/process boundary instead of an in-process function call.
5. **Handle the connection lifecycle correctly**: what happens if the MCP server process isn't running, crashes mid-conversation, or is slow to respond — this is Chapter 10 Topic 4's error-handling discipline, now specifically applied to the MCP client connection itself as a new potential failure point.

---

### 3. How It Is Implemented in This Project

```python
import asyncio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
import json

# -----------------------------------------------------------------------
# MCP CLIENT SETUP -- established ONCE at agent startup, reused across
# every subsequent tool call, not reconnected per-request
# -----------------------------------------------------------------------

async def create_mcp_client_session(server_script_path: str):
    """Launches the MCP server (Topic 4's script) as a subprocess and
    establishes a persistent client connection to it over stdio."""
    server_params = StdioServerParameters(command="python", args=[server_script_path])

    stdio_transport = await stdio_client(server_params).__aenter__()
    read_stream, write_stream = stdio_transport

    session = ClientSession(read_stream, write_stream)
    await session.initialize()
    return session


async def discover_and_translate_mcp_tools(session: ClientSession) -> list:
    """Discovers tools from the MCP server and translates MCP's schema
    format into Anthropic's tools format -- the exact translation step
    Topic 4 flagged as needing careful, correctness-verified implementation."""
    mcp_tools_response = await session.list_tools()

    translated_tools = []
    for mcp_tool in mcp_tools_response.tools:
        translated_tools.append({
            "name": mcp_tool.name,
            "description": mcp_tool.description,
            "input_schema": mcp_tool.inputSchema,  # structurally compatible, direct mapping
        })
    return translated_tools


# -----------------------------------------------------------------------
# MODIFIED run_agent() -- the SAME mechanical loop from Chapter 3/10 Topic 1,
# with ONE change: validate_fd_reference is now dispatched through the
# MCP client session instead of a direct in-process function call
# -----------------------------------------------------------------------

async def run_agent_with_mcp(email_text: str, mcp_session: ClientSession,
                              mcp_tools: list, other_local_tools: list,
                              client, model_id: str, max_steps: int = 5) -> dict:

    all_tools = mcp_tools + other_local_tools  # combined toolset, MCP + still-local tools
    messages = [{"role": "user", "content": email_text}]

    for step in range(max_steps):
        response = client.messages.create(
            model=model_id, max_tokens=500,
            system=AGENT_SYSTEM_PROMPT, tools=all_tools,
            messages=messages,
        )

        if response.stop_reason != "tool_use":
            return {"status": "no_tool_call", "text": response.content[0].text}

        messages.append({"role": "assistant", "content": response.content})
        tool_result_blocks = []

        for block in response.content:
            if block.name == "validate_fd_reference":
                # THE KEY CHANGE: routed through the MCP client, not a
                # direct Python function call -- everything else about
                # the loop's mechanics is UNCHANGED from Chapter 10 Topic 1
                try:
                    mcp_result = await mcp_session.call_tool(
                        "validate_fd_reference", arguments=block.input
                    )
                    result = json.loads(mcp_result.content[0].text)
                except Exception as e:
                    # MCP-CONNECTION-SPECIFIC error handling -- a NEW
                    # failure point Chapter 10 Topic 4's original design
                    # didn't need to consider for an in-process call
                    result = {"found": False, "error": True, "error_type": "mcp_connection_failed",
                              "message": f"Could not reach the MCP server: {type(e).__name__}"}

                tool_result_blocks.append({
                    "type": "tool_result", "tool_use_id": block.id, "content": json.dumps(result),
                })
            elif block.name == "finalize_classification":
                return {"status": "classified", "label": block.input["label"], "reason": block.input["reason"]}

        messages.append({"role": "user", "content": tool_result_blocks})

    return {"status": "max_steps_exceeded"}
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **Connection lifecycle failures are a genuinely new failure category**: an MCP server crash mid-conversation (Topic 4's monitoring concern) now directly surfaces as a client-side connection failure — the `try/except` around `mcp_session.call_tool()` shown above is not optional defensive coding, it's handling a real, new class of failure this project's tightly-coupled tool calls never had to consider, since a direct Python function call cannot "disconnect" the way a cross-process connection can.
- **Startup dependency ordering**: the agent application now depends on the MCP server being running and ready *before* the agent can successfully discover and use its tools — this introduces a genuine startup-sequencing requirement (the server must start first, or the client's connection attempt must retry until the server becomes available) that a purely in-process, single-application deployment never needed to think about.
- **Latency measurement, concretely**: this is the point where Topic 3's flagged "genuine latency overhead" becomes directly measurable — comparing `validate_fd_reference` call latency before (Chapter 10 Topic 1's in-process call) and after (this topic's MCP-routed call) gives this project concrete evidence for the actual cost being paid, which should be weighed against the reuse benefit being gained, rather than remaining a purely theoretical trade-off.
- **Monitoring**: track MCP connection health as its own distinct signal from general agent health — a rising rate of `mcp_connection_failed` errors is a clear, specific signal pointing at the MCP server or its connection, distinct from any other kind of agent failure, and should route to a different investigation path (check the server process, per Topic 4's health-monitoring discussion) than a general application error would.
- **Cost**: no direct new monetary cost from the MCP layer itself (no additional LLM calls), but the added latency indirectly affects perceived responsiveness and, at high enough overhead, could affect customer experience metrics — worth tracking even though it's not a literal dollar cost line item.
- **Security**: the MCP client-server connection, even over local stdio, is a boundary where malformed or unexpected data could theoretically cross — the same defensive parsing discipline applied to any external input (Chapter 9 Topic 4's principle, Chapter 10 Topic 2's tool input validation) should apply to whatever comes back from the MCP server, not assumed automatically trustworthy simply because it's "this project's own" server.
- **Deployment**: this project's deployment process now needs to manage TWO coordinated processes (the agent application and the MCP server) rather than one — a genuine increase in deployment complexity that needs its own explicit process (e.g. a startup script or orchestration configuration ensuring both processes launch correctly and in the right order, and both are monitored for health).

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **Mixing MCP-managed tools and still-local, in-process tools in the same agent (as shown in the code above)**: this is likely this project's realistic, incremental adoption path — not every tool needs to migrate to MCP simultaneously, and the `all_tools = mcp_tools + other_local_tools` pattern shown supports a gradual, tool-by-tool migration rather than an all-or-nothing rewrite, directly reflecting Topic 3's selective-adoption recommendation.
- **Reconnection strategy if the MCP server connection drops mid-session**: the code above treats a connection failure as a terminal error for that specific tool call (returned as a structured `mcp_connection_failed` result), letting the model reason about the failure and decide its next action — an alternative design could attempt an automatic reconnection before giving up, adding resilience at the cost of added complexity and potential latency from the reconnection attempt itself. Given Chapter 10 Topic 4's established preference for structured failure over silent complexity, the simpler "fail this call cleanly, let the model or a higher-level retry mechanism decide what's next" approach is a reasonable starting point, with reconnection logic added later only if production experience shows transient connection drops are common enough to justify it.
- **Should the MCP client connection be established once at application startup (this topic's approach) or per-request?**: per-request connection establishment would be simpler in some ways (no persistent connection lifecycle to manage) but adds meaningful latency to every single tool call (connection setup overhead repeated every time) — establishing once at startup and reusing the connection is the correct default for a production system where tool calls happen frequently, though it requires the connection-health monitoring and reconnection-on-failure considerations discussed above.

---

### 6. Alternatives and When to Use Each

- **Full MCP client integration for all tools simultaneously**: appropriate only once a clear, validated need exists for every tool to be MCP-accessible — a larger, riskier migration than the incremental approach below.
- **Incremental, tool-by-tool MCP adoption (this topic's demonstrated approach)**: the pragmatic default — migrate individual tools to MCP servers as concrete reuse needs materialize (Topic 3's evidence-based criterion), keeping the rest tightly coupled, minimizing risk and allowing the team to build operational confidence with the new architecture gradually.
- **Reverting a tool from MCP back to tight coupling if the anticipated reuse never materializes**: a legitimate, honest option (as discussed in Topic 3's scenario-based question) — architectural decisions should remain revisable based on real outcomes, not treated as permanent once made.

---

### 7. Common Mistakes and Production Failures

- Establishing a fresh MCP client connection for every single tool call instead of once at application startup, adding significant, unnecessary latency overhead to every request.
- Not handling MCP connection failures explicitly, allowing an unexpected exception from a dropped connection to crash the entire agent loop rather than failing gracefully for just that specific tool call.
- Not accounting for startup-sequencing dependencies (the MCP server must be running before the agent can successfully connect), causing failures specifically during application startup or deployment that don't manifest once both processes are already running.
- Assuming schema translation between MCP's format and Anthropic's format is always lossless without explicitly testing it, risking a subtle tool-selection or argument-parsing regression introduced purely by the translation layer, not the underlying tool logic itself.
- Not measuring the actual latency cost of the MCP-routed call versus the original in-process call, missing a real, quantifiable trade-off that should inform future migration decisions for other tools.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: What is the one specific change in `run_agent()`'s dispatch logic when migrating `validate_fd_reference` to be MCP-managed, and what stays exactly the same?**
A: The change is in how the tool's actual execution happens — instead of directly calling the Python function `validate_fd_reference(reference_number)` in-process, the code now calls `await mcp_session.call_tool("validate_fd_reference", arguments)`, routing the invocation through the MCP client connection to the separate server process. Everything else about the loop's mechanics — detecting the `tool_use` block, packaging the result into a `tool_result` with the matching `tool_use_id`, appending to `messages`, continuing the loop — remains exactly as established in Chapter 10 Topic 1.

**Q: Why should the MCP client connection be established once at application startup rather than per tool call?**
A: Establishing a connection has its own overhead (process communication setup) — repeating this for every single tool call would add that overhead redundantly to every request, when the connection can instead be established once and safely reused across many subsequent tool calls throughout the application's runtime, avoiding this repeated cost entirely.

**Intermediate:**

**Q: What new failure mode does connecting to an MCP server introduce that this project's original in-process tool calls never had to handle?**
A: A connection failure — the MCP server process could crash, become unresponsive, or the connection could otherwise be lost mid-session — something structurally impossible for a direct, in-process Python function call, which either runs successfully or raises a normal Python exception within the same process. This requires explicit handling (the `try/except` around `mcp_session.call_tool()`) to convert a connection-level failure into the same kind of structured, gracefully-handled error response Chapter 10 Topic 4 established for other tool failure modes, rather than letting an unhandled connection exception crash the agent loop.

**Q: Why does this project's design mix MCP-managed and still-local tools in the same `TOOLS` list rather than migrating everything to MCP at once?**
A: This reflects an incremental, evidence-based adoption strategy (Topic 3's core recommendation) — not every tool has a concrete, validated reuse need justifying MCP's overhead, so migrating only the tools with genuine reuse value (or being migrated first as a proof of concept, as `validate_fd_reference` is here) while leaving others tightly coupled minimizes risk and avoids paying MCP's latency and complexity cost for tools that don't yet benefit from its decoupling.

**Advanced:**

**Q: Design the startup sequencing and health-check strategy needed to reliably deploy this project's agent application alongside its MCP server dependency.**
A: The deployment process needs to launch the MCP server first (or launch both simultaneously with the agent's client connection logic retrying with backoff, mirroring Chapter 10 Topic 4's retry pattern, until the server becomes available rather than failing immediately if it's not yet ready) and confirm the server is genuinely ready (successfully responding to a `list_tools()` discovery call, not just that its process has started, since a process can be running but not yet fully initialized) before the agent begins accepting real customer traffic. Ongoing health monitoring should separately track both the agent application's health and the MCP server's health, with alerting configured to distinguish "the agent is down" from "the agent is up but its MCP server dependency is unreachable," since these require different investigation and remediation paths — a process supervisor or container orchestration health-check configuration (Topic 4's forward reference) is the standard infrastructure tool for implementing this reliably rather than hand-rolling it.

**Q: A/B testing shows the MCP-routed version of `validate_fd_reference` adds 15ms of latency per call compared to the original in-process implementation, and this tool is called on roughly 40% of all customer emails at this project's production volume. Quantify the aggregate impact and discuss whether this trade-off is justified.**
A: At 8,000-12,000 emails/day with 40% triggering this tool, that's roughly 3,200-4,800 additional 15ms delays per day — an aggregate of 48-72 additional seconds of cumulative latency across the day's traffic, though critically this is *per-request* added latency (each affected customer experiences an extra 15ms), not a bottleneck that compounds across requests, so the customer-facing impact is a small, likely imperceptible addition to each individual request's response time rather than a systemic slowdown. Whether this is "justified" depends entirely on what concrete reuse benefit is actually being realized by this migration — if a genuine second consumer (an internal support tool, per Topic 3's motivating scenario) is actively using this same MCP server, the 15ms is a reasonable, small price for that realized reuse value; if no second consumer yet exists, this is 15ms of pure overhead for a benefit that remains hypothetical, which is exactly the scenario Topic 3's "premature adoption" concern warned against, and would argue for reverting to the in-process implementation until the anticipated reuse case actually materializes.

**Scenario-based:**

**Q: During a routine deployment, the MCP server's startup script has a bug causing it to fail silently, but the agent application starts successfully and begins accepting traffic. Every customer email requiring `validate_fd_reference` now receives an `mcp_connection_failed` error. Diagnose the process and monitoring gaps that allowed this to reach production undetected until customer complaints arrived.**
A: This reveals two gaps: first, the agent's startup sequence apparently didn't verify the MCP server was genuinely ready (a successful `list_tools()` call, not just "the server process exists") before beginning to accept live traffic — a startup health-check gate would have caught this before any real customer request was affected. Second, ongoing monitoring apparently didn't have alerting on the `mcp_connection_failed` error rate specifically, or didn't have a low-enough alerting threshold to catch a 100% failure rate for this specific tool promptly — given every relevant request would have failed identically after this deployment, a well-configured error-rate alert should have fired within minutes, not waited for customer complaints to surface the issue. The fix requires both a startup health-check gate (preventing the agent from serving traffic until its MCP dependency is confirmed healthy) and dedicated, sufficiently sensitive alerting on MCP-connection-specific error rates, treating this failure category with the same monitoring rigor as any other critical dependency failure.

---

### 9. Hidden Concepts and Prerequisites

- **This topic is a concrete instance of general "service dependency management" in distributed systems** — startup ordering, health checks, graceful degradation when a dependency is unavailable, and connection lifecycle management are all well-established concerns in any system composed of multiple communicating services, not unique to MCP or LLM agents specifically.
- **The async/await pattern used throughout this topic's code reflects a genuine shift from this project's earlier, synchronous code patterns** (Chapters 3-10's `client.messages.create()` calls were synchronous) — MCP's client libraries are commonly async-first, meaning integrating MCP into a previously fully-synchronous codebase requires understanding and correctly handling Python's async/await concurrency model, a real, non-trivial engineering skill distinct from anything covered in earlier chapters.
- **This closes the loop on Chapter 11's full MCP arc (Topics 3-5)** and connects forward to Chapter 12's LangGraph orchestration chapter — a multi-agent architecture built with LangGraph is a natural, complementary consumer of MCP-exposed tools, since different nodes in an orchestration graph (Chapter 12's subject) could each act as MCP clients connecting to shared, centrally-maintained MCP servers for common capabilities, directly building on this chapter's foundation.

---

### 10. Revision Summary

> Connecting an agent to the MCP server built in Topic 4 completes this chapter's MCP arc: the agent becomes an MCP client, establishing a persistent connection at startup (not per-request, to avoid repeated connection overhead), discovering available tools via `list_tools()`, translating MCP's schema format into Anthropic's `tools` format, and routing tool invocation through `mcp_session.call_tool()` instead of a direct in-process function call — with everything else about `run_agent()`'s mechanical loop (Chapter 10 Topic 1) staying exactly the same. This introduces a genuinely new failure category (connection failures) requiring the same structured-error-response discipline as Chapter 10 Topic 4, now applied to a cross-process boundary that can fail in ways an in-process function call never could. Mixing MCP-managed and still-local tools in the same toolset supports the incremental, evidence-based adoption strategy Topic 3 recommended, rather than requiring an all-or-nothing migration. New operational requirements — startup sequencing (the server must be ready before the agent serves traffic), dedicated health monitoring for the MCP connection distinct from general application health, and measurable latency overhead — are the concrete, now fully realized costs of this architecture, which should be weighed against actual, materializing reuse benefits exactly as Topic 3 anticipated conceptually and this topic makes empirically measurable.

---
