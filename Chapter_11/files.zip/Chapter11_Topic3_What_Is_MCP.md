# Chapter 11: Memory in Agents + Model Context Protocol (MCP)

## Topic 3: What MCP Is and Why It Standardizes Tool/Resource Access

---

### 1. Concept, Intuition, and Why It Exists

- Every tool this project has built (Chapters 3, 9, 10) — `validate_fd_reference`, `search_knowledge_base`, `lookup_product_catalog`, `check_sender_history` — is defined and wired using Anthropic's specific tool-calling API conventions (`tools` parameter, `input_schema`, `tool_use`/`tool_result` content blocks). This works well, but it is **provider-specific and application-specific**: these exact tool definitions and the Python functions behind them are coupled directly into this project's own codebase, callable only from within this project's own agent loop, using this specific API's exact conventions.
- **MCP (Model Context Protocol)**, an open protocol originally introduced by Anthropic, exists to solve exactly this coupling problem: it defines a standardized way to expose tools (and other resources, like data sources) as a separate, independent **server** that *any* MCP-compatible client — a different agent, a different LLM provider's application, even a completely different team's system — can connect to and use, without needing to know anything about how the tools are implemented internally.
- The core intuition: today, this project's `validate_fd_reference` tool is defined *inside* this project's agent code — if a different team wanted to build a separate agent (say, an internal support-staff tool) that also needed FD reference lookups, they'd need to reimplement or directly import this project's specific Python function. With MCP, `validate_fd_reference` could instead be exposed once, as a standalone MCP server, and *any* MCP-compatible agent — this project's customer-facing agent, a hypothetical internal support tool, a future agent built by a different team entirely — could connect to that one server and use the same tool, with the same guaranteed behavior, without any code sharing or tight coupling.

---

### 2. Internal Working — Step by Step

**The MCP architecture, at a conceptual level:**

1. **An MCP server** exposes a set of capabilities — tools (functions the client can invoke), resources (data the client can read), and prompts (reusable prompt templates) — over a standardized protocol, independent of any specific LLM provider's API conventions.
2. **An MCP client** (which could be this project's agent, or Claude Desktop, or any other MCP-compatible application) connects to one or more MCP servers, discovers what capabilities each server exposes, and can invoke them — the client translates between the MCP protocol's standardized representation and whatever LLM-provider-specific tool-calling format it actually needs (e.g. converting an MCP tool definition into Anthropic's `tools` schema format for a `client.messages.create()` call).
3. **The protocol itself** is transport-agnostic in principle (commonly implemented over stdio for local servers, or HTTP/SSE for remote servers) and uses JSON-RPC-style message exchange for discovery ("what tools do you have?") and invocation ("call this tool with these arguments").

**Why this decoupling matters, concretely for this project:**

1. **Reusability across agents**: if this project eventually builds Chapter 12's more sophisticated LangGraph-orchestrated multi-agent system, or a completely separate internal tool for support staff, MCP lets both reuse the *same* `validate_fd_reference` implementation via a shared server, rather than duplicating the Python function or tightly coupling both systems to the same codebase.
2. **Provider independence**: this project currently uses `claude-haiku-4-5-20251001` exclusively, but MCP's standardization means that if a future requirement ever needed a different LLM provider for some component, the *tools* themselves (as MCP servers) wouldn't need to be rewritten — only the *client* translation layer connecting to a different provider's specific tool-calling API would need adaptation.
3. **Clear ownership and versioning boundaries**: an MCP server for `validate_fd_reference` becomes a genuinely separate, independently deployable and versionable piece of infrastructure — the team owning the FD database can own and evolve this server's implementation without needing to coordinate every change through this project's agent codebase directly, exactly the kind of clean interface boundary that scales better as an organization and its systems grow.

---

### 3. How It Is Implemented in This Project — Conceptual Mapping (Full Implementation in Topic 4)

```python
# BEFORE MCP: this project's current, tightly-coupled pattern (Chapters 3, 9, 10)
# validate_fd_reference is defined directly in this project's own codebase,
# only callable from within this project's own run_agent() loop.

VALIDATE_FD_REFERENCE_TOOL = {
    "name": "validate_fd_reference",
    "description": "...",
    "input_schema": {...},
}

def validate_fd_reference(reference_number: str) -> dict:
    return get_fd_record(reference_number)  # tightly coupled to THIS codebase


# AFTER MCP (conceptual preview -- Topic 4 builds the real server):
# validate_fd_reference becomes a TOOL EXPOSED BY AN MCP SERVER, running as
# its own independent process. This project's agent becomes an MCP CLIENT
# that discovers and calls it, rather than importing the function directly.

# Conceptually, the MCP server declares its tools in a STANDARDIZED format
# (not Anthropic's tools/input_schema format specifically -- MCP has its
# own schema convention, which an MCP CLIENT then translates into
# whatever the underlying LLM API actually needs):

MCP_TOOL_DEFINITION_CONCEPTUAL = {
    "name": "validate_fd_reference",
    "description": "Looks up an FD record by reference number.",
    "inputSchema": {  # MCP's own JSON Schema convention
        "type": "object",
        "properties": {"reference_number": {"type": "string"}},
        "required": ["reference_number"],
    },
}

# The CLIENT (this project's agent, adapted) discovers this tool from the
# MCP server at runtime, translates it into Anthropic's tools format,
# and includes it in client.messages.create(tools=translated_tools, ...)
# -- exactly as before, but now the TOOL DEFINITION AND IMPLEMENTATION
# live in a separate, independently-deployable server, not this project's
# own codebase directly.
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **MCP adds a genuine architectural layer, and therefore genuine latency and operational overhead**: calling a tool via an MCP server (a separate process, potentially over a network) is slower than calling a Python function directly within the same process (this project's current pattern) — this overhead must be weighed against the reusability and decoupling benefits, and is not free simply because the protocol is well-designed.
- **Discovery and versioning become explicit, ongoing concerns**: once `validate_fd_reference` is a separately-versioned MCP server rather than code directly inside this project's repository, changes to its behavior (a schema change, per Chapter 10 Topic 3's discipline) need a genuine deployment and versioning strategy independent of this project's own release cycle — a new kind of coordination overhead that a tightly-coupled, single-codebase tool doesn't require.
- **Not every tool benefits equally from MCP's decoupling**: a tool genuinely specific to this one agent's use case, unlikely to ever be reused elsewhere, gains little from being extracted into a separate MCP server and pays the latency/complexity cost for no real benefit — MCP is most valuable specifically for capabilities with genuine reuse potential across multiple agents or systems, not a universal default for every tool regardless of reuse likelihood.
- **Monitoring an MCP-based architecture requires tracing across a process/network boundary**: Chapter 9 Topic 3's full pipeline-stage logging discipline now needs to span the client-server boundary — a debugging trace must capture not just what happened inside the agent's own process, but what happened inside the separate MCP server process handling a specific tool call, a genuinely more complex observability requirement than single-process tool calls.
- **Security**: an MCP server, especially if exposed over a network (rather than local stdio) for shared use across multiple client applications, needs its own authentication and access control — a very different security posture than a tool function living safely inside one application's own trusted process boundary; this is a new, real security surface that tightly-coupled tools don't have.
- **Cost**: running MCP servers as separate, independently-deployed processes has its own infrastructure cost (compute, potentially networking) distinct from this project's existing agent infrastructure — a genuine cost trade-off against the reusability benefit that should be weighed deliberately, not assumed to be free.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **When is MCP's decoupling worth its overhead for this project specifically?**: given this project currently has one primary agent (the classification/response system), the reusability argument for MCP is more forward-looking than immediately necessary — the value becomes concrete once a second, genuinely separate system (an internal support tool, a different team's agent, per Chapter 12's eventual multi-agent trajectory) needs to reuse the same underlying capabilities (`validate_fd_reference`, `search_knowledge_base`). Adopting MCP purely in anticipation of that future need, before it's concrete, is a real architectural bet that should be weighed against simply keeping tools tightly coupled until reuse is genuinely needed — echoing this project's consistent evidence-before-architecture-change discipline.
- **Local (stdio) MCP servers vs. remote (networked) MCP servers**: a local server (the same machine, communicating over standard input/output) avoids network latency and security surface concerns entirely, appropriate when the "reuse" being enabled is across different processes on the same machine or a tightly-controlled local development setup. A remote server (accessible over a network) enables true cross-system, cross-team reuse but introduces genuine network latency, authentication, and availability concerns — this project's actual choice should depend on how broadly the tool genuinely needs to be shared.
- **Full MCP adoption for every tool vs. selective adoption for genuinely reusable capabilities**: given the overhead discussed above, a selective approach — keeping simple, single-use tools tightly coupled as they are today, and extracting only the tools with clear, concrete reuse value (perhaps `search_knowledge_base`, if a separate internal tool would also benefit from the same policy-search capability) into MCP servers — is likely the more pragmatic path for this project than a wholesale migration of every existing tool.

---

### 6. Alternatives and When to Use Each

- **Tightly-coupled tools within a single codebase (this project's current approach through Chapter 10)**: the correct choice when tools are genuinely specific to one agent's use case with no near-term reuse need — simpler, faster (no cross-process overhead), and easier to develop and debug within one codebase.
- **MCP-based decoupled tool servers (this topic's subject)**: the correct choice once genuine cross-agent or cross-team reuse is needed, or when a tool's implementation genuinely benefits from being owned and versioned independently of any single consuming application.
- **A shared internal Python library (an alternative decoupling approach, without MCP's protocol-level standardization)**: extracting `validate_fd_reference` into a shared, importable Python package that multiple codebases can depend on achieves some of MCP's reuse benefit without the cross-process/network overhead — appropriate when all consuming systems are guaranteed to be Python-based and can tolerate a shared-library dependency relationship, but loses MCP's provider-independence and true process-level isolation benefits, and doesn't generalize to non-Python consuming systems the way a protocol-level standard does.

---

### 7. Common Mistakes and Production Failures

- Adopting MCP for every tool preemptively, before any genuine reuse need exists, paying real latency and operational overhead for a decoupling benefit that isn't yet being used.
- Not accounting for the genuine latency cost of cross-process (or cross-network) tool invocation when migrating a previously in-process tool call to an MCP server, causing an unexpected agent response time regression.
- Treating an MCP server's versioning and deployment as an afterthought, rather than establishing clear ownership and change-management processes once a tool becomes a genuinely separate, independently-evolving piece of infrastructure.
- Exposing an MCP server over an insecure network connection without proper authentication, especially risky given tools like `validate_fd_reference` touch customer PII.
- Not extending observability/tracing practices (Chapter 9 Topic 3's discipline) across the new client-server boundary MCP introduces, losing visibility into what's actually happening inside a separately-running MCP server during debugging.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: What problem does MCP solve that this project's current tool-calling approach (tools defined directly in the agent's own codebase) does not?**
A: This project's current tools are tightly coupled to this specific codebase and this specific LLM provider's API conventions — reusing `validate_fd_reference` in a different agent or system would require directly importing or reimplementing this project's Python function. MCP standardizes tool exposure as an independent server any MCP-compatible client can discover and use, decoupling the tool's implementation from any single consuming application or LLM provider.

**Q: Why might adopting MCP for every single tool in this project be premature, given its current architecture?**
A: MCP's decoupling benefit (reusability across multiple agents or systems) is only realized once genuine reuse actually happens — with currently one primary agent, extracting every tool into a separate MCP server pays real latency and operational overhead (cross-process or network communication, independent versioning and deployment) without yet capturing the corresponding benefit. This mirrors the evidence-before-architecture-change discipline used throughout this project — adopt the more complex architecture once a concrete need justifies it, not preemptively.

**Intermediate:**

**Q: What is the difference between an MCP server and an MCP client, and which role does this project's agent play?**
A: An MCP server exposes capabilities (tools, resources, prompts) via the standardized protocol, independent of how those capabilities will be consumed. An MCP client connects to one or more servers, discovers their exposed capabilities, and invokes them — translating between MCP's standardized representation and whatever specific format the client's own LLM API actually requires. This project's agent, if adopting MCP, would primarily act as a client, connecting to MCP servers exposing tools like `validate_fd_reference`, while a separate, independent process would run as the server actually implementing that tool's logic.

**Q: Why does exposing a tool via a remote (networked) MCP server introduce security considerations that a tightly-coupled, in-process tool call doesn't have?**
A: A tool function living inside this project's own application process is protected by that process's own trust boundary — nothing outside the application can invoke it directly. A remote MCP server, accessible over a network so multiple different client applications can connect to and use it, is a genuinely new, separately-accessible surface that requires its own authentication and access control, since without it, any client capable of reaching the server over the network could potentially invoke its tools, including tools that touch sensitive customer data like `validate_fd_reference`.

**Advanced:**

**Q: Design the criteria for deciding which of this project's existing tools (validate_fd_reference, search_knowledge_base, lookup_product_catalog, check_sender_history) are the best candidates for extraction into MCP servers, versus remaining tightly coupled.**
A: The strongest candidates are tools with genuine, concrete (not merely hypothetical) reuse potential across multiple systems — `search_knowledge_base`, for instance, if an internal support-staff tool would benefit from the same policy-search capability without needing to reimplement Chapter 7's entire retrieval pipeline, is a strong candidate, since the value of a shared, independently-maintained server is concrete and immediate. `check_sender_history`, tied tightly to this project's specific customer-facing agent's memory architecture (Topics 1-2), is a weaker candidate unless a genuinely separate system also needs access to the same interaction history, which isn't yet an established requirement. The decision should be revisited as this project's system landscape genuinely grows (per Chapter 12's eventual multi-agent trajectory), rather than decided once and treated as permanent — extraction into MCP is a reversible-but-nontrivial architectural investment that should track actual, materializing reuse needs.

**Q: A stakeholder argues that adopting MCP now, even without immediate reuse needs, is valuable as forward-looking architecture that will pay off later. How do you evaluate this argument?**
A: This is a legitimate architectural bet, but it should be evaluated with the same rigor as any other speculative investment — what is the actual probability and timeline of the anticipated future reuse materializing, what is the concrete cost being paid now (latency overhead, operational complexity, engineering time) versus the cost of migrating later once reuse is genuinely needed, and is that later migration cost meaningfully higher than adopting MCP now. For a capability with a highly likely, near-term reuse case already partially visible (like Chapter 12's stated multi-agent trajectory), earlier adoption may be justified. For capabilities with only vague, distant future reuse possibilities, this project's consistent discipline of deferring architectural complexity until evidence justifies it (applied throughout Chapters 6, 7, and 9's various infrastructure decisions) suggests waiting for a more concrete signal is the more defensible default, rather than treating "might be useful later" as sufficient justification on its own.

**Scenario-based:**

**Q: Six months after adopting MCP for `search_knowledge_base`, you notice its response latency has increased compared to the original in-process implementation, and a new internal support tool that was supposed to justify the migration was never actually built. Diagnose the situation and recommend next steps.**
A: This is exactly the risk flagged in the "premature adoption" discussion — the migration's latency cost was paid, but the anticipated reuse benefit never materialized, meaning the current state is strictly worse than the original tightly-coupled implementation for this project's actual, realized needs. The honest next step is re-evaluating whether the internal support tool is still genuinely planned in the near term (in which case tolerating the latency cost a while longer may still be justified) or whether it's been deprioritized or abandoned (in which case reverting `search_knowledge_base` to a tightly-coupled, in-process implementation, removing the unrealized-benefit MCP overhead, is the more honest and performance-appropriate choice) — architectural decisions should be revisited against actual outcomes, not treated as permanent commitments once made, especially when the original justification for the decision has demonstrably not played out as anticipated.

---

### 9. Hidden Concepts and Prerequisites

- **MCP is conceptually related to general API/service-oriented architecture patterns** — the same reasoning that motivates extracting a capability into a well-defined, independently-versioned microservice in traditional software architecture applies directly to MCP's motivation for tool decoupling; recognizing MCP as an LLM-specific instance of this much broader, well-established architectural pattern (rather than something entirely novel to agentic AI) situates it correctly within existing engineering knowledge.
- **JSON-RPC, the typical underlying message format for MCP's client-server communication, is itself a long-established, general-purpose remote procedure call convention** predating MCP by many years — worth knowing this by name, since it clarifies that MCP's wire-level mechanics build on existing, well-understood standards rather than inventing an entirely new communication paradigm from scratch.
- **This connects directly forward to Topics 4-5 of this chapter**, which build a real, working MCP server wrapping this project's tools and connect an agent to it end to end — this topic deliberately stayed at the conceptual, architectural level so those following topics' hands-on implementation work has a clear conceptual foundation to build on.

---

### 10. Revision Summary

> MCP (Model Context Protocol) standardizes how tools, resources, and prompts are exposed by a server and consumed by a client, decoupling tool implementation from any single consuming application or LLM provider — solving the tight-coupling limitation of this project's current tool-calling pattern, where `validate_fd_reference` and similar tools are defined directly inside this project's own codebase, callable only from this project's own agent loop. The decoupling enables genuine reuse across multiple agents or teams (an internal support tool sharing the same FD lookup capability, for instance) and provider independence, at the real cost of cross-process/network latency and the operational overhead of independently versioning and deploying separated servers. This trade-off means MCP adoption should be evidence-driven — justified by concrete, materializing reuse needs, not adopted preemptively as generically "good architecture" — following this project's consistent discipline of deferring architectural complexity until genuinely warranted. Security and observability both require new consideration once tools move behind a client-server boundary: authentication for networked servers (a genuinely new attack surface tightly-coupled tools don't have), and tracing that spans the process boundary for effective debugging.

---
