# Chapter 11: Memory in Agents + Model Context Protocol (MCP)

## Topic 1: Short-Term Memory (Within One Email) vs. Long-Term Memory (Sender History)

---

### 1. Concept, Intuition, and Why It Exists

- Chapter 10 Topic 1 established a foundational fact: the API is stateless — every `client.messages.create()` call carries no memory of any prior call unless you explicitly include it in `messages`. Chapter 9 Topic 6's multi-turn RAG work already used this fact to build conversation history across turns *within* one customer interaction. This topic formalizes that pattern and names its counterpart: what happens *across* separate interactions, potentially days or months apart, with the same customer.
- **Short-term memory**: the accumulated `messages` list within a single `run_agent()` invocation, or across the turns of a single ongoing conversation (Chapter 9 Topic 6). It exists only as long as the conversation does, and is naturally bounded by Chapter 8 Topic 1's token budget concerns.
- **Long-term memory**: information that persists *between* separate conversations, tied to a durable identity (a customer's email address, not a temporary conversation ID) — this project's own EDA finding that 14% of senders are repeat senders is the direct business motivation. `check_sender_history` (Chapter 10 Topic 5) was the first concrete tool touching this capability; this topic is where that capability gets a proper architectural home instead of being a single tool's implementation detail.
- Why this distinction matters enough to be a dedicated topic: short-term and long-term memory have completely different lifecycle, storage, and access-pattern requirements. Conflating them — for instance, trying to store an entire conversation history indefinitely as "memory" — creates exactly the kind of unscoped, unbounded, poorly-governed data store that causes real production problems (storage growth, PII governance complexity, retrieval inefficiency).

---

### 2. Internal Working — Step by Step

**Short-term memory, mechanically:**

1. Exists purely as the `messages` list, held in application memory (or a session store) for the duration of one conversation.
2. Grows with every turn — every customer message, every assistant response, every tool call and tool result becomes part of it.
3. Is naturally bounded by two forces: the conversation ending (customer stops replying, or the interaction reaches a terminal tool call), and Chapter 8 Topic 1's token budget, which forces truncation or summarization once accumulated history grows large enough to threaten the space needed for other content.
4. Is *ephemeral by design* — once the conversation ends, this specific accumulated context has no inherent reason to persist further, unless something specific from it is worth promoting into long-term memory.

**Long-term memory, mechanically:**

1. Keyed by a durable identity — this project's natural choice is the sender's email address (already the access-scoping key `check_sender_history` uses, per Chapter 10 Topic 5).
2. Stored *outside* any single conversation's lifecycle — a persistent store (a database table, not an in-memory Python list) that survives server restarts, spans multiple separate conversations, and grows over the customer's entire relationship with the business.
3. Is **not** a verbatim transcript of every past conversation — storing every raw message from every past interaction indefinitely is both a storage-growth problem and a PII/governance problem (exactly the concern Chapter 6 Topic 9 raised for customer records generally). Instead, long-term memory typically stores a *distilled* representation: topics discussed, dates, resolution status, and any specific facts worth remembering (e.g. "this customer is a senior citizen," "this customer has previously disputed a penalty charge").
4. Is retrieved selectively, on demand, via a tool call (`check_sender_history`) — not automatically loaded into every conversation's context by default, echoing Chapter 9 Topic 1's broader "retrieve only when needed" trigger philosophy, now applied to memory rather than knowledge-base content.

**The distillation step — the specific mechanism that turns a raw conversation into long-term memory:**

- At the end of a conversation (once a terminal tool like `finalize_classification` or `refuse_out_of_scope` is reached), a distillation step extracts the durable, worth-remembering facts from the full short-term `messages` history and writes a compact summary into the long-term store — this is the bridge between the two memory types, and is itself often an LLM call (summarize this conversation into a few durable facts), not a hand-coded extraction.

---

### 3. How It Is Implemented in This Project

```python
# Short-term memory: exactly Chapter 9 Topic 6's existing pattern, unchanged
def run_agent_with_short_term_memory(email_text: str, conversation_history: list,
                                      client, model_id: str) -> dict:
    messages = conversation_history + [{"role": "user", "content": email_text}]
    # ... the existing run_agent() loop, operating on this SHORT-TERM messages list
    return {"messages": messages}  # returned so the CALLER can persist it for the NEXT turn


# Long-term memory: a separate, durable store, keyed by sender identity
LONG_TERM_MEMORY_STORE = {}  # in production: a real database table, not a Python dict

def distill_conversation_to_memory(conversation_messages: list, sender_email: str,
                                    client, model_id: str) -> dict:
    """Runs ONCE, at the end of a conversation (after a terminal tool call),
    extracting durable facts worth remembering long-term. This is
    DELIBERATELY not a verbatim copy of the conversation -- distillation
    keeps long-term memory compact and specifically useful."""

    conversation_text = "\n".join(
        f"{m['role']}: {m['content']}" for m in conversation_messages
        if isinstance(m.get("content"), str)
    )

    distillation_prompt = f"""Conversation transcript:
{conversation_text}

Extract a SHORT summary (1-2 sentences) of the topic discussed and any
durable fact worth remembering about this customer for future interactions
(e.g. a recurring issue, a stated preference, a special status). If nothing
is durably worth remembering, say "No durable facts."."""

    response = client.messages.create(
        model=model_id, max_tokens=100,
        messages=[{"role": "user", "content": distillation_prompt}],
    )
    summary = response.content[0].text.strip()

    entry = {"date": get_current_date(), "topic": summary}

    LONG_TERM_MEMORY_STORE.setdefault(sender_email.lower(), []).append(entry)
    return entry


def check_sender_history(sender_email: str) -> dict:
    """Chapter 10 Topic 5's tool, now correctly understood as the READ
    path into long-term memory -- distillation (above) is the WRITE path."""
    history = LONG_TERM_MEMORY_STORE.get(sender_email.strip().lower(), [])
    if not history:
        return {"is_repeat_sender": False, "previous_interaction_count": 0}
    return {
        "is_repeat_sender": True,
        "previous_interaction_count": len(history),
        "previous_topics": [h["topic"] for h in history[-3:]],
        "last_interaction_date": history[-1]["date"],
    }
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **Distillation quality directly determines long-term memory's usefulness**: a poorly-distilled summary ("customer emailed about something") is worthless for future retrieval; a well-distilled one ("customer disputed a 1% premature withdrawal penalty on FD BJ2019FD7717, unresolved as of 2025-01-15") is directly actionable. This is prompt engineering (Chapter 9 Topic 6's discipline) applied specifically to the summarization task, and should be validated against real conversations, not assumed correct from the prompt wording alone.
- **Storage growth is unbounded by default**: unlike short-term memory (naturally bounded by conversation length and token budget), long-term memory accumulates indefinitely across a customer's entire relationship — a genuine, real storage and retrieval-latency concern at scale that needs an explicit retention policy (how much history to keep, whether to further compress or archive very old entries) rather than assuming indefinite unbounded growth is fine.
- **PII and governance implications compound over time**: long-term memory is, by definition, a durable store of customer-specific information — this is squarely within the PII governance concerns Chapter 6 Topic 9 raised for customer records, now extended to *derived, distilled* customer data rather than just raw database fields. Right-to-be-forgotten requests (a customer requesting deletion of their data) must delete from *both* the structured customer database (Chapter 6 Topic 9's original concern) and this long-term memory store — an easy thing to forget if long-term memory is bolted on as an afterthought rather than governed with the same rigor from the start.
- **Distillation timing and failure handling**: if distillation runs as a final step after the terminal tool call, what happens if the distillation LLM call itself fails (Chapter 10 Topic 4's error-handling discipline applies here too)? A failed distillation should not crash the primary request (the customer still gets their answer) — it should fail gracefully, perhaps queued for a retry, without blocking the customer-facing response on this secondary, non-critical-path operation.
- **Monitoring**: track distillation success/failure rate, average long-term memory entries per sender over time (a rapidly growing average might indicate the retention policy needs tightening), and — critically — how often `check_sender_history`'s returned context actually changes the agent's behavior or answer quality (echoing Chapter 10 Topic 5's cost-justification question for this specific tool).
- **Cost**: distillation adds one LLM call per completed conversation — a real, additional cost distinct from the primary conversation's own cost, and should be tracked as its own line item, especially since it runs on every conversation regardless of whether that conversation's summary ever gets retrieved and used later.
- **Deployment**: `LONG_TERM_MEMORY_STORE` as a Python dict is purely illustrative — a production system needs a real, persistent database table (keyed by sender identity, with proper indexing for the lookup pattern `check_sender_history` performs), surviving server restarts and supporting concurrent access from multiple agent instances.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **Distillation via LLM call vs. rule-based extraction**: an LLM-based distillation (shown above) is flexible and can capture nuanced, novel information a rule-based extractor might miss, but costs money and adds latency to the end of every conversation, and — like any LLM-generated content — needs its own quality validation rather than being assumed reliable. A rule-based extraction (e.g. tagging the conversation with its classification label and any structured facts already captured via tool calls, like a specific FD reference number discussed) is cheaper, more predictable, and directly reuses information already gathered during the conversation, at the cost of less flexibility for capturing genuinely novel, unstructured nuance. A hybrid — rule-based extraction for anything already structurally available (classification label, referenced account numbers), LLM-based distillation only for the genuinely unstructured "what was this about" summary — is a reasonable middle ground.
- **How much history to retain per sender**: keeping the full history indefinitely maximizes context available for future interactions but compounds storage and PII governance concerns; retaining only the most recent N interactions (as shown in the `history[-3:]` slicing in `check_sender_history`) bounds growth but risks losing a genuinely relevant older fact (echoing Chapter 9 Topic 6's identical truncation-vs-completeness trade-off for short-term conversation history, now applied at the long-term timescale).
- **Should distillation happen synchronously (blocking the response) or asynchronously (after the customer already has their answer)?**: synchronous distillation guarantees long-term memory is immediately up to date but adds latency to every single conversation's completion. Asynchronous distillation (queued, processed after the customer-facing response is already sent) adds no latency to the primary interaction, at the cost of a brief window where long-term memory is not yet updated (irrelevant for almost all realistic cases, since a customer is unlikely to email again within seconds of their first email) — this project should prefer the asynchronous approach, prioritizing customer-facing latency over the negligible risk of a stale long-term memory in an extremely short window.

---

### 6. Alternatives and When to Use Each

- **No long-term memory (only short-term, within-conversation memory)**: appropriate for a system where repeat interactions genuinely don't benefit from historical context, or where the customer base is large enough and interactions rare enough that repeat-sender patterns are negligible — not this project's actual situation, given the measured 14% repeat-sender rate.
- **Full verbatim conversation history retained indefinitely (no distillation)**: simpler to implement (no distillation step needed) but creates the storage-growth, retrieval-inefficiency, and PII-governance problems discussed above — not recommended once memory needs to scale across many customers and long relationship periods.
- **Distilled, compact long-term memory (this topic's recommended approach)**: the correct default balance of usefulness, storage efficiency, and governance manageability for this project's actual scale and requirements.
- **External memory frameworks (a forward reference)**: some agent frameworks provide built-in memory abstractions (conversation buffers, summary memory, entity memory) — worth being aware these exist as pre-built alternatives to hand-rolling this architecture, though understanding the underlying mechanics first (as this topic does) makes evaluating such frameworks far more informed than adopting one as an unexamined black box.

---

### 7. Common Mistakes and Production Failures

- Conflating short-term and long-term memory into one undifferentiated concept, leading to either unbounded short-term context growth (Chapter 8 Topic 1's budget problem) or an inability to persist anything useful across separate conversations.
- Storing full verbatim conversation transcripts indefinitely as "long-term memory" without any distillation, creating unnecessary storage growth and PII governance complexity.
- Not handling distillation failures gracefully, risking the primary customer-facing response being blocked or broken by a failure in a secondary, non-critical-path operation.
- Forgetting that long-term memory is customer PII subject to the same right-to-be-forgotten and access-scoping requirements as the structured customer database (Chapter 6 Topic 9), and not including it in deletion/governance processes.
- Not validating distillation quality, assuming an LLM-generated summary is automatically useful without checking whether it actually captures durably relevant information.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: What is the fundamental difference between short-term and long-term memory in an agentic system?**
A: Short-term memory is the accumulated conversation context (the `messages` list) within a single, ongoing interaction — it's ephemeral and naturally bounded by the conversation's length and the token budget. Long-term memory persists across separate conversations, tied to a durable identity like a customer's email address, stored in a persistent database rather than in-memory conversation state, and typically holds a distilled summary rather than verbatim transcripts.

**Q: Why shouldn't long-term memory simply store every past conversation's full transcript?**
A: This creates unbounded storage growth over a customer's entire relationship, makes retrieval less efficient (more data to search through for the relevant facts), and compounds PII governance complexity, since every stored word of every past conversation is customer data subject to the same access-scoping and right-to-be-forgotten requirements as structured database records. Distillation into compact, durably-relevant summaries addresses all three concerns.

**Intermediate:**

**Q: Why should distillation typically run asynchronously, after the customer-facing response has already been sent, rather than synchronously as part of the main request?**
A: Distillation is not on the customer's critical path — they don't need their long-term memory updated before receiving their current answer. Running it synchronously adds latency to every single conversation's completion for a benefit (immediately up-to-date long-term memory) that's rarely time-sensitive, since a customer is unlikely to email again within seconds. Running it asynchronously keeps the customer-facing latency unaffected, at the cost of a negligible, brief window before long-term memory reflects the just-completed conversation.

**Q: `check_sender_history` (Chapter 10 Topic 5) only returns the 3 most recent previous topics. What's the trade-off here, and how would you decide if this limit is appropriate?**
A: Limiting to the most recent 3 bounds the tool's response size and keeps the returned context focused on likely-still-relevant recent history, but risks losing a genuinely relevant older fact (e.g. a significant issue from 8 interactions ago that's still unresolved). This is the same completeness-versus-boundedness trade-off Chapter 9 Topic 6 faced for short-term conversation history truncation. The right limit should be validated against real usage: track how often older, excluded history would have actually been relevant to a current interaction (via post-hoc review of cases where responses seem to be missing important context) before assuming 3 is the correct number.

**Advanced:**

**Q: Design the right-to-be-forgotten process for this project's long-term memory store, given it now holds distilled summaries derived from past conversations, not just raw structured data.**
A: Any customer deletion request must remove their entry from `LONG_TERM_MEMORY_STORE` (keyed by their email address) in addition to their record in the structured customer database (Chapter 6 Topic 9's original scope) — this requires the deletion process to be aware of and touch both storage systems, not just the more "obvious" structured database. Since distilled summaries are derived data (not the original conversation transcripts, which presumably aren't separately retained once distilled), deleting the distilled entry is sufficient — there's no separate, hidden copy of the raw conversation elsewhere that also needs deletion, provided the distillation-then-discard pattern is implemented cleanly (i.e., the full conversation transcript isn't ALSO being separately archived somewhere for other purposes, which would need its own deletion path).

**Q: A teammate proposes skipping distillation entirely and instead re-running a semantic search over the customer's full raw conversation history (treated as a mini per-customer knowledge base, using Chapter 7's retrieval techniques) whenever `check_sender_history` is called. Evaluate this alternative.**
A: This trades distillation's upfront cost (one LLM call per completed conversation, whether or not it's ever retrieved later) for retrieval-time cost (running Chapter 7's retrieval pipeline against a growing per-customer corpus every time history is checked) — potentially cheaper for customers whose history is checked rarely, more expensive for customers checked frequently, given retrieval must re-run every time rather than paying the cost once at conversation end. It also reintroduces the storage-growth and retrieval-latency concerns of keeping full raw transcripts (Section 4's point), and requires building genuine per-customer retrieval infrastructure (chunking, embedding, indexing each customer's own conversation history) — meaningfully more engineering complexity than a distilled summary lookup. This could be worth it specifically if conversations are long and rich enough that distillation genuinely loses important nuance a full-text semantic search would preserve — a decision that should be validated against real cases where distilled summaries prove insufficient, rather than adopted preemptively.

**Scenario-based:**

**Q: A customer contacts support and mentions "as I discussed last time," but `check_sender_history` returns `is_repeat_sender: False`. Diagnose the possible causes.**
A: Several possibilities, each requiring different follow-up: the customer may have used a different email address for their previous interaction (a genuine identity-matching limitation of email-based keying — this project has no way to know two different addresses belong to the same person unless additional identity information is captured); the previous conversation may not have reached a terminal tool call, if distillation only runs on completed conversations (worth checking whether abandoned/incomplete conversations are handled at all); the distillation step for the previous conversation may have failed silently (Section 4's error-handling concern) without ever writing an entry; or the previous interaction may have occurred through a completely different channel (phone, in-branch) not captured in this email-specific system at all, a scope limitation worth being explicit about with stakeholders rather than treating as a bug in this system.

---

### 9. Hidden Concepts and Prerequisites

- **This topic is a direct application of general software architecture patterns around "session state" vs. "persistent state"** — the same distinction exists in web application architecture generally (a user's shopping cart during one browsing session vs. their saved order history across all sessions), and recognizing this connects agent memory architecture to a much broader, already-familiar body of software engineering practice.
- **Distillation is a specific instance of "lossy compression" applied to natural language** — deliberately discarding detail to retain only the most useful signal, trading completeness for compactness and efficiency; the same fundamental trade-off appears in domains as varied as video compression and database materialized views, applied here specifically to conversational context.
- **This connects directly forward to Topics 3-5 of this chapter (MCP)**: MCP standardizes *how* tools and resources (including a memory store) are exposed to an agent — this topic's memory architecture is exactly the kind of capability MCP is designed to make interoperable and reusable across different agents and different LLM providers, which the next three topics explore in depth.

---

### 10. Revision Summary

> Short-term memory is the ephemeral, within-conversation `messages` list, naturally bounded by conversation length and token budget (Chapter 8 Topic 1, Chapter 9 Topic 6). Long-term memory persists across separate conversations, keyed by durable customer identity, and should store *distilled* summaries rather than verbatim transcripts — bounding storage growth and reducing PII governance complexity. Distillation, typically an LLM call summarizing a completed conversation into durable facts, is the bridge from short-term to long-term memory, and should run asynchronously (off the customer's critical path) with graceful failure handling, since it's a non-critical secondary operation. Long-term memory is customer PII subject to the same access-scoping and right-to-be-forgotten requirements established in Chapter 6 Topic 9 for structured customer records, and any deletion process must account for both storage systems. `check_sender_history` (Chapter 10 Topic 5) is the read path into this architecture; distillation is the write path — together they form the complete memory lifecycle this project's 14% repeat-sender finding motivates.

---
