# Chapter 10: Tool Engineering

## Topic 4: Handling Tool Errors, Timeouts, and Retries Gracefully

---

### 1. Concept, Intuition, and Why It Exists

- Every tool built so far in this project (`validate_fd_reference`, `search_knowledge_base`) has been described in its "happy path" — the input is well-formed, the data source is available, the call succeeds. This topic addresses everything that happens when that assumption breaks: a database connection times out, a malformed argument slips through despite schema validation, a network call to an external API fails, or a bug in the backing function raises an unexpected exception.
- The core principle: **a tool's failure must never crash the agent loop, and must never leave the model with an ambiguous or silently-missing signal about what happened**. This directly extends Chapter 9 Topic 3's insistence on explicit, structured `found: False` responses — this topic generalizes that principle to *all* failure modes, not just "not found."
- Why this matters more as this project's toolset grows: `validate_fd_reference`'s current backing function (a local CSV read) has almost no realistic failure modes. `search_knowledge_base`'s pipeline (Qdrant client, embedding model, reranker) has several real network- and resource-dependent failure points. As this project adds more tools (Chapter 9's syllabus references `lookup_product_catalog` and `check_sender_history` for Topic 5), the number and variety of realistic failure modes grows substantially, making this topic's discipline increasingly load-bearing.

---

### 2. Internal Working — Step by Step

**The three distinct failure categories, each needing different handling:**

1. **Input errors** (the tool receives arguments it cannot process correctly) — e.g. a `reference_number` that's an empty string despite the schema requiring it, or a `query` for `search_knowledge_base` that's empty after Chapter 9 Topic 2's filler-stripping accidentally removes everything. Handling: validate defensively (Topic 2's principle) and return a structured error response, never let it propagate into a lower-level exception.
2. **Transient infrastructure errors** (the tool's dependencies are temporarily unavailable) — a network timeout connecting to Qdrant, a rate limit from an external API, a temporary database connection failure. Handling: **retry with backoff** — these failures often resolve themselves on a subsequent attempt, and blindly failing on the first error wastes a recoverable situation.
3. **Persistent/logical errors** (something is genuinely, non-transiently wrong) — a bug in the backing function, a fundamentally malformed query that will fail on every retry identically, a permanently misconfigured connection string. Handling: **fail fast and report clearly** — retrying a persistent error just wastes time and delays the inevitable, correct outcome (surfacing the failure).

**The retry-with-backoff pattern, step by step:**

1. Attempt the operation (e.g. the Qdrant query inside `search_knowledge_base`).
2. If it raises a transient-category exception (timeout, connection error), wait a short delay, then retry.
3. Each subsequent retry waits *longer* than the last (exponential backoff) — this avoids hammering an already-struggling downstream service with immediate retries, which can make a transient problem worse (a well-known systems reliability anti-pattern called a "retry storm").
4. After a maximum number of retries, give up and return a structured, honest failure response — never retry indefinitely, which risks the same runaway-cost problem `max_steps` guards against in Topic 1's agent loop.

**What the model receives when a tool genuinely fails, after exhausting retries:**

- A structured `tool_result` explicitly indicating failure, e.g. `{"error": True, "error_type": "service_unavailable", "message": "Unable to search the knowledge base right now."}` — this must still be a valid `tool_result` block (the API layer doesn't care whether the *content* represents success or failure, only that it's a well-formed response to the tool call), giving the model something concrete to reason about (e.g. apologize and suggest the customer try again later, or fall back to answering with a caveat) rather than the loop breaking entirely.

---

### 3. How It Is Implemented in This Project

```python
import time
from qdrant_client.http.exceptions import ResponseHandlingException  # illustrative transient error type

TRANSIENT_ERROR_TYPES = (ResponseHandlingException, TimeoutError, ConnectionError)


def search_knowledge_base_with_resilience(query: str, top_k: int = 5,
                                           max_retries: int = 3, base_delay: float = 0.5) -> dict:
    """search_knowledge_base (Chapter 9 Topic 3) wrapped with retry-with-backoff
    for TRANSIENT errors, and clean, structured failure reporting for
    PERSISTENT errors -- never lets an exception propagate uncaught into
    the agent loop."""

    # Input validation FIRST (Topic 2's principle) -- fail fast on obviously bad input
    if not query or not query.strip():
        return {"found": False, "error": True, "error_type": "invalid_input",
                "message": "Query was empty after preprocessing."}

    last_exception = None
    for attempt in range(max_retries):
        try:
            # The actual Chapter 7/9 retrieval pipeline call
            results = run_full_retrieval_pipeline(query, top_k=top_k)
            return {"found": len(results) > 0, "chunks": results}

        except TRANSIENT_ERROR_TYPES as e:
            last_exception = e
            if attempt < max_retries - 1:
                delay = base_delay * (2 ** attempt)  # exponential backoff: 0.5s, 1s, 2s...
                time.sleep(delay)
                continue
            # Exhausted retries -- fall through to structured failure below

        except Exception as e:
            # PERSISTENT/unexpected error -- do NOT retry, fail fast and report clearly
            return {"found": False, "error": True, "error_type": "unexpected_error",
                    "message": f"An unexpected error occurred: {type(e).__name__}"}

    # Reached only if all retries were exhausted on a TRANSIENT error
    return {"found": False, "error": True, "error_type": "service_unavailable",
            "message": "The knowledge base search is temporarily unavailable. "
                       "Please inform the customer we'll follow up shortly."}


def validate_fd_reference_with_resilience(reference_number: str) -> dict:
    """validate_fd_reference (Chapter 10 Topic 2) with the same error-handling
    discipline applied -- even though its current CSV-based implementation
    has few realistic transient failure modes, the PATTERN should be
    consistent across every tool, anticipating a future migration to a
    real networked database (Chapter 6 Topic 8's migration-trigger discussion)."""

    if not reference_number or len(reference_number.strip()) < 6:
        return {"found": False, "error": True, "error_type": "invalid_input",
                "message": "Reference number format is implausibly short."}

    try:
        record = get_fd_record(reference_number.strip())
    except Exception as e:
        return {"found": False, "error": True, "error_type": "unexpected_error",
                "message": f"Lookup failed: {type(e).__name__}"}

    if record is None:
        return {"found": False}

    return {"found": True, "status": record["status"], "fd_amount_inr": record["fd_amount_inr"]}
```

- Critically, in `run_agent()`, the code that calls these functions and packages results into `tool_result` blocks does **not** need special-case logic for the error path — because the error response is *already* a well-formed dict, `json.dumps(result)` and the existing `tool_result` packaging works identically whether `result` represents success or a handled failure. This is the payoff of designing errors as structured data rather than as exceptions that would need separate handling at the call site.

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **Retry storms**: if many concurrent requests hit a struggling downstream service simultaneously and all retry on the same fixed schedule, retries can synchronize and repeatedly overwhelm the recovering service right as it starts to come back — **jitter** (adding a small random variation to each retry's delay) is the standard mitigation, spreading retries out in time rather than having them cluster.
- **Distinguishing "genuinely not found" from "failed to check"**: `{"found": False}` (Chapter 9 Topic 3's clean not-found case) and `{"found": False, "error": True, ...}` (this topic's failure case) must be clearly distinguishable in the response structure — conflating them (e.g. both just returning `found: False` with no error flag) would make the model, and any downstream monitoring, unable to tell "this reference number doesn't exist" from "we couldn't check whether it exists," which require completely different customer-facing responses (a clear, confident "no record found" vs. an apologetic "we're having trouble checking right now").
- **Latency cost of retries**: exponential backoff with 3 retries at 0.5s/1s/2s delays adds up to 3.5 seconds of added latency in the worst case (all retries exhausted) before returning a failure — this must be weighed against the overall request latency budget (a customer-facing synchronous flow can't retry indefinitely) and should itself be monitored as a distinct latency contributor.
- **Monitoring**: track retry rate (how often a transient error occurs at all), retry-exhaustion rate (how often all retries fail, indicating the downstream service was down for a sustained period, not just a blip), and the breakdown of `error_type` values returned over time — a rising `service_unavailable` rate for `search_knowledge_base` specifically warrants investigating the Qdrant/embedding infrastructure health, separate from investigating the agent logic itself.
- **Cost**: retries multiply the cost of whatever operation is being retried (e.g. 3 embedding model calls instead of 1, in the worst case) — for expensive operations (an LLM-based check, per Chapter 8 Topic 4's Tier 2), retry cost should be weighed carefully, and a lower `max_retries` may be appropriate for expensive operations than for cheap ones like a local database lookup.
- **Security**: an error message returned to the model (and potentially, indirectly, surfaced to a customer) must never leak internal implementation details that could aid an attacker — `f"An unexpected error occurred: {type(e).__name__}"` is safer than including the full exception message or stack trace, which might reveal internal file paths, library versions, or other infrastructure details.
- **Deployment**: `max_retries` and `base_delay` should be configurable (environment variables or config, not hardcoded magic numbers) so they can be tuned per-environment (a staging environment might want faster failure for quicker debugging, while production might tolerate more retries for better resilience) without a code change.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **How many retries, and how long a backoff?**: more retries and longer backoff increase resilience against genuinely transient blips but also increase worst-case latency for the *un-recoverable* failure case, where all retries are wasted time before the inevitable failure response — there's a real trade-off between resilience and worst-case latency that should be tuned based on the specific operation's typical failure duration (a network blip might resolve in under a second; a downstream service restart might take much longer, potentially rendering short retries useless anyway).
- **Should a tool's structured error response ever be surfaced verbatim to the customer, or always paraphrased by the model?**: this project's design lets the model see the structured error and decide how to communicate it — this is more flexible (the model can phrase an apology naturally) but relies on the model handling the error gracefully and appropriately, rather than, say, verbatim repeating an internal `error_type` string to the customer. The system prompt should include explicit guidance on how to communicate tool failures to customers, treating this as seriously as the "only use provided context" guidance from Chapter 9 Topic 6.
- **Real-time dilemma: retry now (adding latency) vs. fail fast and let the agent's outer logic decide whether to retry the entire tool call from a fresh model turn**: this topic's approach retries *within* the tool's backing function, transparently to the model. An alternative architecture could let the tool fail fast every time, and rely on the model itself deciding to call the tool again on a subsequent turn if the first attempt's error response suggests trying again might help — trading some latency efficiency (in-function retry avoids extra full model round-trips) for architectural simplicity and giving the model more visibility into what's happening. This project's in-function retry approach is more efficient but hides the retry process from the model entirely; the trade-off should be revisited if debugging opacity from hidden retries ever becomes a real problem.

---

### 6. Alternatives and When to Use Each

- **No error handling (letting exceptions propagate, this project's implicit state before this topic)**: acceptable only during early prototyping when reliability isn't yet a concern — a crashed agent loop on any tool failure is not acceptable for any production system.
- **In-function retry-with-backoff (this topic's primary recommendation)**: the correct default for tools with realistic transient failure modes (network-dependent operations like `search_knowledge_base`'s Qdrant/embedding calls) — invisible to the model, efficient, and directly addresses the most common class of recoverable failures.
- **No retry, immediate structured failure (appropriate for `validate_fd_reference`'s current CSV-based implementation)**: when a tool's backing operation has no realistic transient failure mode (a local file read essentially always either works or reveals a genuine, non-transient problem), retry logic adds complexity without corresponding benefit — though the *structured error response* discipline should still apply even without retry logic, anticipating a future migration to a networked data source.
- **Circuit breaker pattern (a more advanced technique worth knowing about, not yet needed at this project's scale)**: rather than retrying every single failed call, a circuit breaker tracks recent failure rates for a downstream dependency and, once failures exceed a threshold, stops attempting calls entirely for a cooldown period, failing fast immediately without even trying — appropriate for high-volume production systems where retrying against a *known*-currently-down service wastes resources at scale; worth adopting once this project's production volume and dependency count justify the added complexity.

---

### 7. Common Mistakes and Production Failures

- Letting an unhandled exception from a backing function propagate up through the agent loop, crashing the entire request rather than gracefully returning a structured failure the model can reason about.
- Retrying persistent/logical errors (a genuine bug, a malformed query that will fail identically every time) exactly as if they were transient, wasting time on retries that can never succeed.
- Not distinguishing "genuinely not found" from "failed to check" in the response structure, leaving the model (and downstream monitoring) unable to tell these apart.
- Retrying without backoff or jitter, risking retry storms that worsen an already-struggling downstream service's recovery.
- Leaking internal implementation details (stack traces, file paths, library-specific exception messages) into error responses that could reach the model's context and potentially, indirectly, the customer.
- Hardcoding retry counts and delays rather than making them configurable per environment.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: What is the difference between a transient error and a persistent error, and why does this distinction matter for retry logic?**
A: A transient error (a network timeout, a temporary connection failure) is likely to resolve on its own if retried after a brief delay — the underlying condition causing the failure is temporary. A persistent error (a genuine code bug, a fundamentally malformed input) will fail identically on every retry, since the underlying cause doesn't change between attempts. Retrying a persistent error wastes time and delays the inevitable, correct outcome of surfacing the failure — only transient errors should trigger retry logic.

**Q: Why should a tool's error response be structured data (a dict with an error flag) rather than an unhandled exception?**
A: The agent loop's tool-result packaging (`json.dumps(result)`, appending as a `tool_result` block) doesn't need special-case logic to handle success versus failure if both are represented as well-formed dicts — an unhandled exception would crash the calling code entirely, breaking the agent loop, whereas a structured error response flows through the exact same code path as a successful response, giving the model something concrete and well-formed to reason about on its next turn.

**Intermediate:**

**Q: Why does exponential backoff use increasing delays between retries rather than a fixed delay?**
A: A fixed, short delay retried immediately and repeatedly can worsen an already-struggling downstream service's ability to recover, especially under concurrent load from many simultaneous requests (a "retry storm"). Exponential backoff spaces out retries with increasing gaps, giving the downstream service more time to recover with each successive attempt, and reduces the aggregate load many concurrent clients place on a recovering service compared to all retrying on the same fixed, short schedule.

**Q: `validate_fd_reference`'s current implementation reads from a local CSV file. Does it need retry-with-backoff logic today? Would your answer change if this project migrated to a networked database?**
A: Today, no — a local file read has essentially no realistic transient failure mode; it either succeeds or reveals a genuine, non-transient problem (file missing, permissions issue) that retrying wouldn't fix. However, the structured error-response discipline (returning a clean `{"found": False, "error": True, ...}` rather than letting an exception propagate) should still be applied even without retry logic, specifically because a future migration to a networked database (a realistic possibility, per Chapter 6 Topic 8's migration-trigger discussion) would introduce genuine transient failure modes — designing the error-response shape consistently now means the retry logic can be added later without changing the tool's external contract or the agent loop's handling of it.

**Advanced:**

**Q: Design the full error-handling and retry strategy for `search_knowledge_base`, considering that its pipeline involves multiple stages (embedding call, Qdrant query, reranking model call), each with potentially different failure characteristics.**
A: Each stage should be wrapped with error handling appropriate to its own failure profile rather than treating the entire pipeline as one opaque unit. The embedding model call (local inference) has different failure characteristics than the Qdrant query (network-dependent) or a reranking API call (if using a managed service like Cohere, per Chapter 7 Topic 7's discussion) — a network-dependent stage warrants retry-with-backoff, while a local inference failure is more likely a persistent, non-transient problem (a corrupted model file, an OOM condition) better handled by failing fast with a clear error. The overall function should catch failures at each stage, log which specific stage failed (extending Chapter 9 Topic 3's full pipeline-stage logging to also capture failure points, not just successful traces), and return a structured error response indicating which capability was unavailable (e.g. "reranking unavailable, returning unranked results" as a degraded-but-still-useful fallback, versus "retrieval entirely unavailable" as a full failure) — a graceful degradation strategy is often better than an all-or-nothing failure when only one stage of a multi-stage pipeline is affected.

**Q: A tool's retry logic is discovered to be masking a real, underlying bug — every call fails on the first attempt due to a code error, succeeds on retry due to an unrelated race condition, and the system has been "working" in production for months while silently retrying on every single request. How would you detect this, and what does it reveal about retry logic's risks?**
A: This reveals a real risk of retry logic: it can mask underlying problems by making them invisible in aggregate success-rate metrics, while silently paying a hidden cost (latency, resource usage) on every request. Detection requires monitoring not just overall success rate but the *retry rate itself* as a first-class metric — if a very high percentage of "successful" calls actually required at least one retry, this is a strong signal something is systematically wrong even though the end-to-end success rate looks fine. This specific scenario (first-attempt failure masked by an unrelated race condition on retry) underscores why retry-rate monitoring, not just success-rate monitoring, is essential — a system that "always eventually succeeds" via retries can hide a real, first-attempt bug indefinitely unless retry frequency is explicitly tracked and investigated when it's unexpectedly high.

**Scenario-based:**

**Q: In production, `search_knowledge_base`'s retry-exhaustion rate spikes for a 10-minute window, then returns to normal. Walk through your incident response.**
A: During the spike, the structured error responses should have ensured the agent loop kept functioning (not crashing), with the model presumably falling back to some form of "I'm having trouble accessing our policy information right now" response for affected requests, per the system prompt guidance on handling tool failures gracefully. Post-incident, correlate the timing of the spike against infrastructure logs for the underlying dependencies (Qdrant connection logs, embedding model service health, network infrastructure) to identify the root cause — a deployment happening during that window, a resource exhaustion event, or an external network issue are all plausible causes worth checking in order of likelihood. Additionally, review whether the retry configuration (max_retries, backoff delays) was appropriate for this specific incident's duration — if the underlying issue resolved faster than the configured retries could detect (e.g. resolved in 2 seconds but retries were configured for a 10-second window), some requests during the spike may have unnecessarily failed despite the underlying problem being brief; if the reverse is true, some requests may have added unnecessary latency retrying against a problem that persisted well beyond what retries could reasonably help with.

---

### 9. Hidden Concepts and Prerequisites

- **This topic is a direct application of general distributed systems reliability patterns** — retry-with-backoff, jitter, and circuit breakers are well-established patterns from distributed systems and microservices engineering, predating LLM tool-calling entirely; recognizing this connects tool engineering to a broader, transferable body of systems engineering knowledge rather than treating it as an LLM-specific novelty.
- **The concept of "idempotency" is relevant and worth understanding**: a retried operation is only safe to blindly repeat if it's idempotent (running it multiple times has the same effect as running it once) — `get_fd_record()` (a read-only lookup) is naturally idempotent and safe to retry freely; a hypothetical future tool that *writes* data (e.g. updating a customer record) would need much more careful retry design, since retrying a non-idempotent write operation could cause duplicate or incorrect side effects (charging a penalty twice, for instance) — this project's tools are currently all read-only, but this consideration becomes critical the moment any write-capable tool is introduced.
- **This connects forward to Chapter 19's Observability & Guardrails chapter**, which will formalize the monitoring, tracing, and fallback-design principles touched on here (retry rate monitoring, structured error responses, graceful degradation) into a complete production observability strategy — this topic is the tool-level foundation that chapter builds on system-wide.

---

### 10. Revision Summary

> Tool failures fall into three categories requiring different handling: input errors (validate defensively, per Topic 2, and fail immediately with a clear structured response), transient infrastructure errors (retry with exponential backoff, since the underlying condition often resolves on its own), and persistent/logical errors (fail fast — retrying can never succeed since the cause doesn't change between attempts). Every failure mode must produce a structured, well-formed response (never an uncaught exception), distinguishing "genuinely not found" from "failed to check" so the model and downstream monitoring can respond appropriately to each. Exponential backoff with jitter avoids retry storms that can worsen a recovering downstream service's condition. `validate_fd_reference`'s current CSV-based implementation needs the structured-error-response discipline but not retry logic today, while `search_knowledge_base`'s multi-stage, network-dependent pipeline genuinely benefits from stage-appropriate retry handling and graceful degradation. Retry rate itself (not just success rate) must be monitored, since retries can silently mask an underlying, systematically-failing-on-first-attempt bug indefinitely if only aggregate success is tracked. Idempotency matters critically the moment any write-capable tool is introduced, since retrying a non-idempotent operation can cause duplicate or incorrect side effects.

---
