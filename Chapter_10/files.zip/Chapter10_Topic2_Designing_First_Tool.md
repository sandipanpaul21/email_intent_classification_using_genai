# Chapter 10: Tool Engineering

## Topic 2: Designing Your First Tool — `validate_fd_reference(text)`

---

### 1. Concept, Intuition, and Why It Exists

- Topic 1 explained tool calling mechanically. This topic asks a narrower, practical question: given a real need ("verify whether a candidate FD reference number is genuine before trusting it"), how do you actually *design* the tool — what should its function signature look like, what should it validate before ever reaching the database, and what should it return?
- The core design principle: a tool's Python function is not just "the thing that runs" — it's a boundary between the model's potentially-imperfect extraction of information from unstructured text (the email) and your system's structured, trusted data (the FD database). Good tool design treats this boundary defensively, exactly as any function accepting external input should.
- This project's actual `validate_fd_reference` already exists (Chapter 3) — this topic is where its design choices are explained and justified from first principles, and where the natural next question ("what would I change or add if I were designing this today, with everything else in this project now built") gets explored.

---

### 2. Internal Working — Step by Step

**Designing the function signature:**

1. **What does the tool need as input?** A single `reference_number: str` — the model extracts this from the email text itself; the tool doesn't need the whole email, only the specific candidate value.
2. **What does the tool need to return?** Enough structured information for the model to make a good decision on its next turn — not just `True`/`False`, but `{"found": bool, "status": str, "fd_amount_inr": int, ...}` when found, giving the model rich enough data to incorporate into its reasoning (e.g. noting a discrepancy between what the customer claims and what the record shows, per Chapter 3's system prompt guidance).
3. **What should the tool validate BEFORE touching the database?** Defensive input validation — is `reference_number` even plausibly well-formed (right length, right character pattern) before spending a database query on it? This matters both for correctness (garbage in doesn't need to reach the data layer) and for the tool's own robustness against a model that might occasionally pass malformed input despite the schema.

**The actual internal flow of `validate_fd_reference`:**

1. Receive `reference_number` from the model's `tool_use` block input.
2. Perform basic format sanity-checking (not full validation — that's what the database lookup itself effectively does).
3. Call `get_fd_record(reference_number)` — the actual data access function, kept *separate* from the tool's own logic, so the data access layer can be tested, reused, and reasoned about independently of the tool-calling mechanism wrapping it.
4. Return a structured dict: `found=True` with relevant fields if a match exists, `found=False` if not — never raising an unhandled exception back through the tool-calling layer (Topic 4 covers this in depth).

---

### 3. How It Is Implemented in This Project

```python
# fd_database.py -- the DATA ACCESS layer, deliberately separate from the tool wrapper
def get_fd_record(reference_number: str) -> dict | None:
    """Pure data access -- no tool-calling concerns here at all.
    This function could be called from a completely different context
    (a batch script, a different agent, a unit test) with zero coupling
    to the tool-calling mechanism. This separation is a deliberate,
    important design choice."""
    # Reads fd_master_database.csv (or a real DB in production), returns
    # a matching record dict or None
    ...


# The TOOL WRAPPER -- this is what gets registered in TOOLS and invoked
# by the model via tool_use
def validate_fd_reference(reference_number: str) -> dict:
    """Tool-calling-specific wrapper around get_fd_record(). Handles:
    - basic defensive input sanity-checking
    - the found/not-found response SHAPE the model has learned to expect
    - (Topic 4 will add) error handling so this never raises uncaught"""

    # Defensive check: is this even plausibly a reference number, before
    # spending a lookup on it? (Real format: e.g. 2 letters + 4 digits + "FD" + 4+ digits)
    if not reference_number or len(reference_number.strip()) < 6:
        return {"found": False, "reason": "Reference number format is implausibly short."}

    record = get_fd_record(reference_number.strip())

    if record is None:
        return {"found": False}

    return {
        "found": True,
        "status": record["status"],           # e.g. "Active", "Matured", "Closed (Premature)"
        "fd_amount_inr": record["fd_amount_inr"],
        "maturity_date": record.get("maturity_date"),
    }


VALIDATE_FD_REFERENCE_TOOL = {
    "name": "validate_fd_reference",
    "description": (
        "Call this whenever the email contains something that looks like an FD "
        "reference number, before relying on it to decide the label or describe "
        "the account's status. Returns found=False if no such reference exists "
        "in the system -- do not assume a reference is real just because it "
        "matches the expected text pattern."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "reference_number": {"type": "string", "description": "The candidate reference number found in the email."}
        },
        "required": ["reference_number"],
    },
}
```

- Notice the description explicitly warns the model: "do not assume a reference is real just because it matches the expected text pattern" — this is deliberate tool-design craft, not accidental wording. It's specifically countering a plausible model behavior (assuming pattern-match = validity) that would defeat the tool's entire purpose.

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **The model might extract a subtly wrong reference number from messy text**: a customer email with a typo, OCR-style garbling (if the email included a scanned attachment reference), or two similar-looking reference numbers mentioned could lead the model to pass a slightly incorrect string — the tool has no way to know this happened, and `found: False` from a genuinely-existing-but-mistyped reference looks identical to `found: False` from a customer inventing a reference number. This ambiguity is a real, hard-to-fully-solve edge case; the best mitigation is prompting the model to double-check its extraction against the original email text before finalizing a `found: False`-driven answer.
- **Separating `get_fd_record()` from `validate_fd_reference()` pays off in testing**: because the data access layer has zero tool-calling coupling, it can be unit tested directly with simple input/output assertions, independent of any model or API call — a testing discipline this project should apply to every tool's backing logic (Topic 6 formalizes this further).
- **Monitoring**: track the `found: False` rate specifically for `validate_fd_reference` over time — a rising rate could indicate increasingly poor extraction from a shifting email phrasing pattern (worth cross-referencing with Chapter 9 Topic 2's query transformation work), a genuine increase in customers referencing non-existent or very old records, or a data freshness problem in the underlying `fd_master_database.csv`.
- **Latency and cost**: `get_fd_record()` is a fast, local CSV lookup at this project's current scale — negligible cost. In a production system with a real database, this becomes a network call with its own latency profile, requiring the same defensive timeout/retry thinking Topic 4 covers.
- **Security**: `reference_number` is model-extracted text ultimately derived from customer-controlled email content — even though this project's use case is a benign lookup key (not a file path or SQL fragment constructed via string concatenation), the general principle from Chapter 9 Topic 4 applies: never use externally-influenced strings for anything beyond a parameterized, safe lookup operation. If this were ever backed by a real SQL database, `reference_number` must be a bound parameter, never concatenated into a query string.
- **Deployment**: as `fd_master_database.csv` is replaced by a real production database, `get_fd_record()`'s internals change, but its function signature and contract (input a reference number string, output a record dict or None) should remain stable — this is exactly what the separation between data access and tool wrapper is designed to make possible without touching the tool-calling logic at all.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **How much should the tool return vs. how much should the model have to ask for separately?**: returning a rich record (status, amount, maturity date) in one call is more efficient (one tool call answers several potential follow-up questions) than a minimal `found: True/False` requiring several separate, narrower tool calls — but risks returning more customer data than a specific question actually needed, a minor but real over-exposure consideration in a regulated domain. This project's current design favors efficiency; a stricter design could add parameters letting the model request only specific fields.
- **Defensive validation inside the tool vs. relying entirely on the model's correct extraction**: adding format sanity-checks (like the length check shown above) adds a small amount of tool complexity but catches obviously-malformed input before it reaches the data layer — a cheap, worthwhile defensive layer, following the general software engineering principle of never trusting input at a function boundary, regardless of how reliable the calling code (in this case, the model) is expected to be.
- **Should the tool's `description` field explicitly warn against specific model failure modes (like the pattern-match-isn't-validity warning shown above)?**: yes, and this project's actual implementation already does this — tool descriptions are prompt engineering, not just documentation, and should be iteratively refined based on observed model behavior exactly like any other prompt (Chapter 9 Topic 6's discipline applied specifically to tool descriptions).

---

### 6. Alternatives and When to Use Each

- **Rich, single-call tool response (this project's approach)**: best when the tool's underlying data access is cheap and the response fields are commonly needed together — reduces total tool-call round-trips.
- **Minimal, parameterized tool response (request specific fields only)**: best when the underlying data is sensitive enough that minimizing exposure per call matters more than round-trip efficiency, or when the underlying data source is expensive to query in full (e.g. an expensive downstream API where fetching unnecessary fields has a real cost).
- **Combining validation and lookup into one step vs. separate `is_valid_format()` and `lookup()` tools**: this project combines them into one tool call for simplicity — a more granular design could expose format validation as a separate, even cheaper pre-check tool the model could call first, though this adds tool-count overhead (Topic 1's tool-proliferation consideration) for a benefit that's likely marginal at this project's current scale.

---

### 7. Common Mistakes and Production Failures

- Coupling the data access logic directly inside the tool-calling function, making it impossible to unit test or reuse the lookup logic independent of the agent architecture.
- Not defensively validating input format before spending a data access call on obviously malformed input.
- Writing a tool description that only states *what* the tool does without addressing *when not* to trust its inputs or outputs (like the pattern-match-isn't-validity warning) — missing an opportunity to proactively correct a plausible model misunderstanding.
- Returning inconsistent response shapes across different failure cases (e.g. sometimes `None`, sometimes an empty dict, sometimes `{"found": False}`) — the model needs a single, predictable, structured response shape to reason about reliably, echoing Chapter 9 Topic 3's explicit `found: False` requirement.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: Why is `get_fd_record()` kept as a separate function from `validate_fd_reference()`, rather than combining the data access logic directly into the tool function?**
A: Separation of concerns — `get_fd_record()` is pure data access logic with zero tool-calling coupling, meaning it can be unit tested, reused in other contexts (a batch script, a different agent), and reasoned about independently of anything related to the model or the API. `validate_fd_reference()` is the thin, tool-calling-specific wrapper that adds input validation and shapes the response the way the tool-calling loop and the model expect.

**Q: What does the tool description's warning "do not assume a reference is real just because it matches the expected text pattern" actually protect against?**
A: A plausible model failure mode where the model, having extracted text that superficially looks like a valid reference number format, treats that pattern match as sufficient evidence of validity and skips actually verifying it against the real database — defeating the entire purpose of having the tool. This is proactive prompt engineering embedded in the tool description, not just documentation.

**Intermediate:**

**Q: A customer's email contains a reference number with a typo, causing `validate_fd_reference` to correctly return `found: False` for a record that actually exists under the correct spelling. How would you address this at the tool-design level?**
A: This is fundamentally an extraction-accuracy problem, not something the tool itself can fully solve, since the tool only ever sees whatever string the model extracted. Mitigations at the tool-design level: return a more informative response when not found (rather than a bare `found: False`) that might prompt the model to reconsider, or have the tool description explicitly instruct the model to double-check its extracted reference number against the original email text for common typo patterns before treating a not-found result as conclusive. A more robust fix might involve fuzzy matching in `get_fd_record()` itself (e.g. Levenshtein distance against known reference numbers) if this pattern proves common enough in production to justify the added complexity and risk of incorrect fuzzy matches.

**Q: Why does the tool return a rich record (status, amount, maturity date) in one response rather than requiring the model to ask for each field separately?**
A: Given the underlying data access (`get_fd_record()`) is cheap and fast (a local CSV lookup, or a single indexed database query in production), returning the full commonly-needed record in one call avoids multiple round-trips for a model that will very likely need more than one field to answer a typical customer question, reducing both latency (fewer loop iterations) and cost (fewer total API calls) — a deliberate efficiency trade-off, accepting slightly broader data exposure per call in exchange for round-trip efficiency.

**Advanced:**

**Q: Design the input validation logic for `validate_fd_reference` more rigorously than the illustrative length check shown, given this project's actual reference number format (e.g. two letters, four digits, "FD", four-plus digits).**
A: Implement a regex-based format check matching the known reference number pattern (something like `^[A-Z]{2}\\d{4}FD\\d{4,}$`) as a fast pre-check before any data access call — this catches obviously malformed input (wrong length, wrong character types, missing the "FD" marker) without touching the database at all. Critically, a failed format check should still return a structured, informative response (e.g. `{"found": False, "reason": "format_invalid"}` distinct from `{"found": False, "reason": "not_in_system"}`) so the model — and any downstream monitoring — can distinguish "this wasn't even a plausible reference number" from "this looked like a reference number but doesn't exist," which are genuinely different situations requiring different follow-up reasoning from the model.

**Q: How would you evolve `validate_fd_reference`'s design if this project needed to support looking up records by mobile number in addition to reference number, given the existing `fd_master_database.csv` schema (which includes `Mobile_Number`)?**
A: This requires a genuine design decision, not just an implementation change — extend `validate_fd_reference`'s single `input_schema` to optionally accept either a `reference_number` or a `mobile_number` field (with the tool description clarifying at least one is required), or introduce this as an entirely new, separate tool (`lookup_by_mobile_number`) with its own schema and description. The separate-tool approach keeps each tool's schema simple and its description precisely scoped (avoiding the tool-selection ambiguity Chapter 9 Topic 1 discussed for overlapping tool purposes), at the cost of one more tool in the toolset (Topic 1's proliferation trade-off). Given mobile-number lookup is a genuinely different query pattern with different security/PII implications (a mobile number can match multiple records for a customer with several FDs, unlike a reference number which is unique), I'd lean toward a separate tool with its own careful access-scoping design, consistent with Chapter 9 Topic 4's principle of not blurring genuinely distinct data-access patterns into one overly-flexible tool.

**Scenario-based:**

**Q: Production monitoring shows `validate_fd_reference`'s `found: False` rate has doubled over the past month, with no known change to the underlying database or customer email patterns. Diagnose.**
A: First, rule out a data freshness issue — confirm `fd_master_database.csv` (or its production database equivalent) is being updated correctly and isn't silently stale or missing recent records (a Chapter 4/6 ingestion-adjacent concern, now applied to structured customer data rather than the knowledge base). If data freshness is confirmed fine, sample actual `found: False` cases and check whether the extracted `reference_number` values look like genuine format-plausible-but-nonexistent references, or whether there's a pattern of malformed extraction (e.g. a recent uptick in email formatting that confuses the model's extraction, worth cross-referencing against any recent changes to how customers submit emails, like a new web form template). This is exactly the kind of investigation that benefits from the full request-tracing discipline established in Chapter 9 Topic 3 — reviewing the original email text alongside the extracted reference number for a sample of failing cases usually reveals which category the problem falls into.

---

### 9. Hidden Concepts and Prerequisites

- **This topic is an instance of the general software engineering principle of "defensive programming at trust boundaries"** — any function receiving input from a source you don't fully control (user input, network calls, and here, model-extracted text) should validate that input rather than assuming it's well-formed, regardless of how reliable the source is expected to be in the common case.
- **The separation between `get_fd_record()` (data access) and `validate_fd_reference()` (tool wrapper) is a specific instance of the "adapter pattern"** from general software design — a thin layer adapting one interface (a general-purpose data access function) to the specific shape/conventions another system (the tool-calling loop) expects, without modifying the underlying logic itself.
- **This connects directly forward to Topic 3 (Writing Tool Schemas)**: the `input_schema` design choices touched on here (what fields, what types, what's required) are the specific focus of the next topic — this topic covered the *function design* around the schema; Topic 3 covers the *schema design* itself in depth.

---

### 10. Revision Summary

> Designing a tool means designing the boundary between the model's imperfect extraction of information from unstructured text and your system's trusted, structured data. `validate_fd_reference` separates data access (`get_fd_record()`, reusable and independently testable) from the tool-calling wrapper (which adds defensive input validation and shapes the response into a consistent, predictable structure the model has learned to expect). Tool descriptions are prompt engineering — this project's explicit warning against treating pattern-match as validity is a deliberate correction of a plausible model failure mode, not incidental documentation. Response design trades round-trip efficiency (returning a rich record in one call) against minimal data exposure per call, and should be chosen based on the sensitivity and cost profile of the underlying data source. Every tool should return a consistent, structured response shape even in failure cases, distinguishing genuinely different failure reasons (malformed input vs. not-found) rather than collapsing them into one ambiguous signal.

---
