# Chapter 10: Tool Engineering

## Topic 3: Writing Tool Schemas the Model Can Call Reliably

---

### 1. Concept, Intuition, and Why It Exists

- Topic 2 designed a tool's Python function. This topic focuses specifically on the `input_schema` and `description` fields — the part of a tool definition that is *entirely* what the model sees and reasons from. A perfectly-implemented backing function is worthless if the schema around it confuses the model into calling it incorrectly, calling the wrong tool instead, or never calling it at all.
- The core principle: schema design is prompt engineering with structure. Every word in a `description`, every field name, every `type` and `enum` constraint in `input_schema` is training-time-learned-behavior-triggering text the model weighs when deciding what to do next — this is not a formality for documentation purposes, it is the single most leveraged piece of text in your entire tool-use system for the specific behavior of *tool selection and argument construction*.
- Why this deserves its own topic separate from Topic 2: a project can have excellent backing functions and mediocre schemas, or vice versa — these are genuinely separable skills, and this project's growing toolset (Chapter 9's `search_knowledge_base` alongside Chapter 3's original three) makes schema quality an increasingly important, increasingly first-class engineering concern as tool count grows.

---

### 2. Internal Working — Step by Step

**What makes a schema "reliable" — the specific properties to optimize for:**

1. **Unambiguous triggering conditions**: the `description` should state precisely *when* to call this tool, ideally with both positive examples (when to call it) and negative examples (when NOT to, especially contrasting with similar tools) — this project's `search_knowledge_base` description explicitly says "do NOT call this for simple FD-vs-Non-FD classification" specifically because `finalize_classification` exists and could otherwise be confused for the right choice in an ambiguous case.
2. **Self-documenting field names and types**: `reference_number: string` is immediately interpretable; a vaguely-named field like `value: string` forces the model to infer meaning purely from the description, increasing the chance of misuse. Field names carry real semantic weight in a schema the model reads as text.
3. **Constrained value spaces where possible**: using `"enum": ["FD", "Non-FD", "Multiple Category"]` (as `finalize_classification` already does for `label`) is far more reliable than an open `string` field with a description saying "one of FD, Non-FD, or Multiple Category" — an enum is a *hard* constraint the API can validate structurally; a free-text description of allowed values is a *soft* constraint the model might violate under unusual phrasing pressure.
4. **Required vs. optional fields, chosen deliberately**: marking a field `required` forces the model to always provide it, which is correct when the tool genuinely cannot function without it (like `reference_number` for `validate_fd_reference`) but wrong when a field is sometimes genuinely unavailable — an over-required schema can cause the model to fabricate a plausible-but-invented value just to satisfy the schema, a subtle and dangerous failure mode.
5. **Description length and specificity trade-off**: too terse ("looks up FD status") under-specifies triggering conditions; too verbose risks burying the actually-critical guidance in less important detail, and costs tokens on every single call (Topic 1's cost concern) — the right length is whatever reliably produces correct triggering behavior, validated empirically (Topic 6), not maximized for thoroughness alone.

---

### 3. How It Is Implemented in This Project — Schema Anti-Patterns and Fixes

```python
# ANTI-PATTERN: vague field name, no constraint, thin description
WEAK_SCHEMA_EXAMPLE = {
    "name": "classify",
    "description": "Classifies the email.",
    "input_schema": {
        "type": "object",
        "properties": {
            "value": {"type": "string"}  # what IS "value"? no hint at all
        },
        "required": ["value"],
    },
}

# THIS PROJECT'S ACTUAL SCHEMA: specific name, enum constraint, explicit reason field
FINALIZE_CLASSIFICATION_TOOL = {
    "name": "finalize_classification",
    "description": "Call this once you're ready to commit to a final label for the email.",
    "input_schema": {
        "type": "object",
        "properties": {
            "label": {"type": "string", "enum": ["FD", "Non-FD", "Multiple Category"]},  # HARD constraint
            "reason": {"type": "string"},  # forces the model to articulate its reasoning,
                                             # which also aids debugging and auditability
        },
        "required": ["label", "reason"],
    },
}

# THIS PROJECT'S search_knowledge_base -- explicit positive AND negative triggering examples
SEARCH_KNOWLEDGE_BASE_TOOL = {
    "name": "search_knowledge_base",
    "description": (
        "Call this when you need FD policy information you don't already know -- "  # positive
        "for example, questions about premature withdrawal penalties, interest rate "
        "rules, nominee provisions, or maturity procedures. Do NOT call this for "     # negative
        "simple FD-vs-Non-FD classification, and do NOT call this for looking up a "
        "specific customer's FD record -- use validate_fd_reference for that instead."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "A clear, self-contained policy question."}
        },
        "required": ["query"],
    },
}


def audit_schema_quality(tool: dict) -> list:
    """A checklist-style audit function -- not a substitute for empirical
    testing (Topic 6), but a fast, cheap first-pass review before a new
    tool schema is even tried against real queries."""
    issues = []

    if len(tool["description"]) < 20:
        issues.append("Description is very short -- likely under-specifies triggering conditions.")

    if "do not" not in tool["description"].lower() and "don't" not in tool["description"].lower():
        issues.append("No explicit negative example -- consider whether confusion with another "
                       "tool is possible, and if so, add a 'do NOT call this for...' clause.")

    for field_name, field_def in tool["input_schema"]["properties"].items():
        if field_name in ("value", "data", "input", "text"):
            issues.append(f"Field '{field_name}' has a generic, non-descriptive name.")
        if field_def.get("type") == "string" and "enum" not in field_def and "description" not in field_def:
            issues.append(f"Field '{field_name}' is an unconstrained string with no description -- "
                          f"consider an enum if the value space is actually limited.")

    return issues


print("Auditing the weak example schema:")
for issue in audit_schema_quality(WEAK_SCHEMA_EXAMPLE):
    print(f"  - {issue}")
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **Schema changes are prompt changes and need the same evaluation discipline**: modifying a tool's description or field structure is functionally identical to modifying a system prompt (Chapter 9 Topic 6) — it should be validated against a labeled test set of expected tool-calling behavior (Topic 6) before deployment, never shipped based on "this reads more clearly to me" alone.
- **Over-constraining with enums can be brittle to legitimate edge cases**: `finalize_classification`'s `label` enum works because this project has exactly three well-defined categories that don't change — but an enum used somewhere the value space genuinely might need to expand (e.g. a product name field, if new products launch regularly per Chapter 9 Topic 8's scenario) would require a schema update every time a new value is needed, a maintenance burden worth weighing against the reliability benefit.
- **The `required` field trap**: marking a field required when it's sometimes genuinely unknown can cause the model to invent a plausible value rather than correctly indicating absence — if a field can legitimately be missing, either make it optional with clear guidance on what absence means, or provide an explicit "unknown" sentinel value the model can supply instead of fabricating something.
- **Monitoring schema-related failures specifically**: track cases where a tool call's arguments, while schema-valid, are semantically implausible (e.g. a `reference_number` that doesn't match the expected format despite passing the loose `string` type check) — this is a signal the schema's soft constraints (description-based guidance) aren't sufficient and a harder constraint (a regex pattern property, where the API supports it, or more defensive validation in the backing function per Topic 2) may be needed.
- **Cost**: longer, more example-laden descriptions cost more tokens per call, compounding at this project's production volume — there's a genuine trade-off between schema clarity (more examples, more explicit negative cases) and token cost that should be weighed, though correctness generally should win this trade-off given the cost of a wrong tool call (wasted latency, a wrong database lookup, or worse, a missed retrieval per Chapter 9 Topic 1's under-triggering risk) usually exceeds the marginal token cost of a clearer description.
- **Security**: schema descriptions are part of the model's context and thus part of the prompt-injection attack surface (Topic 1's point, restated specifically for schemas) — a description containing unusual or manipulable phrasing could theoretically be exploited if an attacker could somehow influence tool registration, though this is a much less common attack vector than content-based injection since tool schemas are typically developer-controlled, not user-controlled.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **How many negative/contrastive examples should a description include?**: enough to disambiguate from genuinely confusable alternatives (this project's `search_knowledge_base` contrasts with both `finalize_classification` and `validate_fd_reference`, since both are plausible confusions), but not so many that the description becomes bloated and its core positive triggering condition gets buried — a judgment call that should be validated against actual observed tool-selection errors (Topic 6), not maximized preemptively.
- **Enum constraints vs. free-text with description-based guidance**: enums are strictly more reliable when the value space is genuinely fixed and known — there is little reason not to use an enum in that case, since it's a strictly stronger guarantee at no meaningful cost. The trade-off only exists when the value space might need to grow, in which case the maintenance cost of updating the enum must be weighed against the reliability benefit.
- **Field-level descriptions vs. relying on the tool-level description alone**: adding a `description` to individual `input_schema` properties (as shown for `search_knowledge_base`'s `query` field) is a specific reliability improvement — for tools with several fields, especially fields whose purpose isn't obvious from the name alone, field-level descriptions reduce the risk of the model confusing which value goes where, particularly relevant as tools grow more complex (Topic 5's multi-tool, multi-field agents).

---

### 6. Alternatives and When to Use Each

- **Thin, minimal schemas (only name + basic type, sparse description)**: only appropriate for extremely obvious, unambiguous tools with no plausible confusion against other tools in the same toolset — risky as a default given how much tool-selection accuracy depends on schema quality.
- **Rich, example-laden schemas with explicit positive/negative triggering guidance (this project's approach)**: the correct default once a toolset has more than one or two tools, or any potential for confusion between tools exists.
- **Schema versioning and change management (a more mature practice worth adopting as this project's toolset grows)**: treating schema changes with the same rigor as code changes — version control, change review, and before/after evaluation (Topic 6) — becomes increasingly important as more of this project's business logic depends on reliable tool-selection behavior.

---

### 7. Common Mistakes and Production Failures

- Using generic field names (`value`, `data`, `input`) that provide no semantic signal to the model beyond their type.
- Writing a description that states what a tool does but never states when NOT to use it, especially when a plausibly-confusable alternative tool exists in the same toolset.
- Marking a field `required` when it can legitimately be absent, risking the model fabricating a value to satisfy the schema rather than correctly signaling absence.
- Not using enums for genuinely fixed, known value spaces, relying instead on a free-text description that the model can (rarely, but non-zero probability) deviate from under unusual phrasing.
- Treating schema wording changes as low-stakes, "just documentation" edits rather than prompt-engineering changes requiring the same evaluation rigor as any other prompt modification.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: Why is a tool's `description` field considered a form of prompt engineering rather than mere documentation?**
A: The description is text the model actually reads and reasons over on every single API call to decide whether and how to invoke the tool — it directly influences model behavior the same way system prompt wording does. Poor wording produces poor tool-selection behavior regardless of how well-implemented the backing function is, exactly the same causal relationship prompt quality has to model output quality generally.

**Q: What is the specific reliability advantage of using an `enum` constraint over a free-text string with description-based guidance on allowed values?**
A: An enum is a hard, API-enforced constraint — the model's output is structurally validated against the fixed list of allowed values. A free-text description saying "one of FD, Non-FD, or Multiple Category" is a soft constraint the model has learned to generally respect but isn't structurally guaranteed to honor under unusual phrasing or edge-case pressure — the enum provides a strictly stronger correctness guarantee whenever the value space is genuinely fixed and known in advance.

**Intermediate:**

**Q: This project's `search_knowledge_base` tool description includes an explicit "do NOT call this for..." clause. What specific problem does this solve, and when would you add a similar clause to a new tool?**
A: It disambiguates `search_knowledge_base` from other, plausibly-confusable tools in the same toolset (`finalize_classification` for simple classification, `validate_fd_reference` for customer-specific lookups) — without this negative guidance, a model facing an ambiguous case might select the wrong tool among genuinely similar-sounding options. Add a similar clause whenever a new tool's purpose could plausibly overlap with an existing tool's purpose from the model's perspective, even if the underlying implementations are entirely different.

**Q: A field in a new tool's schema can legitimately be unknown in some cases (e.g. a customer's branch location, which not every email will mention). How should this be reflected in the schema?**
A: The field should NOT be marked `required` if it's genuinely, legitimately sometimes absent — marking it required forces the model to either fail to call the tool at all (if it can't confidently provide every required field) or, more dangerously, fabricate a plausible-but-invented value just to satisfy the schema. Instead, make it optional and provide clear description-level guidance on what its absence means and how the backing function should handle a missing value, ensuring the backing function (Topic 2's design layer) gracefully handles the `None`/absent case rather than assuming it will always be populated.

**Advanced:**

**Q: Design a systematic schema review process this project should apply before adding any new tool to the growing toolset (currently four tools and counting).**
A: Before deployment, review every new tool's schema against: does the description include both a clear positive triggering condition and, where a plausible confusion with an existing tool exists, an explicit negative clause distinguishing them; are all field names self-documenting, with field-level descriptions added for any non-obvious field; are value spaces that are genuinely fixed and known represented as enums rather than free-text; is every `required` field one that the tool genuinely cannot function without, with no legitimately-absent-sometimes fields incorrectly marked required. After this static review, the schema should go through Topic 6's empirical testing — running representative queries (both ones that should trigger this tool and ones that should trigger a different, potentially-confusable tool) and measuring actual selection accuracy before considering the tool schema finalized, not just reviewed.

**Q: A tool schema change (adding a new optional field with a default-implied meaning when absent) causes a measurable regression in another, unrelated tool's selection accuracy. How is this possible, and how would you diagnose it?**
A: Since all tool schemas are sent together in the same `tools` list on every call, and the model reasons over the full set jointly when deciding what to invoke, a change to one tool's schema can shift the model's relative "weighting" of tool descriptions in ways that aren't strictly isolated to that tool — a longer, more detailed description for tool A could, in principle, make tool A's use case seem like a better match for a query that previously, more narrowly, triggered tool B, purely through relative salience effects in the model's reasoning over the joint tool list. Diagnosing this requires running the SAME regression test set used in Topic 6 both before and after the schema change, checking not just the changed tool's own accuracy but the full toolset's selection accuracy jointly — a discipline of treating any single-tool schema change as a change to the entire tool-use system's behavior, not an isolated edit.

**Scenario-based:**

**Q: After adding a new `lookup_product_catalog` tool with a reasonably-written schema, you observe the model correctly calling it for genuine product questions, but ALSO occasionally calling it in cases that should have triggered `search_knowledge_base` instead (for general policy questions unrelated to a specific product lookup). Diagnose and fix.**
A: This is a schema-level disambiguation gap between two now-plausibly-overlapping tools — review both tools' descriptions specifically for how clearly they distinguish "looking up a specific named product's details" (the new tool's actual purpose) from "answering a general policy question" (`search_knowledge_base`'s purpose) — the overlap likely arises because many product-related policy questions could superficially sound like either use case. Add explicit negative guidance to each tool's description, cross-referencing the other by name (mirroring `search_knowledge_base`'s existing pattern of referencing `validate_fd_reference` by name), and validate the fix against a test set specifically constructed with borderline cases between these two tools (Topic 6's methodology), rather than assuming the wording fix worked without measurement.

---

### 9. Hidden Concepts and Prerequisites

- **This topic is a specific, LLM-tool-calling instance of the general software engineering discipline of "API design"** — the same principles that make a good REST API or library function signature (clear naming, appropriate use of enums/constrained types, sensible required-vs-optional field choices, good documentation) apply directly to tool schema design, just with an LLM as the "caller" instead of another program or a human developer.
- **The relationship between schema quality and few-shot prompting (Chapter 2)**: an especially effective schema-design technique not shown above is including a worked example directly in the description (e.g. "Example: for the email 'my FD BJ2019FD7717 matured but no payout', call this with reference_number='BJ2019FD7717'") — this is functionally a form of few-shot prompting embedded within the tool definition itself, connecting this topic directly back to Chapter 2's foundational prompt engineering techniques.
- **This connects forward to Topic 6 (Testing Tool-Calling Reliability)**: every design principle in this topic (clear descriptions, enums, field naming) is a hypothesis about what improves reliability — Topic 6 is where those hypotheses actually get validated empirically against real data, closing the loop between schema design theory and measured practice.

---

### 10. Revision Summary

> Tool schemas are prompt engineering with structure — every word in a `description`, every field name, and every constraint in `input_schema` directly shapes the model's tool-selection and argument-construction behavior on every single call. Reliable schemas have unambiguous triggering conditions (positive examples of when to call, negative examples distinguishing from confusable alternative tools, as this project's `search_knowledge_base` does against both `finalize_classification` and `validate_fd_reference`), self-documenting field names, enum constraints wherever the value space is genuinely fixed and known (stronger than free-text description-based guidance), and deliberate required-vs-optional choices that avoid forcing the model to fabricate values for legitimately-absent fields. Schema changes are prompt changes and require the same before-and-after evaluation discipline as any other prompt modification (Topic 6), evaluated across the *entire* toolset jointly, since all tool schemas are reasoned over together on every call and a change to one tool's description can shift relative selection behavior for others.

---
