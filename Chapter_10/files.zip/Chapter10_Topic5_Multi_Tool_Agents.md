# Chapter 10: Tool Engineering

## Topic 5: Multi-Tool Agents — `lookup_product_catalog`, `check_sender_history`

---

### 1. Concept, Intuition, and Why It Exists

- This project's agent has grown from 3 tools (Chapter 3) to 4 (`search_knowledge_base` added in Chapter 9), each addressing a distinct, previously-explored need. This topic asks what happens as the toolset grows further, using two concrete, motivated new tools as the vehicle: `lookup_product_catalog` (answering "what products does this NBFC offer and what are their current terms" — distinct from `search_knowledge_base`'s general policy knowledge) and `check_sender_history` (surfacing this project's own EDA finding of 14% repeat senders — has this customer emailed before, and if so, about what).
- The core new challenge multi-tool agents introduce, beyond anything single- or few-tool systems face: **tool selection accuracy degrades as the number of plausible, overlapping tools grows**, and the *combinatorics* of correct multi-step tool sequences (call A, then B, then finalize — versus B then A then finalize — versus just A then finalize) become a genuine reasoning burden for the model, not just a schema-wording problem (Topic 3) but an architectural one.
- Why `lookup_product_catalog` and `check_sender_history` specifically: they were flagged in this project's own syllabus as the natural next tools, and they exercise two genuinely different multi-tool patterns — `lookup_product_catalog` risks confusion with `search_knowledge_base` (both are knowledge-retrieval-flavored), while `check_sender_history` introduces a fundamentally new capability (memory/history lookup) that previews Chapter 11's Memory chapter.

---

### 2. Internal Working — Step by Step

**Designing `lookup_product_catalog` — disambiguating from `search_knowledge_base`:**

1. **The overlap risk**: both tools answer "what does the customer need to know about FD products" — but `search_knowledge_base` (Chapter 9) searches unstructured policy/FAQ/SOP text via semantic retrieval, while `lookup_product_catalog` should be an *exact, structured* lookup against a product catalog table (product name → current interest rate, tenure options, minimum deposit) — closer in spirit to `validate_fd_reference`'s exact-match pattern than to semantic search.
2. **The schema must make this distinction unmistakable**: `lookup_product_catalog`'s description should specify it's for looking up *current, structured terms of a named product* ("what's the current rate for Smart Saver FD"), while `search_knowledge_base`'s description continues to own general policy *explanations* ("what happens if I withdraw early") — this is Topic 3's disambiguation principle, now applied to two knowledge-flavored tools rather than a knowledge tool versus a classification tool.

**Designing `check_sender_history` — a genuinely new capability:**

1. **What does it need as input?** The sender's email address or customer identifier (extracted from the email metadata, not necessarily from the email body text the way `validate_fd_reference`'s reference number is).
2. **What does it return?** A structured summary of past interactions — e.g. `{"is_repeat_sender": bool, "previous_interaction_count": int, "previous_topics": list, "last_interaction_date": str}` — giving the model context to potentially adjust its response (e.g. "as we discussed in your previous email..." or recognizing an escalating pattern of complaints about the same issue).
3. **The multi-tool sequencing question this introduces**: should the model call `check_sender_history` *before* deciding how to classify or respond to the current email (using history to inform the primary decision), or only *after* forming an initial view (using history as a secondary enrichment)? This is a genuine architectural and prompting decision, not just a schema question — the system prompt must guide *when in the reasoning sequence* this tool's information should be sought.

**The combinatorial reasoning burden, made concrete:**

- With 3 tools (Chapter 3), the model's realistic decision space per turn is small: call `validate_fd_reference`, or finalize/refuse.
- With 6 tools (this topic's addition), a single request might plausibly involve: check sender history first → validate FD reference → look up product catalog → search knowledge base for a policy nuance → finalize. The model must correctly sequence potentially several tool calls, not just correctly select one tool once — this is a qualitatively harder reasoning task than single-tool selection, and testing (Topic 6) must specifically probe multi-step sequences, not just individual tool-selection accuracy in isolation.

---

### 3. How It Is Implemented in This Project

```python
LOOKUP_PRODUCT_CATALOG_TOOL = {
    "name": "lookup_product_catalog",
    "description": (
        "Call this to get the CURRENT, STRUCTURED terms of a SPECIFIC NAMED FD "
        "product (interest rate, tenure options, minimum deposit) -- for example "
        "'what is the current rate for Smart Saver FD'. Do NOT call this for general "
        "policy explanations (like withdrawal penalty rules) -- use search_knowledge_base "
        "for that instead. This tool only returns structured facts about a named product, "
        "not explanatory text."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "product_name": {"type": "string", "description": "The exact or best-guess name of the FD product, e.g. 'Smart Saver FD'."}
        },
        "required": ["product_name"],
    },
}

CHECK_SENDER_HISTORY_TOOL = {
    "name": "check_sender_history",
    "description": (
        "Call this EARLY, before finalizing your classification or response, to check "
        "if this customer has emailed before. Useful for recognizing repeat concerns, "
        "escalating patterns, or providing continuity ('as discussed previously'). "
        "Always call this for every email UNLESS the sender's email address is missing "
        "or clearly a test/internal address."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "sender_email": {"type": "string", "description": "The sender's email address, from the email metadata."}
        },
        "required": ["sender_email"],
    },
}


def lookup_product_catalog(product_name: str) -> dict:
    """Exact/fuzzy lookup against a structured product table -- NOT semantic
    search. Mirrors validate_fd_reference's exact-match pattern (Chapter 10
    Topic 2), applied to product data instead of customer account data."""
    product = PRODUCT_CATALOG.get(product_name.strip().lower())
    if product is None:
        # Fuzzy fallback: check for close matches before giving up
        close_match = find_closest_product_name(product_name, PRODUCT_CATALOG.keys())
        if close_match:
            return {"found": True, "note": f"Assumed you meant '{close_match}'", **PRODUCT_CATALOG[close_match]}
        return {"found": False, "reason": f"No product found matching '{product_name}'."}
    return {"found": True, **product}


def check_sender_history(sender_email: str) -> dict:
    """Queries this project's interaction history store (a forward reference
    to Chapter 11's Memory architecture -- here, a simplified stand-in)."""
    history = INTERACTION_HISTORY_STORE.get(sender_email.strip().lower(), [])
    if not history:
        return {"is_repeat_sender": False, "previous_interaction_count": 0}
    return {
        "is_repeat_sender": True,
        "previous_interaction_count": len(history),
        "previous_topics": [h["topic"] for h in history[-3:]],  # most recent 3, not the entire history
        "last_interaction_date": history[-1]["date"],
    }


# Updated toolset -- SIX tools now, requiring the sequencing guidance below
TOOLS = [
    CHECK_SENDER_HISTORY_TOOL,       # NEW -- guided to be called EARLY
    VALIDATE_FD_REFERENCE_TOOL,
    LOOKUP_PRODUCT_CATALOG_TOOL,     # NEW
    SEARCH_KNOWLEDGE_BASE_TOOL,
    FINALIZE_CLASSIFICATION_TOOL,
    REFUSE_OUT_OF_SCOPE_TOOL,
]

# System prompt addition -- explicit SEQUENCING guidance, not just per-tool triggering
SEQUENCING_GUIDANCE = """
Suggested order of operations (not rigid, adapt as needed):
1. If the sender's email is available, call check_sender_history early to gather context.
2. If the email references a specific FD reference number, call validate_fd_reference.
3. If the email asks about a specific named product's current terms, call lookup_product_catalog.
4. If the email asks a general policy question, call search_knowledge_base.
5. Once you have everything needed, call finalize_classification or the appropriate answer tool.
"""
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **Latency compounds multiplicatively with tool count per request**: a request now plausibly involving 3-4 sequential tool calls before finalizing means 4-5 full agent-loop iterations (each a network round-trip) instead of Chapter 3's typical 1-2 — this is a direct, measurable latency cost of a richer toolset that must be tracked per-request (loop-iteration count, per Topic 1's monitoring recommendation) as the toolset grows, not assumed to stay constant.
- **`check_sender_history`'s "always call this" guidance creates a real cost trade-off**: calling it on every single email (per the description's "Always call this... UNLESS...") means every request incurs this tool's latency and cost even when history turns out to be irrelevant (a first-time sender) — this should be measured against the value it actually provides in practice (how often does history genuinely change the response) before committing to "always call" as a permanent policy, versus a more selective triggering condition.
- **Product catalog staleness is a real, recurring risk**: `lookup_product_catalog`'s entire value proposition is *current* structured terms — if `PRODUCT_CATALOG` isn't kept in sync with actual current rates (a data freshness problem structurally identical to Chapter 8 Topic 3's knowledge-base-staleness correctness concern), the tool confidently returns wrong, outdated information with no signal anything is wrong.
- **Monitoring multi-tool sequences specifically**: beyond per-tool metrics (Topic 1, Topic 4), track *sequence patterns* — which combinations and orderings of tool calls occur most frequently, and whether any sequence pattern correlates with lower downstream answer quality (Chapter 8 Topic 3's faithfulness/relevance framework) — a specific ordering might be systematically suboptimal in ways that only show up when looking at sequences, not individual tool accuracy in isolation.
- **Security**: `check_sender_history` introduces a new PII-adjacent surface — interaction history is customer data, and the same access-scoping discipline from Chapter 9 Topic 4 (never let one customer's data leak into another's context) applies directly: `INTERACTION_HISTORY_STORE.get(sender_email...)` must be scoped precisely to the exact sender's own email address, with no fuzzy or partial matching that could ever return a different customer's history.
- **Cost**: six tool schemas resent on every API call (Topic 1's point, now more consequential) — the cumulative token cost of the full `tools` list is now meaningfully larger than the original three-tool version, and should be tracked as a distinct, growing cost line as the toolset continues to expand in later chapters.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **Should `check_sender_history` be called unconditionally (guided by the system prompt) or only when contextually relevant?**: unconditional calling is simpler to reason about and guarantees no repeat-sender pattern is ever missed, but costs latency and money on every request regardless of whether it changes the outcome. Conditional calling (only when the model judges history might matter) is cheaper on average but risks under-triggering (Chapter 9 Topic 1's concern, now applied to this tool specifically) — missing a genuinely relevant repeat-sender pattern because the model didn't think to check. This is a real trade-off that should be resolved with production data: measure how often history, when checked, actually changes the response quality, and decide based on that measured value versus the unconditional cost.
- **Fuzzy matching in `lookup_product_catalog` vs. requiring exact product names**: fuzzy matching (shown in the code above) makes the tool more forgiving of a customer's imprecise product name mention, but introduces a new failure mode — a fuzzy match could confidently return the *wrong* product's terms if two product names are similar enough, which is a more dangerous failure than a clean "not found," since it's confidently wrong rather than honestly uncertain. This mirrors the general precision-vs-recall tension seen throughout this project's retrieval chapters (Chapter 7), now applied to structured lookup rather than semantic search.
- **Explicit sequencing guidance in the system prompt vs. trusting the model's own reasoning to sequence tools correctly**: as tool count grows, explicit ordering guidance (as shown in `SEQUENCING_GUIDANCE`) becomes increasingly valuable — without it, a capable model can often still sequence tools sensibly on its own, but explicit guidance reduces variance and makes behavior more predictable and auditable, a genuine benefit as this project moves toward the more rigorous evaluation and production requirements covered in Chapters 14-20.

---

### 6. Alternatives and When to Use Each

- **Growing a single agent's toolset indefinitely (this topic's approach, appropriate at moderate scale)**: works well while the toolset remains small enough (perhaps up to 8-10 tools) that schema disambiguation (Topic 3) and sequencing guidance can keep selection and ordering accuracy high — this project's current 6-tool scale is comfortably within this range.
- **Splitting into specialized sub-agents, each with a smaller toolset (a forward reference to Chapter 12's LangGraph orchestration)**: once a toolset grows large enough that a single system prompt's sequencing guidance becomes unwieldy or selection accuracy measurably degrades, splitting responsibilities across multiple specialized agents (each with 2-3 tools and a focused system prompt) — coordinated by an orchestration layer — becomes the more scalable architecture. This project isn't there yet, but Topic 5's tool growth is a preview of the pressure that eventually motivates that architectural shift.
- **A single "mega-tool" with sub-actions instead of many small tools (Topic 1's alternative revisited)**: becomes more attractive as tool count grows, since it caps the *number* of top-level choices the model must make, shifting complexity into within-tool action selection instead — worth reconsidering specifically once this project's toolset grows beyond what Topic 3's disambiguation techniques can keep reliably distinct.

---

### 7. Common Mistakes and Production Failures

- Adding new tools without checking for schema-level overlap with existing tools (Topic 3's discipline), reintroducing tool-selection confusion each time the toolset grows.
- Not providing explicit sequencing guidance as tool count grows, leaving multi-step reasoning entirely to the model's own judgment without any architectural scaffolding, increasing behavioral variance.
- Allowing `check_sender_history` or similar tools to perform anything less than exact, precisely-scoped lookups by sender identity, risking cross-customer data leakage exactly as Chapter 9 Topic 4 warned against for `search_knowledge_base`.
- Letting `PRODUCT_CATALOG` go stale without a data freshness/versioning discipline, silently serving outdated product terms with high apparent confidence.
- Not monitoring tool-call *sequences* as a distinct signal from individual tool accuracy, missing systematic ordering problems that only manifest across multi-step interactions.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: Why does `lookup_product_catalog` need a schema that clearly distinguishes it from `search_knowledge_base`, given both seem to answer "questions about FD products"?**
A: They serve genuinely different query types — `lookup_product_catalog` provides exact, structured, current facts about a specifically named product (an interest rate, a tenure option), while `search_knowledge_base` provides semantic retrieval over unstructured explanatory policy text (why a penalty exists, how an exception works). Without clear schema disambiguation (explicit positive examples for each, and negative cross-references, per Topic 3), the model could easily select the wrong tool for a given question, since both are superficially "about FD products" from a surface-level reading.

**Q: What is the "combinatorial reasoning burden" this topic introduces as tool count grows?**
A: With few tools, the model mostly faces a single-tool-selection decision per turn. As tool count grows and realistic requests plausibly require several tools in sequence (check history, then validate a reference, then look up a product, then finalize), the model must correctly reason about not just *which* tools to call but in what *order*, and when it has gathered enough information to stop — a qualitatively harder multi-step planning task than single-tool selection, requiring both better schema design (Topic 3) and, increasingly, explicit sequencing guidance in the system prompt.

**Intermediate:**

**Q: Why is `check_sender_history`'s "always call this" default a real cost trade-off, and how would you decide whether to keep it?**
A: Calling this tool on every single request guarantees no repeat-sender context is ever missed, but incurs its latency and cost even for the (likely large) fraction of first-time senders where the check turns out to add no value. The trade-off should be resolved empirically: measure, across production traffic, how often `is_repeat_sender: True` actually leads to a materially different or better response (using Chapter 8 Topic 3's faithfulness/relevance framework, extended to compare responses with and without history awareness) — if the value is high and consistent, unconditional calling is justified; if it rarely changes outcomes, a more selective triggering condition (e.g. only when the email's tone suggests frustration or a repeat complaint) could reduce cost without meaningfully hurting quality.

**Q: Why is fuzzy matching in `lookup_product_catalog` a riskier design choice than it might first appear?**
A: A clean "not found" result is an honestly uncertain outcome the model can reason about (perhaps asking the customer to clarify, or falling back to a general policy answer via `search_knowledge_base`). A fuzzy match that confidently returns the wrong product's terms because two product names are textually similar is a *confidently wrong* outcome — arguably worse than an honest not-found, since nothing in the response signals that anything might be off, and the customer could receive incorrect rate or term information believing it's authoritative. This is the same precision-versus-recall tension seen throughout this project's retrieval work, now with higher stakes since structured lookups are typically treated with more implicit trust than semantic search results.

**Advanced:**

**Q: Design the specific mechanism by which `lookup_product_catalog`'s fuzzy matching should signal its own uncertainty to the model, rather than returning a confident-looking result for an uncertain match.**
A: The fuzzy match result should include an explicit confidence or match-quality signal distinct from a genuine exact match — e.g. `{"found": True, "match_type": "exact"}` versus `{"found": True, "match_type": "fuzzy", "match_confidence": 0.72, "note": "Assumed you meant 'Smart Saver FD' -- please confirm if this is incorrect."}` — giving the model (and, through it, potentially the customer-facing response) an explicit signal to treat this result with appropriate caution, perhaps by confirming the product name with the customer rather than stating the fuzzy-matched terms as unconditionally authoritative. This mirrors the general principle from Chapter 8 Topic 3 of never letting a system's internal uncertainty become invisible by the time it reaches a final answer.

**Q: As this project's toolset continues to grow beyond the six tools shown here, at what point would you recommend moving to a multi-agent architecture (Chapter 12's LangGraph) instead of continuing to add tools to a single agent?**
A: The trigger should be measured degradation, not a fixed tool count — specifically, monitor tool-selection accuracy and multi-step sequencing correctness (via the regression testing methodology from Topic 6) as new tools are added; if accuracy measurably degrades as the toolset grows past some point, or if the system prompt's sequencing guidance becomes so elaborate that it's hard to maintain and reason about, that's the evidence-based signal to consider splitting responsibilities across specialized sub-agents rather than continuing to grow one agent's toolset indefinitely — following this project's consistent evidence-before-architectural-change discipline rather than picking an arbitrary tool-count threshold in advance.

**Scenario-based:**

**Q: In production, you observe that when both `check_sender_history` and `validate_fd_reference` are called in the same request, the model sometimes calls them in a suboptimal order (validating the reference first, then checking history, when the reverse would have let history inform how to interpret the reference lookup result). Diagnose and propose a fix.**
A: This is a sequencing accuracy problem, not an individual tool-selection problem — both tools are being correctly selected, just potentially in a suboptimal order. First, verify whether the order actually matters for the specific failing cases (does checking history first genuinely change how the reference lookup result should be interpreted, or is this a purely cosmetic ordering preference with no real quality impact) — if it doesn't materially affect outcome quality, this may not be worth fixing. If it does matter, strengthen the system prompt's `SEQUENCING_GUIDANCE` with a more explicit, specific rule for this exact combination (e.g. "if both a sender history check and a reference validation are needed, always check history first"), and validate the fix against a regression test set specifically constructed with cases requiring both tools (Topic 6's methodology), confirming the more explicit guidance actually improves sequencing without introducing new problems elsewhere.

---

### 9. Hidden Concepts and Prerequisites

- **This topic is a concrete instance of the general AI planning problem** — deciding a correct sequence of actions to achieve a goal, given a set of available actions (tools) and their preconditions/effects, is a long-studied area of AI research (classical planning, and more recently, LLM-based planning and reasoning) predating tool-calling LLMs; recognizing multi-tool sequencing as an instance of this general problem connects this topic to a much broader body of relevant theory.
- **The tension between unconditional tool-calling (like `check_sender_history`'s "always call" guidance) and selective, judgment-based calling connects back to Chapter 9 Topic 1's retrieval-trigger discussion** — both are instances of the same underlying question: should a capability always run, or only when contextually warranted, and how do you measure which is actually better for a specific tool's cost/value profile.
- **This chapter's tool growth previews Chapter 11's Memory chapter directly**: `check_sender_history`'s `INTERACTION_HISTORY_STORE` is a simplified stand-in for what Chapter 11 formalizes as short-term versus long-term agent memory — this topic's tool is the first concrete touchpoint with memory as a capability, before the next chapter treats it as a first-class architectural concern in its own right.

---

### 10. Revision Summary

> Growing a toolset from a handful of tools to six or more introduces a genuinely new challenge beyond individual schema quality (Topic 3): tool *selection* accuracy can degrade with more plausible options, and multi-step tool *sequencing* becomes a real reasoning burden the model must handle correctly, not just single-tool triggering. `lookup_product_catalog` (exact, structured lookup, contrasted carefully against `search_knowledge_base`'s semantic retrieval) and `check_sender_history` (a new memory-adjacent capability previewing Chapter 11) both require the same disambiguation discipline from Topic 3, now applied under greater combinatorial pressure. Explicit sequencing guidance in the system prompt becomes increasingly valuable as tool count grows, reducing behavioral variance in multi-step requests. Fuzzy matching in structured lookups (`lookup_product_catalog`) trades honest uncertainty for convenience and must signal its own confidence explicitly, never presenting an uncertain match as confidently correct. Unconditional tool-calling policies (like "always check sender history") should be validated against measured value, not adopted by default, given their direct, compounding cost impact on every request. Sustained tool growth beyond what schema disambiguation and sequencing guidance can reliably support is the evidence-based trigger for considering a multi-agent architecture (Chapter 12), not a fixed tool-count threshold decided in advance.

---
