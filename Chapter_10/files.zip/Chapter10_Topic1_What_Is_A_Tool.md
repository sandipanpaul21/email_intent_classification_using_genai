# Chapter 10: Tool Engineering

## Topic 1: What a "Tool" Is to an LLM and How Tool-Calling Works Under the Hood

---

### 1. Concept, Intuition, and Why It Exists

- An LLM, by itself, is a text-in, text-out function — it has no ability to look anything up, run any computation, or affect the world outside of generating tokens. "Tool use" (also called function calling) is the mechanism that lets an LLM participate in a loop where it can request that *external code* runs on its behalf, see the result, and continue reasoning with that new information.
- This project has been using tool calling since Chapter 3's `run_agent()` — `validate_fd_reference`, `finalize_classification`, and `refuse_out_of_scope` are all tools. This chapter is where the *mechanics* behind that pattern, taken for granted since Chapter 3, get explained fully: what actually happens inside `client.messages.create(tools=TOOLS, ...)`, why the model "chooses" a tool the way it does, and what the model can and cannot know about a tool beyond its schema.
- The core intuition: a tool is not code the model runs. A tool is a **contract** — a name, a natural-language description, and a JSON schema describing expected arguments — that the model reads as part of its input, and can decide to "invoke" by producing a specially-formatted piece of output. Your code is what actually executes something in response; the model itself never runs anything.

---

### 2. Internal Working — Step by Step

1. **Tool definitions are sent as part of every request**: the `tools` parameter in `client.messages.create()` is a list of JSON objects (name, description, input_schema) — these are sent to the model as part of its input context on *every single call*, not registered once and remembered. The model has no persistent memory of what tools exist between API calls; every request re-declares the full toolset.
2. **The model decides whether to use a tool by pattern-matching its own training and the current context against the tool descriptions**: during training, models are fine-tuned specifically to recognize when a described capability would help answer the current context, and to emit output in the specific format required to invoke it. This is a *learned* behavior — the model wasn't given explicit rules for "if X, call tool Y"; it was trained on many examples of tool-use conversations until this behavior generalized reliably.
3. **When the model decides to call a tool**, its response contains a `stop_reason` of `"tool_use"` and a content block of type `"tool_use"`, containing the tool's `name`, a unique `id`, and `input` (the arguments, matching the tool's `input_schema`) — this is the *entirety* of what happens inside the model. It does not execute Python. It produces structured text that your code interprets as a request.
4. **Your code executes the actual function**: this project's `run_agent()` loop reads `block.name`, matches it against known tool names via `if/elif`, and calls the real Python function (`get_fd_record()` for `validate_fd_reference`) or, for terminal tools like `finalize_classification`, simply returns the model's own declared output.
5. **The result is sent back as a new message**: a `tool_result` content block, tagged with the same `tool_use_id` so the model knows which of its (possibly several) tool calls this result answers, gets appended to the `messages` list with `role: "user"`. This is the *only* way the model learns what happened — it has zero visibility into your code's execution otherwise.
6. **The model is called again with the updated `messages`**, now including the tool result, and decides its next action — call another tool, or finalize. This is why `run_agent()` is a loop, not a single call.

---

### 3. How It Is Implemented in This Project

```python
# The exact pattern already established in Chapter 3, now explained mechanically

VALIDATE_FD_REFERENCE_TOOL = {
    "name": "validate_fd_reference",
    "description": (
        "Call this whenever the email contains something that looks like an FD "
        "reference number, before relying on it to decide the label or describe "
        "the account's status. Returns found=False if no such reference exists "
        "in the system."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "reference_number": {"type": "string", "description": "The candidate reference number found in the email."}
        },
        "required": ["reference_number"],
    },
}

# This dict is PURE DATA -- no function is attached to it. The model reads
# "name", "description", and "input_schema" as TEXT, weighs them against
# the current conversation, and decides whether producing a tool_use block
# referencing "validate_fd_reference" is the right next output.

def run_agent(email_text: str, client, model_id: str, max_steps: int = 5) -> dict:
    messages = [{"role": "user", "content": email_text}]

    for step in range(max_steps):
        response = client.messages.create(
            model=model_id, max_tokens=500,
            system=AGENT_SYSTEM_PROMPT, tools=TOOLS,  # tools re-sent EVERY call
            messages=messages,
        )

        if response.stop_reason != "tool_use":
            return {"status": "no_tool_call", "text": response.content[0].text}

        messages.append({"role": "assistant", "content": response.content})
        tool_result_blocks = []

        for block in response.content:
            if block.name == "validate_fd_reference":
                # THIS is where actual code executes -- the model never ran this
                result = get_fd_record(block.input["reference_number"])
                tool_result_blocks.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,  # links this result to the SPECIFIC call
                    "content": json.dumps(result),
                })
            elif block.name == "finalize_classification":
                return {"status": "classified", "label": block.input["label"], "reason": block.input["reason"]}
            elif block.name == "refuse_out_of_scope":
                return {"status": "refused", "reason": block.input["reason"]}

        messages.append({"role": "user", "content": tool_result_blocks})
        # Loop continues -- model sees the tool result on the NEXT call
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **Every tool definition costs tokens on every single call**: since `tools` is resent in full with every `client.messages.create()` call, a large toolset (or verbose descriptions) directly and repeatedly consumes input token budget — this compounds with Chapter 8 Topic 1's context-window budgeting concerns, since tool schemas compete for the same space as system prompt and retrieved context.
- **The model can hallucinate a tool call with malformed or nonsensical arguments**: while `input_schema` constrains the *shape* of arguments (type checking is enforced reasonably well by modern models), it cannot guarantee *semantic* correctness — a model could call `validate_fd_reference` with a `reference_number` that isn't actually a real reference number pattern, just plausible-looking text it extracted incorrectly. Your code must still validate inputs defensively, never trusting that schema conformance implies correctness.
- **`tool_use_id` matching is not optional**: if your code appends a `tool_result` without the correct `tool_use_id`, or in the wrong order relative to multiple simultaneous tool calls, the model receives a corrupted view of what answered what — a subtle bug that produces confusing, hard-to-diagnose downstream behavior rather than a clean error.
- **Latency**: each loop iteration in `run_agent()` is a full network round-trip to the API — a request needing 3 tool calls before finalizing incurs roughly 4x the latency of a single-shot response (3 tool-use turns + 1 finalization turn). This is the direct cost of agentic flexibility, and should be monitored per-request as loop-iteration-count, not just aggregate response time.
- **Monitoring**: track the distribution of loop iterations per request (most should resolve in 1-2 turns; a long tail of many-turn requests may indicate unclear tool descriptions or a genuinely complex query pattern worth understanding), and track `stop_reason` distribution (`tool_use` vs `end_turn` vs hitting `max_steps`) as a first-class agent health metric.
- **Security**: tool *descriptions* and tool *names* are part of the model's input just like the system prompt — a tool description containing ambiguous or exploitable language is as much a prompt-injection surface as the system prompt itself, and should be reviewed with the same scrutiny.
- **Deployment**: `max_steps` (this project's existing safety net) is a critical, non-negotiable guardrail — without it, a model stuck in a call-tool-then-reconsider loop could run indefinitely, consuming unbounded cost and latency for a single request.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **How many tools should a single agent have access to?**: this project's `TOOLS` list has grown from 3 (Chapter 3) to include `search_knowledge_base` (Chapter 9) — every additional tool increases both token cost per call and the risk of the model selecting the wrong tool among more numerous, potentially overlapping options (this connects directly to Chapter 9 Topic 1's discussion of trigger accuracy). There is no fixed "right number," but tool proliferation should be treated as a cost, not a free capability addition.
- **Terminal tools with no backing function vs. tools with real logic**: `finalize_classification` and `refuse_out_of_scope` have no Python function behind them — they exist purely as a structured way for the model to declare a decision. This is a deliberate, recurring pattern in this project (also used in Chapter 8's `finalize_answer_with_citations`) — using the tool-calling mechanism not just for external actions, but for *forcing structured output* at decision points, which is more reliable than parsing free text for a decision.
- **Should tool execution ever happen without model involvement (e.g., pre-fetching data before the model even runs)?**: this project's design always lets the model *decide* to call a tool — an alternative architecture could pre-fetch commonly-needed data (e.g. always running `validate_fd_reference` if a reference-number-shaped string is detected via regex, before even calling the model) as a deterministic pre-processing step. This trades agentic flexibility for speed and predictability — worth considering for high-confidence, high-frequency patterns, but abandons the "model decides" principle Chapter 9 Topic 1 argued for as the more general, adaptable approach.

---

### 6. Alternatives and When to Use Each

- **The standard tool-use/function-calling API pattern (this project's approach)**: the correct default for any agent needing to invoke external capabilities based on the model's own contextual judgment — well-supported, well-understood, and this project's foundation since Chapter 3.
- **Deterministic pre-processing / rule-based pre-fetching**: appropriate for very high-confidence, narrow patterns where waiting for model judgment adds unnecessary latency (e.g. always checking a well-formed FD reference number pattern via regex before the model even sees the email) — a hybrid this project could adopt if profiling shows a specific, common pattern would benefit.
- **A single mega-tool with many sub-actions vs. many small, specific tools**: some designs prefer one tool with an `action` parameter selecting behavior (e.g. `database_operation(action="lookup"|"insert"|"update", ...)`) — this reduces the total number of distinct tools the model must choose among, potentially improving selection accuracy, at the cost of a more complex single `input_schema` and less self-documenting tool names. This project's existing pattern (separate, narrowly-scoped tools) favors clarity and auditability over this consolidation.

---

### 7. Common Mistakes and Production Failures

- Assuming the model "runs" the tool itself, rather than understanding that tool calling is entirely a text-generation-then-your-code-executes pattern — a common conceptual error that leads to confused debugging when a "tool doesn't work" (the tool's Python function has a bug, unrelated to the model's correct decision to call it).
- Forgetting to resend `tools` on every API call, or inconsistently changing the toolset between calls within the same conversation, which can produce confusing model behavior since it's now "seeing" a different set of options mid-conversation.
- Not enforcing a `max_steps` safety net, risking unbounded loops on edge-case inputs.
- Mismatching `tool_use_id` when multiple tools are called in the same turn, corrupting the model's understanding of which result answers which request.
- Treating schema conformance (the arguments matched the expected types) as equivalent to semantic correctness (the arguments are actually meaningful/valid) — these are different guarantees, and only the former is enforced automatically.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: What is a "tool" from the model's perspective, and what is it not?**
A: A tool is a JSON schema (name, description, input_schema) the model reads as part of its input on every API call — it is text the model reasons about, not code it executes. The model's only capability regarding a tool is producing specially-formatted output (a `tool_use` content block) requesting that the tool be invoked; the actual execution is entirely the calling application's responsibility.

**Q: Why must `tools` be included in every single `client.messages.create()` call within a multi-turn agent loop, rather than being set once?**
A: The API is stateless between calls — the model has no persistent memory of a prior request's tool definitions. Every call is a fresh, complete context that must include everything the model needs to reason correctly, including the full toolset, the system prompt, and the conversation history.

**Intermediate:**

**Q: Walk through what happens, mechanically, between the model deciding to call `validate_fd_reference` and the model learning the result.**
A: The model's response contains a `tool_use` content block with the tool name, a unique id, and structured input arguments — this is appended to `messages`. The application code detects this block, extracts the arguments, calls the real `get_fd_record()` function, and packages the return value into a `tool_result` block tagged with the matching `tool_use_id`. This result is appended to `messages` as a new user-role message. Only on the *next* `client.messages.create()` call, with this updated `messages` list, does the model actually "see" the result and reason about it — there is no synchronous callback or direct code execution from the model's side.

**Q: Why do `finalize_classification` and `refuse_out_of_scope` have no backing Python function, unlike `validate_fd_reference`?**
A: They exist purely to force the model to declare its final decision in a structured, parseable format rather than free text — the "backing function" for these tools is simply returning the model's own declared `input` fields (`label`, `reason`) directly, since there's no external action to perform, only a decision to capture reliably.

**Advanced:**

**Q: A teammate proposes reducing latency by having the application pre-fetch `validate_fd_reference`'s result via regex-based reference number detection, before ever calling the model, then including the result directly in the initial prompt. Evaluate this design change.**
A: This trades the agentic "model decides when to verify" pattern for a deterministic pre-processing step, which can reduce latency (avoiding one loop iteration) for the common case where a reference number is confidently detectable via regex. The risk: if the pre-fetch's regex has false positives or negatives, the model receives either irrelevant lookup results (noise) or is deprived of the tool call it would have correctly triggered on its own for a reference number in an unexpected format the regex missed. This is a legitimate latency optimization for a well-understood, high-frequency pattern, but should preserve the tool as an available option (not remove it entirely) so the model can still call it directly for cases the pre-processing regex doesn't confidently catch — a hybrid rather than a full replacement.

**Q: How would you decide whether to consolidate several related tools into one tool with an `action` parameter, versus keeping them as separate, narrowly-named tools?**
A: This is a tool-selection-accuracy question, best answered empirically rather than by preference — build a test set of representative queries and measure how often the model selects the correct tool (or correct action within a consolidated tool) under each design, mirroring Chapter 9 Topic 1's under-triggering detection methodology. Separate, narrowly-scoped tools tend to have clearer, more specific descriptions that are easier for the model to match confidently; a consolidated tool with an `action` parameter reduces the total tool count (helpful if approaching a practical limit on toolset size) but shifts the selection burden into correctly choosing the `action` value within a single, more complex schema. There's no universal answer — this project's existing separate-tools pattern should be validated against this project's actual query distribution before either approach is assumed superior.

**Scenario-based:**

**Q: In production, you notice a specific customer email pattern consistently causes `run_agent()` to hit `max_steps` without resolving. Diagnose.**
A: This indicates the model is stuck in a call-tool-then-reconsider cycle without ever reaching a terminal tool call (`finalize_classification` or `refuse_out_of_scope`). First, log and inspect the full `messages` trace for one of these failing requests — check whether the model is repeatedly calling the same tool with slightly different arguments (suggesting it's not satisfied with the results and doesn't know how to proceed), calling different tools in a way that suggests genuine confusion about the task, or whether a tool's backing function itself might be returning malformed or unexpected results that confuse the model's reasoning. This is exactly the kind of full-trace debugging Chapter 9 Topic 3 established as necessary for multi-stage tool calls — the fix depends entirely on which specific breakdown the trace reveals, whether that's a tool description needing clarification, a backing function bug, or a genuinely ambiguous input pattern needing new system-prompt guidance.

---

### 9. Hidden Concepts and Prerequisites

- **Tool calling relies on the model having been specifically fine-tuned for it** — this is not an emergent capability of any sufficiently large language model; providers like Anthropic specifically train models on tool-use conversation examples so the model reliably produces correctly-formatted `tool_use` blocks and respects `input_schema` constraints. This is why tool-use quality can vary meaningfully between model versions and providers, and why a model's tool-use accuracy is a real, measurable, model-specific property worth being aware of.
- **JSON Schema is the underlying specification format for `input_schema`** — a well-established, general-purpose standard for describing JSON data shapes (used far beyond LLM tool calling, in API validation, configuration files, etc.) — knowing this connects tool schema design to a broader, transferable skill rather than an LLM-specific quirk.
- **The stateless nature of the API is a foundational constraint that shapes this entire chapter and connects forward to Chapter 11's Memory** — every design decision about what to include in `messages` on each call (conversation history, tool results, retrieved context) exists specifically because the API itself remembers nothing between calls; understanding this statelessness deeply is a prerequisite for reasoning correctly about memory architecture in the next chapter.

---

### 10. Revision Summary

> A tool is a JSON schema (name, description, input_schema) sent as part of every API request — pure data the model reasons about, never code it executes. When the model decides a tool would help, it produces a structured `tool_use` output block; the calling application (this project's `run_agent()`) detects this, executes the real backing function (or, for terminal tools like `finalize_classification`, simply captures the model's declared decision), and sends the result back as a `tool_result` message tagged with a matching `tool_use_id`. This round-trip — model decides, app executes, app reports back, model decides again — is the entire mechanism, repeated in a loop bounded by `max_steps` as a critical safety net against runaway execution. Tools cost tokens on every call (the full toolset is resent every time, with no persistent registration), schema conformance does not guarantee semantic correctness (defensive validation in your own code remains necessary), and tool descriptions are as much a prompt-injection-relevant surface as the system prompt itself.

---
