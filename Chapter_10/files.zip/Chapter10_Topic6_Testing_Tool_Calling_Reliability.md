# Chapter 10: Tool Engineering

## Topic 6: Testing Tool-Calling Reliability Across the Dataset

---

### 1. Concept, Intuition, and Why It Exists

- Every topic in this chapter has repeatedly deferred to "this should be validated empirically" — Topic 3's schema design hypotheses, Topic 5's sequencing guidance, Topic 4's retry configuration. This topic is where that repeated deferral is finally resolved: a systematic testing methodology for tool-calling reliability, built by directly extending Chapter 7 Topic 9's evaluation discipline (Recall@K, MRR, NDCG@K for retrieval) into the tool-selection and tool-sequencing domain.
- The core insight: tool-calling reliability is measurable in exactly the same spirit as retrieval quality — given a labeled set of (email, expected tool-call sequence) pairs, you can compute precise metrics for whether the agent calls the right tools, with the right arguments, in the right order, and reaches the right terminal outcome. Without this, every schema and prompt change discussed in Topics 3-5 is validated by intuition alone — exactly the anti-pattern this entire project has consistently rejected since Chapter 7.
- Why this deserves to be the final topic in this chapter: it is the validation mechanism for everything else in Chapters 3, 9, and 10 — tool design (Topic 2), schema quality (Topic 3), error handling (Topic 4), and multi-tool sequencing (Topic 5) are all *hypotheses* about what produces reliable behavior; this topic is where those hypotheses get checked against real, measured evidence.

---

### 2. Internal Working — Step by Step

**Building the labeled test set — the actual prerequisite:**

1. For each test email, label the **expected tool-call sequence**: which tools should be called, with what arguments, in what order (where order matters), and what the final terminal outcome should be (`finalize_classification` with a specific label, or `refuse_out_of_scope`).
2. Cover the realistic range of patterns: single-tool cases (pure classification, no tool needed), two-tool cases (validate a reference then finalize), and multi-tool cases exercising Topic 5's sequencing concerns (check history, then validate reference, then search knowledge base, then finalize).
3. Deliberately include **negative test cases** — emails that should clearly NOT trigger a specific tool (testing against over-triggering, Chapter 9 Topic 1's concern) and emails at the boundary between two plausibly-confusable tools (testing Topic 3's disambiguation).

**The metrics, each targeting a different failure mode:**

1. **Tool Selection Accuracy**: for each expected tool call in the sequence, was the *correct* tool actually called at some point? (Binary per expected tool, per test case.)
2. **Tool Selection Precision**: of all tools actually called, what fraction were genuinely expected/necessary? (Catches over-triggering — calling tools that shouldn't have been called.)
3. **Argument Correctness**: for each correctly-selected tool call, were the arguments passed to it correct (e.g. the right `reference_number` extracted, not a garbled or wrong one)?
4. **Sequence Correctness**: for multi-tool cases where order matters (per Topic 5's discussion), was the actual order consistent with the expected order?
5. **Terminal Outcome Accuracy**: did the agent reach the correct final decision (`finalize_classification` with the right label, or `refuse_out_of_scope` when appropriate)? This is the "did it work in the end" check, distinct from whether the *path* to get there was ideal.

---

### 3. How It Is Implemented in This Project

```python
# Labeled test set format -- extends Chapter 7 Topic 9's evaluation discipline
# to tool-calling behavior specifically

TOOL_CALLING_TEST_SET = [
    {
        "email": "My personal loan EMI bounced this month, please help.",
        "sender_email": "customer1@example.com",
        "expected_tool_calls": [
            {"tool": "check_sender_history", "args_contains": {"sender_email": "customer1@example.com"}},
        ],
        "expected_terminal": {"tool": "finalize_classification", "label": "Non-FD"},
        "order_matters": False,  # only one non-terminal tool expected
    },
    {
        "email": "What is the status of my FD BJ2019FD7717?",
        "sender_email": "customer2@example.com",
        "expected_tool_calls": [
            {"tool": "check_sender_history", "args_contains": {"sender_email": "customer2@example.com"}},
            {"tool": "validate_fd_reference", "args_contains": {"reference_number": "BJ2019FD7717"}},
        ],
        "expected_terminal": {"tool": "finalize_classification", "label": "FD"},
        "order_matters": True,
        "expected_order": ["check_sender_history", "validate_fd_reference"],
    },
    {
        # NEGATIVE case: should NOT trigger search_knowledge_base
        "email": "My personal loan EMI bounced this month, please help.",
        "sender_email": "customer1@example.com",
        "forbidden_tools": ["search_knowledge_base", "validate_fd_reference", "lookup_product_catalog"],
    },
]


def evaluate_tool_calling(test_case: dict, actual_tool_trace: list, actual_terminal: dict) -> dict:
    """actual_tool_trace: [{"tool": name, "args": {...}}, ...] in call order,
    EXCLUDING the terminal call. actual_terminal: the final finalize/refuse call."""

    results = {"selection_correct": [], "args_correct": [], "forbidden_violated": []}

    for expected in test_case.get("expected_tool_calls", []):
        matching_calls = [c for c in actual_tool_trace if c["tool"] == expected["tool"]]
        selection_hit = len(matching_calls) > 0
        results["selection_correct"].append(selection_hit)

        if selection_hit:
            args_ok = all(
                matching_calls[0]["args"].get(k) == v
                for k, v in expected.get("args_contains", {}).items()
            )
            results["args_correct"].append(args_ok)

    for forbidden_tool in test_case.get("forbidden_tools", []):
        was_called = any(c["tool"] == forbidden_tool for c in actual_tool_trace)
        results["forbidden_violated"].append(was_called)

    order_correct = None
    if test_case.get("order_matters") and "expected_order" in test_case:
        actual_order = [c["tool"] for c in actual_tool_trace if c["tool"] in test_case["expected_order"]]
        order_correct = actual_order == test_case["expected_order"]

    terminal_correct = None
    if "expected_terminal" in test_case:
        terminal_correct = (
            actual_terminal.get("tool") == test_case["expected_terminal"]["tool"] and
            actual_terminal.get("label") == test_case["expected_terminal"].get("label")
        )

    return {
        "selection_accuracy": sum(results["selection_correct"]) / max(len(results["selection_correct"]), 1),
        "args_correctness": sum(results["args_correct"]) / max(len(results["args_correct"]), 1),
        "any_forbidden_called": any(results["forbidden_violated"]),
        "order_correct": order_correct,
        "terminal_correct": terminal_correct,
    }


def run_regression_suite(test_set: list, agent_fn) -> dict:
    """Runs the FULL test set, aggregates metrics -- this is what should run
    BEFORE deploying any schema, prompt, or sequencing change (Topics 3-5),
    comparing before/after just like every other evaluation in this project."""
    all_results = []
    for test_case in test_set:
        tool_trace, terminal = agent_fn(test_case["email"], test_case.get("sender_email"))
        result = evaluate_tool_calling(test_case, tool_trace, terminal)
        all_results.append(result)

    return {
        "avg_selection_accuracy": sum(r["selection_accuracy"] for r in all_results) / len(all_results),
        "avg_args_correctness": sum(r["args_correctness"] for r in all_results) / len(all_results),
        "forbidden_violation_rate": sum(r["any_forbidden_called"] for r in all_results) / len(all_results),
        "order_correct_rate": sum(1 for r in all_results if r["order_correct"]) / max(
            sum(1 for r in all_results if r["order_correct"] is not None), 1),
        "terminal_accuracy": sum(1 for r in all_results if r["terminal_correct"]) / max(
            sum(1 for r in all_results if r["terminal_correct"] is not None), 1),
    }
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **Building this test set has a real, ongoing cost, exactly like every other labeled evaluation set in this project**: constructing (email, expected tool sequence) pairs requires understanding the actual, correct behavior for each case — this is genuine engineering work, not automatable from the emails alone, and should be budgeted for explicitly (echoing Chapter 7 Topic 9's labeling-cost discussion).
- **Running the full regression suite costs real API calls**: every test case requires actually running the agent (one or more real `client.messages.create()` calls per test case, depending on how many tool-call turns it takes) — at a large test set size, this is a genuine, non-trivial cost that should be weighed against how frequently the suite needs to run (every schema/prompt change, ideally, but perhaps not on every trivial code commit unrelated to agent behavior).
- **Flakiness**: LLM outputs have some inherent variability even at low temperature — a test case that passes on one run might occasionally fail on another purely due to sampling variance, not a genuine regression. This requires either running each test case multiple times and looking at a pass rate rather than a binary pass/fail, or explicitly setting temperature to its lowest reliable value for testing purposes (accepting this doesn't perfectly match production temperature settings, a trade-off worth being explicit about).
- **Monitoring**: this offline regression suite should be complemented by production monitoring of the *same* metrics on real traffic (tool selection accuracy inferred from downstream outcome quality, forbidden-tool-call rate, terminal accuracy where ground truth can be established via later customer feedback or human review) — the offline suite catches regressions before deployment; production monitoring catches drift and novel failure patterns the offline suite's fixed test cases don't cover.
- **Cost of comprehensive coverage vs. representative sampling**: a fully comprehensive test set covering every conceivable tool combination and edge case is likely infeasible to build and maintain — a representative, strategically-sampled set (covering the most common patterns plus the highest-risk edge cases, like the boundary cases between confusable tools from Topic 3) is the practical target, following the same practical-coverage reasoning applied to Chapter 7 Topic 9's retrieval evaluation set.
- **Security**: test cases involving customer-like data (sender emails, reference numbers) should use clearly synthetic, obviously-fake values, never real customer data, to avoid any accidental PII exposure in test fixtures, logs, or version-controlled test files.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **Testing at the unit level (individual tool functions, no model involved) vs. integration level (the full agent loop with real model calls)**: unit testing `validate_fd_reference`'s backing function directly (no API call) is fast, cheap, and deterministic — appropriate for testing the tool's own logic (Topic 2's design, Topic 4's error handling). Integration testing (running the full agent loop with real model calls, as shown above) is the only way to actually test tool *selection* and *sequencing*, since that behavior lives in the model's reasoning, not in any function you can unit test directly. Both are necessary; they test different layers and neither substitutes for the other.
- **How often should the full regression suite run?**: ideally on every change to a tool schema, system prompt, or the toolset itself (Topics 3-5's changes) — treating it with the same "must pass before merge" discipline as a traditional software test suite, even though the underlying behavior being tested (an LLM's reasoning) is probabilistic rather than deterministic, requiring the pass-rate-based interpretation discussed in Section 4's flakiness point rather than a strict binary pass/fail gate.
- **Aggregate metrics vs. per-category breakdowns**: reporting one overall "tool calling accuracy" number is less useful than breaking results down by test case category (single-tool cases, multi-tool sequencing cases, negative/forbidden-tool cases, boundary/disambiguation cases) — exactly the same principle as Chapter 8 Topic 3's insistence on faithfulness/relevance/correctness as separate metrics rather than one aggregate "quality" score, since different categories point to different fixes when they fail.

---

### 6. Alternatives and When to Use Each

- **No systematic testing, relying on manual spot-checks (this project's implicit state before this topic)**: acceptable only during the very earliest prototyping, and increasingly risky as toolset complexity grows (Topic 5's combinatorial concern) — manual spot-checking cannot scale to cover the growing space of tool combinations and sequencing patterns.
- **Full regression suite with labeled expected tool sequences (this topic's approach)**: the correct standard for any agent whose tool-calling behavior materially affects business outcomes, which describes this project's classification and customer-response agent directly.
- **Property-based or fuzz testing (a more advanced technique worth knowing about)**: rather than only testing hand-labeled specific cases, generating large numbers of synthetic email variations (paraphrases, Hinglish variants per Chapter 9 Topic 2, edge-case phrasings) and checking that tool-calling behavior remains *consistent* across semantically-equivalent variations — a complementary technique to hand-labeled test cases, worth adopting once the hand-labeled suite is mature and specific robustness-to-phrasing-variation becomes a priority.

---

### 7. Common Mistakes and Production Failures

- Deploying schema, prompt, or toolset changes (Topics 3-5) without running any regression test, relying purely on a few manual spot-checks that don't represent the full range of realistic tool-calling patterns.
- Treating a single flaky test failure as a definitive regression without accounting for LLM output variance, or conversely, dismissing a genuine regression as "just flakiness" without properly investigating a consistently-failing pattern.
- Building a test set that only covers positive cases (tools that should be called) without negative cases (tools that should NOT be called), missing over-triggering regressions entirely.
- Not breaking down results by test case category, treating tool-calling reliability as one monolithic metric that provides insufficient diagnostic signal when it drops.
- Using real customer data in test fixtures, creating an unnecessary PII exposure risk in test files and logs.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: Why can't tool-calling reliability be tested purely through unit tests of individual tool functions?**
A: Unit tests of a tool's backing function (like `validate_fd_reference`'s data access logic) can verify the function itself works correctly given specific inputs, but they cannot test whether the *model* correctly decides to call that tool, with what arguments, and in what sequence relative to other tools — that behavior lives entirely in the model's reasoning over the schema and conversation context, which can only be tested by actually running the full agent loop with real (or realistically simulated) model calls.

**Q: What is the difference between Tool Selection Accuracy and Tool Selection Precision, and why are both needed?**
A: Selection Accuracy asks, for each tool that *should* have been called, was it actually called (catches under-triggering, Chapter 9 Topic 1's concern). Selection Precision asks, of all tools that *were* actually called, how many were genuinely necessary (catches over-triggering — unnecessary tool calls adding cost and latency without benefit). A system can score well on one while failing the other — always calling every available tool would achieve perfect accuracy (nothing needed is ever missed) but terrible precision (lots of unnecessary calls) — both metrics are needed to get the complete picture.

**Intermediate:**

**Q: Why must negative test cases (emails that should NOT trigger a specific tool) be included in the test set, not just positive cases?**
A: Positive-only test sets can only detect under-triggering (a tool that should have fired but didn't) — they provide no signal about over-triggering (a tool firing when it shouldn't, wasting cost and latency, or worse, retrieving and using irrelevant information in the final answer). Negative test cases, especially at the boundary between two plausibly-confusable tools (Topic 3's disambiguation concern), are specifically needed to catch schema or prompt changes that inadvertently make the model too eager to call a tool.

**Q: How would you handle the inherent output variability of LLMs when designing a pass/fail criterion for this regression suite?**
A: Rather than treating a single run's result as a definitive pass or fail, run each test case multiple times (e.g. 3-5 repetitions) and compute a pass *rate* rather than a binary outcome — a test case passing 5/5 times is a much stronger signal than one passing 3/5 times, and a genuine regression should show a consistently lower pass rate across repeated runs, distinguishing it from occasional sampling-driven flakiness. Setting the model's temperature to a low, consistent value specifically for test runs also reduces (though doesn't eliminate) variability, at the cost of not perfectly matching whatever temperature setting production actually uses.

**Advanced:**

**Q: Design the CI/CD integration for this regression suite, given that running it costs real API calls and has some inherent flakiness.**
A: Run the full suite automatically on any pull request touching tool schemas, the system prompt, or the `TOOLS` list — but not on every unrelated code commit, to control cost. Use a pass-rate threshold rather than requiring 100% pass (e.g. flag for human review if any test case's pass rate across repeated runs drops below a set threshold, like 80%, rather than failing the build outright on any single run's failure) to accommodate legitimate LLM variance without either being too strict (blocking merges on noise) or too lenient (missing genuine regressions). Track pass rates over time per test case category (Topic 6's category breakdown) as a trend, not just a point-in-time gate, so a slow, creeping degradation across several small changes is visible even if no single change triggers the threshold alone.

**Q: A regression test for a specific multi-tool sequencing case (check history, then validate reference, then finalize) has been passing consistently for months. After an unrelated schema change to a completely different tool (`lookup_product_catalog`), this test starts failing. How is this possible, and how would you diagnose it?**
A: This is the cross-tool interaction effect flagged in Topic 3's advanced interview question — since all tool schemas are reasoned over jointly by the model on every call, a change to one tool's description can shift the model's relative behavior toward or away from other tools in ways that aren't strictly isolated, even when the changed tool is never directly involved in the now-failing test case. Diagnosis: compare the full `messages` trace for the failing test case before and after the schema change, looking specifically at whether the model's tool-selection reasoning (visible in its intermediate text, if any, or inferable from which tools it considers) shows any influence from the changed tool's new description — this is exactly why the full regression suite, not just tests for the directly-changed tool, must be re-run after any single schema change, treating the whole toolset as one interacting system rather than independently-testable components.

**Scenario-based:**

**Q: The regression suite shows excellent Tool Selection Accuracy and Argument Correctness, but Terminal Outcome Accuracy is noticeably lower. What does this specific pattern suggest, and where would you look next?**
A: This pattern suggests the agent is correctly identifying and calling the right tools with the right arguments (the tool-calling mechanics, Topics 1-5's concern, are working well) but is making an incorrect final decision despite having gathered the correct information — this points toward a problem in the reasoning/synthesis step that happens *after* tool results are gathered, not in the tool-calling process itself. This connects to Chapter 2's original prompt engineering work (the classification logic itself) and Chapter 8 Topic 3's faithfulness/relevance framework — the investigation should shift from "are the right tools being called correctly" (apparently yes) to "is the final synthesis correctly using the gathered information to reach the right conclusion" (apparently not, in some cases) — a genuinely different debugging direction than anything covered in this chapter's tool-engineering focus, illustrating why breaking metrics down by category (Topic 6's own recommendation) is valuable for correctly routing the investigation.

---

### 9. Hidden Concepts and Prerequisites

- **This topic is a direct application of general software testing principles (unit vs. integration testing, regression suites, flakiness handling) to a probabilistic system** — the specific adaptation needed (pass-rate thresholds instead of binary pass/fail, category-based breakdowns) reflects the genuine difference between testing deterministic code and testing LLM-based behavior, but the underlying testing discipline itself is not novel to this domain.
- **This connects directly forward to Chapter 15's Evaluating Agents Properly chapter**, which will formalize exactly this chapter's testing methodology (task-level vs. step-level metrics, did it call the right tool not just reach the right label) into a complete, systematic agent evaluation framework — this topic's regression suite is the concrete, hands-on foundation that chapter builds into a more comprehensive methodology.
- **The relationship between this topic's tool-calling regression suite and Chapter 7 Topic 9's retrieval evaluation harness is one of structural parallelism, not coincidence** — both exist because this project consistently refuses to accept "it seems to work" as sufficient evidence for a production system, instead building the specific measurement infrastructure needed to make every design decision (BM25 parameters, RRF weighting, MMR lambda, tool schema wording, sequencing guidance) evidence-based rather than intuition-based.

---

### 10. Revision Summary

> This topic closes every "should be validated empirically" deferral made throughout this chapter (Topics 3, 4, 5) by building a systematic tool-calling regression suite, directly extending Chapter 7 Topic 9's evaluation discipline into the tool-selection and sequencing domain. A labeled test set of (email, expected tool-call sequence, expected terminal outcome) pairs — including deliberate negative cases testing against over-triggering and boundary cases testing schema disambiguation — enables computing Tool Selection Accuracy, Selection Precision, Argument Correctness, Sequence Correctness, and Terminal Outcome Accuracy as distinct, separately-diagnostic metrics, mirroring Chapter 8 Topic 3's insistence on faithfulness/relevance/correctness as separate rather than aggregate scores. This requires integration-level testing (running the real agent loop) since tool-selection behavior lives in the model's reasoning, not in any unit-testable function alone, and must account for genuine LLM output variance via pass-rate thresholds rather than strict binary pass/fail criteria. Every schema, prompt, or toolset change from Topics 3-5 should be validated against this full suite before deployment — and critically, against the *entire* suite, not just tests directly related to the changed tool, since all tool schemas are reasoned over jointly and a change to one tool can shift selection behavior for others in ways that only comprehensive regression testing reliably catches.

---
