# Chapter 9: Retrieval — Putting It to Work

## Topic 3: Wiring `search_knowledge_base` into the Agent as a Real Tool

---

### 1. Concept, Intuition, and Why It Exists

- Topic 1 designed the *decision* of when to retrieve, using `search_knowledge_base` as a hypothetical tool schema. This topic is where it stops being hypothetical — the full Chapter 7 pipeline (hybrid BM25+dense+RRF, reranking, MMR) and Chapter 8's generation-layer machinery (prompt construction, citation) get wired into one real, callable Python function that plugs into this project's existing `run_agent()` loop from Chapter 3.
- Why this is a distinct topic from "just call the function": this project's own history flagged this exact gap explicitly — earlier chapters repeatedly described `search_knowledge_base` as "the natural next step" without ever actually integrating it into the live agent. This topic is that integration, done properly, with the same rigor as `validate_fd_reference`'s integration in Chapter 3.
- The core engineering challenge: `validate_fd_reference` is a simple, fast, deterministic CSV lookup — wiring it in was straightforward. `search_knowledge_base` is a multi-stage pipeline (retrieve → rerank → MMR → format context) with real latency, real failure modes, and outputs that need careful formatting before being handed back to the model as a tool result. This topic covers doing that integration correctly.

---

### 2. Internal Working — Step by Step

1. **Tool call arrives**: the model, mid-`run_agent()` loop, decides to call `search_knowledge_base` with a `query` argument (Topic 1's trigger decision having fired).
2. **Backing function executes the full Chapter 7 pipeline**: tokenize/embed the query (using Topic 2's transformed variants), run BM25 and dense retrieval in parallel, fuse via RRF, rerank with the cross-encoder, apply MMR for diversity — exactly the pipeline built across Chapter 7, now invoked as a single function call from within the agent loop.
3. **Result formatting for the model**: Chapter 8 Topic 1's context-block construction (source-tagged, budget-aware) determines how the retrieved chunks are packaged into the `tool_result` content sent back to the model — this is NOT the same as constructing a full generation prompt (Chapter 8 assumed a separate generation step); here, the retrieved content becomes part of the ongoing tool-use conversation, and the model itself will synthesize an answer using it in a subsequent turn.
4. **Error handling**: if retrieval finds nothing relevant (e.g., an out-of-domain question the knowledge base genuinely doesn't cover), the tool result must communicate this clearly and structurally — a `{"found": False, "reason": "no relevant policy content found"}`-style result, exactly matching the existing pattern `validate_fd_reference` already uses for its own not-found case (`found=False`), so the model has a consistent, learnable signal shape across all its tools.
5. **The model's next turn**: having received the retrieved (or empty) result, the model decides again — synthesize an answer using the retrieved content (citing sources, per Chapter 8 Topic 2), call another tool, or finalize with `refuse_out_of_scope` if the retrieved content genuinely can't answer the question.

---

### 3. How It Is Implemented in This Project

```python
def search_knowledge_base(query: str, top_k: int = 5) -> dict:
    """Full production backing function for the search_knowledge_base tool.
    Wires together Chapter 7's retrieval pipeline and Chapter 8's context
    formatting into one callable unit, matching validate_fd_reference's
    dict-return-value convention."""

    # Step 1: Query transformation (Chapter 9 Topic 2)
    transformed = transform_query_for_retrieval(query)

    # Step 2: Hybrid retrieval (Chapter 7 Topic 4)
    bm25_ranked = bm25_retrieve(transformed["bm25_query"], top_k=20)
    dense_ranked = dense_retrieve(transformed["dense_query"], top_k=20)
    fused = reciprocal_rank_fusion(
        {"BM25": bm25_ranked, "Dense": dense_ranked}, k=60
    )

    if not fused:
        return {"found": False, "reason": "No relevant policy content found for this query."}

    # Step 3: Reranking (Chapter 7 Topic 7) -- narrow fused candidates to top-10
    candidate_docs = [get_doc_by_id(doc_id) for doc_id, _, _ in fused[:10]]
    reranked = cross_encoder_rerank(query, candidate_docs)

    # Step 4: MMR for diversity (Chapter 7 Topic 6) -- final top_k selection
    final_chunks = maximal_marginal_relevance(query, reranked, k=top_k, lambda_param=0.6)

    # Step 5: Format for the model, source-tagged (Chapter 8 Topic 1/2 pattern)
    formatted_chunks = [
        {"source": doc["metadata"]["source"], "text": doc["page_content"]}
        for doc, _, _, _ in final_chunks
    ]

    return {"found": True, "chunks": formatted_chunks}


SEARCH_KNOWLEDGE_BASE_TOOL = {
    "name": "search_knowledge_base",
    "description": (
        "Call this when you need FD policy information you don't already know -- "
        "for example, questions about premature withdrawal penalties, interest rate "
        "rules, nominee provisions, or maturity procedures. Do NOT call this for "
        "simple FD-vs-Non-FD classification, and do NOT call this for looking up a "
        "specific customer's FD record -- use validate_fd_reference for that."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "A clear, self-contained policy question."}
        },
        "required": ["query"],
    },
}

# Extending Chapter 3's run_agent() loop with ONE new elif branch,
# mirroring the exact structure already used for validate_fd_reference:
#
#     elif block.name == "search_knowledge_base":
#         result = search_knowledge_base(block.input["query"])
#         if verbose:
#             print(f"  [step {step}] OBSERVE -> found={result['found']}, "
#                   f"{len(result.get('chunks', []))} chunks")
#         tool_result_blocks.append({
#             "type": "tool_result",
#             "tool_use_id": block.id,
#             "content": json.dumps(result),
#         })
#
# This is mechanically identical to how validate_fd_reference's result
# is appended -- the model receives it as a new message and decides again.
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **Latency compounds inside the agent loop**: unlike `validate_fd_reference` (a fast CSV lookup), `search_knowledge_base` invokes Chapter 7's full multi-stage pipeline plus a reranking model call — this is a meaningfully slower tool call, and if the model calls it multiple times in one `run_agent()` run (e.g. refining its query after an unsatisfying first result), latency compounds across the loop. This should be monitored as its own metric, separate from the simpler `validate_fd_reference` call latency.
- **JSON serialization of retrieved chunks**: `json.dumps(result)` must handle the chunk content safely — retrieved policy text could theoretically contain characters that need escaping, and very large result sets need truncation logic (connecting back to Chapter 8 Topic 1's token budgeting, now applied at the tool-result level rather than the final generation-prompt level).
- **The "found": False case must be genuinely actionable for the model**: simply returning nothing or an empty list is worse than an explicit `{"found": False, "reason": "..."}` structure — the model needs a clear signal to decide its next action (try a different query phrasing, or conclude the knowledge base doesn't cover this and route to `refuse_out_of_scope` or a human-escalation path), exactly paralleling how `validate_fd_reference`'s explicit `found=False` already guides the model's behavior for unrecognized reference numbers.
- **Debugging a bad final answer that involved a `search_knowledge_base` call**: the full observability chain now includes the transformed query (Topic 2), the raw retrieval results, the reranked/MMR'd final chunks, and the model's synthesis of those chunks into an answer — each stage needs its own visibility (logging) so a bad final answer can be traced back to exactly which stage introduced the problem, rather than treating "the RAG tool call" as one opaque black box.
- **Monitoring**: track `search_knowledge_base` call latency percentiles separately from `validate_fd_reference`'s, track the `found: False` rate (a rising rate signals either a genuine knowledge base coverage gap or a query-transformation regression), and track how often the model calls it more than once within a single `run_agent()` run (a signal of either genuinely complex multi-part questions or the model being unsatisfied with initial results — worth distinguishing).
- **Security**: the `query` argument comes from the model, which in turn is influenced by the customer's email content — Chapter 3's existing "treat content as data, not commands" principle must extend to ensure a customer cannot manipulate the email text into making the model construct a `search_knowledge_base` query that behaves unexpectedly (e.g. attempting to retrieve content clearly outside the FD domain, testing the boundaries of what the knowledge base will surface).
- **Deployment**: the full pipeline invoked by this one function call spans several of this project's previously separate notebooks/modules (Chapters 6, 7, 8) — in production this needs to be consolidated into a proper importable module (not scattered across notebook cells), with each stage's dependencies (Qdrant client, embedding model, reranker model, BM25 index) initialized once and reused across calls, not rebuilt on every single `search_knowledge_base` invocation.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **Return raw chunks vs. return a synthesized mini-answer from the tool itself**: this project's design returns raw, source-tagged chunks and lets the *agent's own next turn* synthesize the final answer (consistent with Chapter 8's citation and faithfulness architecture, which depends on the model doing the synthesis with visibility into sources). An alternative design could have the tool itself call a smaller, cheaper model to pre-synthesize a mini-answer before returning it — reducing the main agent's synthesis burden, but adding an extra model call inside the tool and losing the direct chunk-to-citation traceability Chapter 8 Topic 2 depends on. The raw-chunks approach is more consistent with this project's established faithfulness/citation infrastructure.
- **Single top_k for all queries vs. adaptive top_k**: a fixed `top_k=5` (as shown) is simple; an adaptive approach (fewer chunks for narrow, specific questions, more for broad ones) could better match Chapter 8 Topic 1's token budgeting to actual need, but adds complexity that should be justified by measured benefit, not assumed.
- **Real-time dilemma — how many times should the agent be allowed to call `search_knowledge_base` in one run before being forced to finalize?**: this project's existing `max_steps` parameter in `run_agent()` already provides a safety net against infinite looping generally; a specific policy (e.g. cap `search_knowledge_base` calls at 2 per run, encouraging the model to synthesize from what it has rather than endlessly re-querying) may be a reasonable additional guardrail once production data shows repeated-query behavior is a real pattern worth constraining.

---

### 6. Alternatives and When to Use Each

- **Direct wiring into the existing `run_agent()` loop (this topic's approach)**: the natural, minimal-disruption choice given this project's established Chapter 3 architecture — reuses the same loop, same tool-result pattern, same conversational flow.
- **A separate, dedicated RAG sub-agent invoked as a "tool" that itself runs a mini agent loop internally**: more sophisticated (relevant once Chapter 13's Agentic RAG topic is reached), appropriate when retrieval itself needs multi-step reasoning (e.g. deciding to reformulate and re-retrieve autonomously) — over-engineered for this project's current stage where a single retrieval call per invocation is sufficient.
- **A synchronous, non-agentic RAG call made before the agent loop even starts (bypassing tool-use entirely)**: simpler to implement, but abandons the flexibility of letting the model decide *whether* and *how* to use retrieval (Topic 1's entire point) — reverts to "always retrieve," the exact anti-pattern Topic 1 was built to avoid.

---

### 7. Common Mistakes and Production Failures

- Returning an empty list or `None` instead of an explicit, structured `{"found": False, "reason": ...}` result, leaving the model without a clear signal for how to proceed.
- Not truncating or budget-checking the tool result before JSON-serializing it, risking an oversized tool-result payload that itself contributes to context window pressure (Chapter 8 Topic 1's concern, now relevant at the tool-result level too).
- Rebuilding expensive resources (embedding model, Qdrant client, reranker) on every single function call instead of initializing them once at module load time — a significant, avoidable latency and cost regression at production volume.
- Not logging each pipeline stage's intermediate output (transformed query, raw retrieval, reranked/MMR'd final chunks) separately, making root-cause debugging of a bad final answer far harder than it needs to be.
- Allowing unlimited repeated `search_knowledge_base` calls within a single agent run without any cap, risking runaway latency and cost for a small fraction of unusually persistent (or adversarially crafted) queries.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: How does wiring `search_knowledge_base` into `run_agent()` differ mechanically from wiring in `validate_fd_reference`?**
A: Mechanically, the integration pattern is identical — both are tool calls the model can invoke, both return a dict result that gets JSON-serialized and appended back into the conversation as a `tool_result`. The difference is what happens inside the backing function: `validate_fd_reference` is a fast, deterministic CSV lookup, while `search_knowledge_base` invokes Chapter 7's entire multi-stage retrieval pipeline (hybrid search, reranking, MMR) — meaningfully more latency, more potential failure points, and more complex output formatting.

**Q: Why does `search_knowledge_base` return an explicit `{"found": False, "reason": ...}` structure rather than an empty result when nothing relevant is retrieved?**
A: This mirrors `validate_fd_reference`'s existing convention and gives the model a clear, structured signal to reason about on its next turn — an empty or `None` result is ambiguous (did the search fail technically, or genuinely find nothing relevant?), while an explicit `found: False` with a reason lets the model correctly decide its next action, such as trying a different query phrasing or concluding the knowledge base doesn't cover this topic.

**Intermediate:**

**Q: The model calls `search_knowledge_base` twice within one `run_agent()` run, using different query phrasings each time. Is this a bug or expected behavior?**
A: This can be entirely expected and even desirable behavior — if the first retrieval didn't surface satisfying results (e.g. a `found: False` or chunks the model judges as not fully answering the question), the model reformulating and retrying is exactly the kind of agentic flexibility this project's tool-use architecture is designed to support, mirroring how it might call `validate_fd_reference` and then decide it needs more information before finalizing. It becomes a concern only if it happens excessively or unpredictably in production, which is why monitoring the multiple-call rate (as discussed in Section 4) matters — distinguishing legitimate multi-step reasoning from a pathological retry loop.

**Q: Why does this project's design have the backing function return raw, source-tagged chunks rather than a synthesized answer?**
A: This directly supports Chapter 8's citation and faithfulness architecture — the main agent's final synthesis step needs visibility into which specific source chunk supports which claim in order to produce reliable per-claim citations (Chapter 8 Topic 2) and to make hallucination detection (Chapter 8 Topic 4) possible. If the tool pre-synthesized an answer internally, that direct chunk-to-claim traceability would be lost, undermining the verification infrastructure built specifically to support this project's regulated-domain requirements.

**Advanced:**

**Q: Design the full observability/logging strategy for a `search_knowledge_base` call, sufficient to debug a customer complaint about a specific bad answer weeks after it happened.**
A: Log, per call: the original raw customer email/query, the Topic 2-transformed query variants actually used for BM25 and dense retrieval, the raw ranked results from each retriever before fusion, the RRF-fused ranking, the reranked ordering, the final MMR-selected chunks with their source tags, and the model's final synthesized answer with its declared citations (Chapter 8 Topic 2's `sources_used`). This full pipeline trace, stored with a request ID correlating all stages, makes it possible to determine exactly which stage — query transformation, retrieval, reranking, MMR, or generation/citation — is responsible for a specific bad outcome, rather than only being able to say "the RAG tool produced a bad result" without further insight.

**Q: A teammate proposes caching `search_knowledge_base` results by query text to reduce latency and cost for repeated questions. Evaluate this proposal.**
A: Caching is reasonable for genuinely identical or near-identical queries, which likely recur given a finite set of common FD policy questions across many customers. The key risks: cache invalidation when the underlying knowledge base changes (a policy update, per Chapter 4's ingestion pipeline, must invalidate any cached results referencing the updated content — otherwise this reintroduces exactly the correctness/staleness risk Chapter 8 Topic 3 flagged), and determining what counts as "the same query" given this project's Topic 2 transformation pipeline (should caching key on the raw query, the transformed query, or some canonicalized form — each has different hit-rate and correctness implications). A safe implementation ties cache entries to the knowledge base's version/last-ingestion-timestamp (echoing Chapter 6 Topic 8's embedding model migration concerns) so a knowledge base update automatically invalidates affected cached results, rather than relying on manual cache-clearing that's easy to forget.

**Scenario-based:**

**Q: In production, `search_knowledge_base` calls are taking noticeably longer than expected, and profiling reveals most of the time is spent in the reranking step (Chapter 7 Topic 7), not retrieval itself. Diagnose and propose fixes.**
A: First confirm whether reranking is being called with proper batching (Chapter 7 Topic 7 explicitly flagged one-at-a-time cross-encoder scoring as a major anti-pattern) — if the integration accidentally loops and scores candidates individually rather than passing the full candidate list to a single batched `predict()` call, this alone could explain a significant slowdown. If batching is already correct, check the candidate pool size being reranked — if it's larger than necessary (e.g. reranking all 20 RRF-fused candidates when Chapter 7 Topic 9's evaluation shows the correct answer is reliably within the top 10), narrowing the pre-rerank candidate pool size reduces reranking's per-call cost proportionally, trading a small, measurable recall risk for a real latency improvement — a decision that should be validated against the evaluation harness rather than assumed safe.

---

### 9. Hidden Concepts and Prerequisites

- **This topic is the concrete instance of "tool composition" in agentic systems** — a single tool (`search_knowledge_base`) internally orchestrates several other significant subsystems (Qdrant, BM25 index, reranker model, MMR logic) that are themselves complex, but this complexity is fully hidden behind one simple function signature from the calling agent's perspective — a form of encapsulation that's essential for keeping the agent loop itself simple and maintainable as more sophisticated tools are added in later chapters.
- **State and resource lifecycle management**: unlike `validate_fd_reference`'s stateless CSV read, `search_knowledge_base` depends on several stateful, expensive-to-initialize resources (the embedding model, the Qdrant client connection, the BM25 index, the reranker model) — proper production wiring requires these to be initialized once at application startup and passed into or accessed by the function, not recreated per-call, a distinction easy to overlook when moving from notebook-based development to production deployment.
- **This connects directly forward to Chapter 10's Tool Engineering chapter**: that chapter goes deep on tool schema design, error/timeout/retry handling, and multi-tool agent testing — this topic's `search_knowledge_base` wiring is the first non-trivial (multi-stage, higher-latency) tool this project has built, making it the natural motivating example for Chapter 10's more general tool-engineering principles.

---

### 10. Revision Summary

> This topic converts the previously-hypothetical `search_knowledge_base` tool into a real, production-wired function integrated into Chapter 3's existing `run_agent()` loop, using the exact same tool-call/tool-result pattern already established for `validate_fd_reference`. The backing function orchestrates Chapter 7's full retrieval pipeline (hybrid BM25+dense+RRF, reranking, MMR) and Chapter 8's context-formatting conventions (source-tagged chunks) into one callable unit, returning raw chunks rather than a pre-synthesized answer specifically to preserve the chunk-to-citation traceability Chapter 8's faithfulness infrastructure depends on. Unlike the fast, deterministic `validate_fd_reference`, this tool has real, multi-stage latency and failure modes requiring its own dedicated monitoring (call latency, `found: False` rate, multiple-call-per-run rate) and full pipeline-stage logging for debugging. Expensive resources (models, indexes, client connections) must be initialized once at startup, not per-call — a production discipline distinct from anything needed for the simpler tools built in Chapter 3.

---
