# Chapter 9: Retrieval — Putting It to Work

## Topic 7: Hallucination as a Measured Failure Mode — The Agent-Integration Angle

---

### 1. Concept, Intuition, and Why It Exists

- Chapter 8 Topic 4 built the general hallucination-detection mechanism (two-tier embedding-then-LLM-judge entailment checking) as a standalone generation-layer capability. This topic asks a narrower, more concrete question specific to this chapter: **now that `search_knowledge_base` is wired into the live agent (Topic 3) and retrieval triggering is a real decision the agent makes (Topic 1), how does hallucination risk actually manifest across the *whole agent loop*, not just within a single generation call?**
- The distinction matters because Chapter 8 Topic 4 assumed a context already existed and a claim was already generated from it — a clean, bounded verification problem. In the live agent, hallucination risk now has *additional* sources unique to the agentic setting: the model might hallucinate about *whether* it retrieved (claiming to have checked the knowledge base when the tool trace shows it didn't), might hallucinate *which* tool result answered *which* part of a compound question, or might blend a genuine `validate_fd_reference` result with an ungrounded general claim in ways that are harder to disentangle than a single-context, single-claim check.
- This topic is where Chapter 8's verification machinery gets stress-tested against this project's actual, live, multi-tool agent behavior — not a hypothetical scenario, but the real system built across Chapters 3 and this chapter's Topics 1-6.

---

### 2. Internal Working — Step by Step

**Three agent-specific hallucination patterns beyond Chapter 8 Topic 4's scope:**

1. **False tool-use claims**: the model's final answer states or implies it checked something it never actually called a tool for — e.g. saying "I've verified your FD status" when the tool-use trace for that request shows no `validate_fd_reference` call was made. This requires cross-referencing the final answer's *claims about its own process* against the actual tool-call trace, a check with no equivalent in Chapter 8 Topic 4's single-context framing.
2. **Misattributed synthesis across multiple tool results**: when both `validate_fd_reference` and `search_knowledge_base` are called in the same run (Topic 1's compound-question scenario), the final answer must correctly attribute the customer-specific fact to the database lookup and the general policy fact to the retrieved content — a claim like "your FD's penalty rate is 2%" blending a real customer-specific number with a hallucinated or mismatched policy detail is a subtler, agent-specific version of Chapter 8 Topic 3's faithfulness problem, now requiring per-tool-result faithfulness checking rather than single-context checking.
3. **Under-triggering as an indirect hallucination source (direct continuation of Topic 1)**: if the agent should have called `search_knowledge_base` but didn't (Topic 1's under-triggering risk), any subsequent policy-specific claim in the final answer is, by definition, ungrounded — this is a hallucination *caused by a trigger-decision failure*, not a generation-quality failure, meaning the fix belongs in Topic 1's trigger tuning, not in Chapter 8 Topic 4's entailment-checking thresholds.

**How this expands Chapter 8 Topic 4's pipeline for the live agent:**

1. Capture the full tool-use trace for the request (which tools were called, with what arguments, returning what results) — this project's existing `run_agent()` already has this information available via the `messages` list and `verbose` logging pattern.
2. Run Chapter 8 Topic 4's entailment checking on each claim against its *specific* cited tool result — a `validate_fd_reference` result checked differently (exact-value comparison, since it's structured data) than a `search_knowledge_base` chunk (semantic entailment checking, as Chapter 8 built).
3. Additionally check: does the final answer claim any verification action that isn't present in the tool-use trace at all? This is a new, agent-specific check with no Chapter 8 Topic 4 equivalent.

---

### 3. How It Is Implemented in This Project

```python
def check_false_tool_use_claims(final_answer: str, tool_use_trace: list) -> dict:
    """NEW check, specific to the agentic setting: does the answer claim
    a verification action that never actually happened in the tool trace?"""

    tools_actually_called = {t["tool_name"] for t in tool_use_trace}

    # Simple keyword-based detection for illustration -- production version
    # would use a small classifier or LLM-judge call, similar in spirit to
    # Chapter 8 Topic 4's Tier 2, but specifically scoped to detecting
    # process-claims rather than factual-content claims.
    claims_verification = any(
        phrase in final_answer.lower()
        for phrase in ["i've verified", "i checked your", "confirmed with our records"]
    )

    if claims_verification and "validate_fd_reference" not in tools_actually_called:
        return {
            "flagged": True,
            "reason": "Answer claims verification occurred, but validate_fd_reference "
                      "was never called in this request's tool-use trace.",
        }
    return {"flagged": False}


def check_multi_tool_faithfulness(claims: list, tool_results: dict) -> dict:
    """Extends Chapter 8 Topic 4's per-claim checking to route each claim
    to the RIGHT verification method based on which tool it's attributed to."""

    unsupported = []
    for claim in claims:
        source_tool = claim["cited_source_tool"]  # e.g. "validate_fd_reference" or "search_knowledge_base"

        if source_tool == "validate_fd_reference":
            # Exact-match check: does the claim's stated value match the
            # tool's actual returned value? (structured data, not embedding
            # similarity -- a stricter, more direct check than Chapter 8's
            # semantic entailment approach, appropriate for exact database facts)
            db_result = tool_results.get("validate_fd_reference", {})
            if not exact_value_matches(claim["text"], db_result):
                unsupported.append({**claim, "reason": "Value does not match database record"})

        elif source_tool == "search_knowledge_base":
            # Chapter 8 Topic 4's existing two-tier entailment checking
            kb_chunks = tool_results.get("search_knowledge_base", {}).get("chunks", [])
            matching_chunk = next((c for c in kb_chunks if c["source"] == claim["cited_source"]), None)
            if matching_chunk is None:
                unsupported.append({**claim, "reason": "Cited source not in retrieved chunks"})
            # (Tier 1/Tier 2 entailment checking from Chapter 8 Topic 4 would run here)

    return {"all_supported": len(unsupported) == 0, "unsupported": unsupported}


def exact_value_matches(claim_text: str, db_result: dict) -> bool:
    """Illustrative: checks whether a numeric/status value stated in the
    claim actually matches the structured tool result -- simpler and
    stricter than semantic entailment, appropriate for exact database facts."""
    import re
    for key, value in db_result.items():
        if str(value).lower() in claim_text.lower():
            return True
    return False
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **False tool-use claims are a subtle, hard-to-catch failure mode**: they don't involve incorrect facts per se, just an incorrect implicit claim about process — a customer reading "I've verified your account" has no way to know this didn't actually happen, and this specific failure mode erodes trust in a way that's arguably worse than a straightforwardly wrong fact, since it misrepresents the system's own diligence. This requires its own dedicated detection, since Chapter 8 Topic 4's content-focused entailment checking has no mechanism to catch it.
- **Multi-tool faithfulness checking adds real complexity to the verification pipeline**: routing each claim to the appropriate verification method (exact-match for database facts, semantic entailment for retrieved policy content) requires the claim schema itself (Chapter 8 Topic 4's per-claim structure) to be extended with a `cited_source_tool` field, not just a `cited_source` — a schema change rippling back through Chapter 8's infrastructure.
- **Monitoring**: track false-tool-use-claim flag rate as its own dedicated metric, separate from Chapter 8 Topic 4's general faithfulness metrics — a nonzero rate here is a particularly serious signal given the trust implications described above, and should likely have a lower tolerance threshold for triggering human review than a general faithfulness flag.
- **Cost and latency**: the exact-match check for `validate_fd_reference`-attributed claims is essentially free (a simple string/value comparison, no embedding or LLM call needed) — cheaper than Chapter 8 Topic 4's Tier 1 embedding check for the same claim type, since exact database facts don't need semantic similarity reasoning at all. This is a genuine cost optimization specific to the agentic, multi-tool setting: not every claim needs the full two-tier pipeline if its source is structured data rather than retrieved text.
- **Security**: the false-tool-use-claim check doubles as a subtle prompt-injection detector — if a customer email successfully manipulates the model into claiming a verification occurred that didn't (perhaps to make a subsequent, unrelated false claim seem more credible), this check catches the specific symptom even if the injection technique itself wasn't anticipated.
- **Debugging**: when a multi-tool faithfulness check flags a claim, the debugging trace now needs to include which tool the claim was routed to for checking, in addition to Chapter 8 Topic 4's existing per-claim logging — expanding the observability requirements established in Topic 3.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **Should the exact-match check for database-sourced claims be strict (exact string/value match) or fuzzy (allowing paraphrase, e.g. "closed early" matching a status of "Closed (Premature)")?**: a strict check is simpler and catches clear-cut errors reliably, but risks false-flagging legitimate paraphrases of a correct fact — a fuzzy check (perhaps a lightweight semantic similarity check, reusing Chapter 8 Topic 4's Tier 1 mechanism even for database facts) is more forgiving but reintroduces some of the imprecision that made exact-match preferable for structured data in the first place. This project's actual answer likely depends on how much the generation prompt encourages verbatim value reporting versus natural paraphrasing — worth validating against real generated answers before choosing a strictness level.
- **How much should the false-tool-use-claim check rely on keyword matching (cheap, brittle) versus an LLM-judge call (more robust, more expensive)?**: the illustrative code above uses simple keyword detection for cost reasons, but this is exactly the kind of coarse Tier-1-style filter that should escalate to an LLM-judge call (mirroring Chapter 8 Topic 4's tiering) for genuinely ambiguous cases, rather than relying on keyword matching alone for a check this consequential to customer trust.

---

### 6. Alternatives and When to Use Each

- **Treat all claims uniformly with Chapter 8 Topic 4's single entailment pipeline, regardless of source tool**: simpler to implement, but misses the exact-match opportunity for database-sourced claims (unnecessary embedding/LLM cost for facts that could be checked more cheaply and more precisely) and entirely misses the false-tool-use-claim failure mode this topic identifies as agent-specific.
- **Per-source-tool routing with tailored verification methods (this topic's recommendation)**: more implementation complexity, but more accurate, more cost-efficient (cheaper checks for structured facts), and specifically catches the new failure modes unique to a multi-tool agentic system.

---

### 7. Common Mistakes and Production Failures

- Applying Chapter 8 Topic 4's semantic entailment checking uniformly to all claims, including exact database facts, wasting cost on unnecessary embedding/LLM calls where a simple value comparison would suffice and be more precise.
- Not checking for false tool-use claims at all, leaving a subtle but serious trust-eroding failure mode (claiming verification that didn't happen) completely undetected by content-focused faithfulness checks alone.
- Conflating an under-triggering failure (Topic 1 — the agent should have retrieved but didn't) with a generation-layer faithfulness failure (Chapter 8 Topic 4 — the agent retrieved correctly but generated an unfaithful claim from good context) — these require entirely different fixes and should be distinguished during debugging, not treated as the same category of "hallucination."
- Not extending the citation schema to track which specific tool a claim is attributed to, making the multi-tool routing this topic requires impossible to implement cleanly after the fact.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: What new hallucination risk exists in this project's live, multi-tool agent that Chapter 8 Topic 4's original hallucination-detection design didn't need to consider?**
A: False tool-use claims — the model's final answer stating or implying it performed a verification action (like checking a customer's FD record) that never actually happened according to the tool-use trace. Chapter 8 Topic 4 assumed a context already existed and checked whether generated claims matched that context; it had no mechanism to check claims about the model's own process, which only becomes a meaningful risk once the model has real tools it might falsely claim to have used.

**Q: Why does this topic recommend a different verification method for claims sourced from `validate_fd_reference` versus claims sourced from `search_knowledge_base`?**
A: `validate_fd_reference` returns structured, exact data (a status string, a numeric amount) — checking a claim against this can be a direct value comparison, cheaper and more precise than semantic similarity reasoning. `search_knowledge_base` returns retrieved text chunks, where the relationship between a claim and its source is inherently more about meaning than exact value matching, requiring Chapter 8 Topic 4's semantic entailment approach (embedding similarity plus LLM-as-judge). Using the same method for both wastes cost on the exact-match case and may be less precise than a direct value comparison would be.

**Intermediate:**

**Q: A customer's final answer says "your FD is currently Active" but the tool trace shows `validate_fd_reference` was called and returned status "Closed (Premature)". What check catches this, and how would you classify the failure?**
A: The exact-match check on `validate_fd_reference`-attributed claims catches this directly — the claimed value ("Active") doesn't match the actual returned database value ("Closed (Premature)"). This is a faithfulness failure in Chapter 8 Topic 3's terms (the answer doesn't match what was actually retrieved/returned), specifically a generation-layer synthesis error rather than a retrieval or tool-invocation problem, since the correct data was successfully retrieved but misrepresented in the final answer.

**Advanced:**

**Q: Design the full claim-routing and verification pipeline for a single agent run where the model calls both `validate_fd_reference` and `search_knowledge_base`, producing a final answer with claims sourced from both.**
A: Extend the per-claim schema (Chapter 8 Topic 4) with a `cited_source_tool` field alongside the existing `cited_source` field. For each claim in the final structured answer, route based on `cited_source_tool`: claims attributed to `validate_fd_reference` go through a cheap, direct exact-value comparison against that tool's actual returned result for this request; claims attributed to `search_knowledge_base` go through the existing two-tier embedding-then-LLM-judge entailment pipeline against the specific cited chunk. Separately and always, run the false-tool-use-claim check against the full answer text and the complete tool-use trace, regardless of per-claim routing, since this check operates on the answer's implicit process-claims rather than its content-claims. Aggregate all three check results (exact-match failures, entailment failures, false-tool-use-claims) into a single answer-level faithfulness verdict, with any failure blocking customer-facing surfacing and routing to human review, consistent with Chapter 8's established policy for a regulated domain.

**Q: How would you prioritize investigating a spike in flagged false-tool-use-claims versus a spike in Chapter 8 Topic 4's general entailment-failure rate, if both happened simultaneously and you had limited immediate investigation capacity?**
A: False-tool-use-claims likely warrants higher immediate priority — it represents the model actively misrepresenting its own process to the customer, which is a distinct and arguably more corrosive trust violation than a content-accuracy failure, and it may indicate either a prompt-injection success (Section 4's security note) or a systematic prompting issue causing the model to overstate its diligence, either of which could be actively worsening across many concurrent requests. General entailment failures, while serious, are the failure mode Chapter 8's infrastructure was originally built and tuned to catch and route to review — a spike there, while needing investigation, is operating within a more mature, already-monitored detection and response pathway. I'd triage false-tool-use-claims first specifically because it's the newer, less-instrumented failure mode with less established response tooling around it.

**Scenario-based:**

**Q: In production, the false-tool-use-claim check's flag rate is rising, but sampled review shows the flagged answers are actually accurate — the model genuinely did check the customer's record via a tool call that the check's keyword-based detection simply isn't recognizing due to varied phrasing ("I looked into your account," "checking our system shows," etc.). Diagnose and fix.**
A: This is a false-positive problem in the check itself, not a real hallucination increase — the keyword-based detection approach flagged in Section 5 as a cost-conscious but brittle Tier-1-style filter is failing to generalize to the actual variety of phrasing the model uses to describe having performed verification. The fix mirrors Chapter 8 Topic 4's own tiering logic: escalate ambiguous or newly-observed phrasing patterns to an LLM-judge call specifically trained to recognize "does this text claim a verification action occurred" as a semantic question rather than a keyword-matching one, reserving the cheap keyword check only as an initial filter for the clearest, most common phrasings. This is the same lesson Chapter 8 Topic 4 already taught about embedding similarity's limitations as a standalone check — a cheap first-tier filter needs a more robust escalation path for cases it can't reliably classify alone.

---

### 9. Hidden Concepts and Prerequisites

- **This topic is a specific instance of the broader challenge of "agent self-report reliability"** — as agents become more autonomous and multi-step (a trajectory this project continues through Chapters 10-13), the gap between what an agent claims it did and what it actually did becomes an increasingly important, separately-studied verification problem, distinct from content-accuracy verification alone.
- **The exact-match versus semantic-entailment distinction connects back to this project's very first sparse-versus-dense retrieval distinction (Chapter 7 Topics 1-2)** — exact match is appropriate for precise, structured facts (like BM25's strength with exact terms, or `validate_fd_reference`'s database lookups), while semantic checking is appropriate for meaning-based content (like dense retrieval, or `search_knowledge_base`'s chunk-based entailment checking) — the same underlying principle (precision-vs-meaning trade-off) recurring at a different layer of the system.
- **This connects forward to Chapter 15's Evaluating Agents Properly chapter**, which formalizes exactly this project's need for step-level metrics (did the agent call the right tool, not just reach the right final label) rather than only task-level metrics — this topic's false-tool-use-claim check is a concrete, early instance of the step-level verification thinking that chapter will develop into a complete evaluation methodology.

---

### 10. Revision Summary

> Chapter 8 Topic 4's hallucination detection assumed a single, bounded context-and-claim relationship; this topic extends that framework to this project's actual live, multi-tool agent, where two new failure modes emerge specifically from the agentic setting: false tool-use claims (the model claiming a verification action occurred when the tool-use trace shows it didn't) and multi-tool misattribution (blending a real database fact with an ungrounded policy claim in ways that need per-source-tool verification routing). Claims attributed to `validate_fd_reference` should be checked via cheap, precise exact-value comparison against the tool's actual returned data; claims attributed to `search_knowledge_base` continue using Chapter 8 Topic 4's two-tier semantic entailment pipeline. False-tool-use-claims require their own dedicated detection mechanism with no equivalent in the original, single-context hallucination-detection design, and arguably deserve higher-priority investigation given the distinct trust-erosion risk of an agent misrepresenting its own diligence. This topic's per-claim, per-source-tool routing requires extending Chapter 8's citation schema with a `cited_source_tool` field, and connects forward to Chapter 15's broader step-level agent evaluation methodology.

---
