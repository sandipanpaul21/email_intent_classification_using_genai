# Chapter 9: Retrieval — Putting It to Work

## Topic 4: Should Retrieval Ever Touch Customer-Specific Records Directly?

---

### 1. Concept, Intuition, and Why It Exists

- Chapter 6 Topic 9 established the *storage-layer* PII answer: customer records live in a separate Qdrant collection, access-scoped by caller identity, never mixed with policy documents. This topic asks the same question one layer higher — as an **agent-design decision**, not a storage decision: given the agent already has `validate_fd_reference` for exact-match lookups, should `search_knowledge_base`'s open-ended semantic search ever be allowed to reach into customer-specific data at all?
- The distinction matters because storage-layer separation (Chapter 6) only protects against *accidental* leakage through shared collections — it does nothing to stop an agent from being *designed* to route semantic queries toward customer records in the first place. This topic is about the design decision that determines whether that separation is ever actually tested under real query pressure.
- The concrete tension: a customer asking "what's happening with my FD?" is emotionally and functionally similar to "what happens to FDs generally at maturity?" — one needs an exact, customer-specific answer (`validate_fd_reference`), the other needs general policy knowledge (`search_knowledge_base`). An agent that blurs this distinction, or worse, that has `search_knowledge_base` capable of semantically matching against customer records "just in case," reintroduces exactly the cross-customer leakage risk Chapter 6 Topic 9 worked to prevent — at the agent-design layer, not the storage layer.

---

### 2. Internal Working — Step by Step

**The three architectural options, worked through explicitly:**

1. **Hard separation (this project's existing, correct design)**: `search_knowledge_base` only ever searches the policy/FAQ/SOP knowledge base collection (Chapter 6's separated architecture). `validate_fd_reference` only ever does exact-match lookups against `fd_master_database.csv` / the customer-records collection. There is no code path, no matter what the model decides, where a semantic search query can retrieve a customer record — this is enforced architecturally (the tool literally cannot see that collection), not just by prompting convention.
2. **Soft separation via prompting alone (a weaker, discouraged alternative)**: both collections technically reachable by a general-purpose search tool, with the system prompt instructing the model to use `validate_fd_reference` for customer-specific queries and `search_knowledge_base` for general ones. This relies entirely on the model's judgment holding under every possible phrasing and every possible adversarial or confused input — the same category of fragility Chapter 3's prompt-injection defense already teaches you not to rely on alone for security-relevant behavior.
3. **Unified search across both (actively wrong for this domain)**: one tool, one collection, semantic search spanning both policy content and customer records, relying purely on relevance ranking to "usually" surface the right kind of result. This is precisely the architecture Chapter 6 Topic 9 demonstrated concretely fails — a query about a customer's own FD can semantically match a *different* customer's record if their profiles are similar enough (same branch, similar tenure, similar amount), a measured, reproduced risk, not a hypothetical one.

**Why hard separation must be enforced at the tool/architecture level, not the prompt level:**

- A tool that has no code path to a given collection cannot leak from it, regardless of what the model is told, what the customer's email says, or how a prompt injection attempt is phrased — this is defense-in-depth, not reliance on instruction-following alone, and is consistent with Chapter 3's broader principle that scope should be enforced by what tools *exist*, not just by what the system prompt says not to do.

---

### 3. How It Is Implemented in This Project

```python
# search_knowledge_base's implementation (Topic 3) only ever connects to
# the POLICY collection -- it has NO client connection, NO code path, and
# NO awareness of the customer-records collection at all.

POLICY_COLLECTION_NAME = "fd_knowledge_base"       # FAQ, Policy, SOP, Product docs
CUSTOMER_COLLECTION_NAME = "fd_customer_records"    # Chapter 6 Topic 9's separated collection

def search_knowledge_base(query: str, top_k: int = 5) -> dict:
    """This function's Qdrant client call is HARD-WIRED to
    POLICY_COLLECTION_NAME. There is no parameter, no code path, and no
    way for a caller (including the model, via any query phrasing) to
    redirect this search toward CUSTOMER_COLLECTION_NAME. Architectural
    separation, not prompt-level convention."""
    results = client.query_points(
        collection_name=POLICY_COLLECTION_NAME,  # HARD-CODED, not a parameter
        query=embed_query(query),
        limit=top_k,
    ).points
    ...


def validate_fd_reference(reference_number: str) -> dict:
    """This function is the ONLY code path that ever touches customer
    records, and it does so via EXACT match only -- never semantic
    search -- exactly as established in Chapter 3 and reinforced by
    Chapter 6 Topic 9's PII access-scoping design."""
    record = get_fd_record(reference_number)  # exact CSV/DB lookup, not embedding search
    if record is None:
        return {"found": False}
    return {"found": True, "status": record["status"], "fd_amount_inr": record["fd_amount_inr"]}


# The TOOLS list makes the separation explicit and auditable at a glance:
TOOLS = [
    VALIDATE_FD_REFERENCE_TOOL,     # -> customer records, EXACT MATCH ONLY
    SEARCH_KNOWLEDGE_BASE_TOOL,     # -> policy knowledge, SEMANTIC SEARCH, NEVER customer data
    FINALIZE_CLASSIFICATION_TOOL,
    REFUSE_OUT_OF_SCOPE_TOOL,
]
```

- The system prompt reinforces this (soft layer, in addition to the hard architectural separation, not instead of it): "Never use `search_knowledge_base` to look up information about a specific customer's account — always use `validate_fd_reference` for that, which requires an exact reference number."

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **The "what if a policy document legitimately quotes an example customer scenario" edge case**: FAQ or SOP documents sometimes use illustrative examples ("For example, if a customer's FD of ₹1,00,000 matures...") — these are fictional/generic illustrations, not real customer data, and must be clearly distinguishable during Chapter 4's ingestion process (a documentation/content-authoring discipline, not a retrieval-time fix) to avoid a false-positive concern that policy content itself contains real customer information.
- **Monitoring for architectural drift**: as this project's agent grows more sophisticated across later chapters (multi-tool agents in Chapter 10, LangGraph orchestration in Chapter 12), there's a real risk that a future engineer adds a new, more "flexible" search tool that inadvertently spans both collections for convenience — this requires an explicit architectural review checkpoint (a specific line item in any code review touching retrieval tools) rather than assuming the original separation will be preserved by default as the system evolves.
- **Debugging a suspected leak**: if a generated answer appears to reference customer-specific details it shouldn't have access to, the first diagnostic step is checking which tool was actually called and which collection it queried — given the hard separation design, this should be structurally impossible, so any occurrence is a serious, high-priority bug requiring immediate investigation into how the architectural boundary was breached (a code change, a misconfigured collection name, or a genuinely novel exploit).
- **Cost and latency**: hard separation has no negative cost or latency implications versus a unified design — if anything, `search_knowledge_base`'s smaller, policy-only collection is faster to search than a hypothetical combined collection would be at scale.
- **Security**: this is fundamentally a security topic — the entire point is eliminating an entire class of PII leakage risk by architectural design rather than by hoping prompting and monitoring catch every case after the fact. This is the practical embodiment of defense-in-depth: Chapter 6 Topic 9's storage-layer separation plus this topic's tool-level separation plus Chapter 3's prompt-level reinforcement are three independent layers, any one of which failing shouldn't be catastrophic if the others hold.
- **Deployment**: any infrastructure change (e.g. migrating to a different vector database, restructuring collections) must explicitly preserve this separation — a migration checklist item, not an assumption that carries over automatically.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **Is there ever a legitimate use case for semantic search over customer records at all?**: yes, potentially — an internal, admin-facing tool for support staff to find "customers with similar complaint patterns" or "customers with FDs above ₹X in branch Y" is a legitimate semantic-search-over-customer-data use case, but it is a *fundamentally different agent* with different access controls, different authentication requirements, and different audit logging — not a capability that should ever be exposed through the customer-facing classification/response agent this project has built. Conflating "semantic search over customer data is sometimes useful" with "therefore the customer-facing agent's search tool should support it" is the exact category error this topic exists to prevent.
- **What if a genuinely useful feature requires blending policy and customer context, e.g. "personalized" policy explanations referencing the customer's own FD terms?**: this is achievable *safely* by having the agent call both tools separately — `validate_fd_reference` for the customer's specific facts (exact match, already access-scoped) and `search_knowledge_base` for the general policy explanation — then synthesizing both in its final answer. This preserves the architectural separation while still delivering a personalized-feeling response; the separation constrains *how* data is retrieved, not what the final answer can reference.

---

### 6. Alternatives and When to Use Each

- **Hard architectural separation (this project's design, strongly recommended)**: the correct default for any customer-facing agent in a regulated financial domain — eliminates an entire risk category by construction rather than by policy or monitoring alone.
- **Soft separation via prompting only**: not recommended as the sole safeguard for a regulated domain — acceptable only as an *additional* layer on top of hard architectural separation, never as a substitute for it.
- **Unified search with post-hoc filtering**: actively discouraged — this is architecturally identical to the "post-filter" anti-pattern already demonstrated as broken in Chapter 7 Topic 8, now applied to a PII context where the stakes of a filtering failure are much higher than a mere relevance-quality problem.
- **A separate, access-controlled internal admin tool for legitimate semantic search over customer data**: appropriate for internal support-staff use cases, but must be a genuinely separate system with its own authentication and audit trail, never a capability folded into the customer-facing agent's toolset.

---

### 7. Common Mistakes and Production Failures

- Building a single, general-purpose "search everything" tool for convenience during early development, intending to add access restrictions "later" — a common path to this exact vulnerability, since "later" restrictions are easy to forget or implement incompletely once the unified tool is already deeply integrated.
- Relying on the system prompt alone to prevent `search_knowledge_base` from being used for customer-specific queries, without the hard architectural separation (different collection, different function, no shared code path) backing it up.
- Not treating "does this new tool touch a customer-data collection" as an explicit, mandatory review question whenever new retrieval capabilities are added to the agent in later chapters.
- Assuming illustrative examples in policy documentation are automatically safe without a content-authoring review process confirming they don't inadvertently reference or resemble real customer data.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: Why shouldn't `search_knowledge_base` ever be allowed to search customer records, even with careful prompting?**
A: Prompting is instruction-following, which is probabilistic, not a guaranteed architectural boundary — the same reasoning Chapter 8 Topic 4 already established for why hallucination detection can't rely on prompting alone applies here even more critically, since the failure mode is a genuine PII leak, not just a quality issue. Hard architectural separation — the tool has no code path to the customer-records collection at all — eliminates the risk regardless of how the model is prompted or what the customer's email contains.

**Q: What's the difference between this topic's concern and Chapter 6 Topic 9's PII access-scoping?**
A: Chapter 6 Topic 9 addresses the storage layer — ensuring customer records are in a separate, access-scoped collection so a search against the policy collection can never return them. This topic addresses the agent-design layer — ensuring the agent's tools themselves are architected so that no tool intended for general policy search ever has a code path to the customer-records collection in the first place, regardless of how well the storage layer is separated. Both layers are needed; this topic's failure mode (a tool built to span both collections) would bypass even a perfectly-separated storage layer.

**Intermediate:**

**Q: A product manager asks for a feature where the agent gives "personalized" policy explanations referencing the customer's specific FD terms. How would you implement this without violating this topic's separation principle?**
A: The agent calls both existing tools separately and combines their results in its own final synthesis — `validate_fd_reference` for the customer's specific, exact-match facts (already access-scoped per Chapter 6 Topic 9), and `search_knowledge_base` for the general policy content. Neither tool's internal implementation changes; the personalization happens in how the model combines two independently-retrieved, appropriately-scoped pieces of information in its answer, not by building a new tool that searches across both data types together.

**Q: How would you audit whether this separation is actually holding in production, beyond just reviewing the code once at build time?**
A: Periodically (and as part of any code change touching retrieval tools) verify that `search_knowledge_base`'s Qdrant client call is still hard-wired to only the policy collection name, with no parameter or code path allowing redirection. Additionally, monitor generated answers for any appearance of customer-specific details (names, account numbers, specific amounts) in responses that did NOT involve a `validate_fd_reference` call in their tool-use trace — any such occurrence, given the architectural design, should be structurally impossible and therefore a critical, immediately-investigated incident if it ever appears.

**Advanced:**

**Q: As this project adds more sophisticated agent capabilities in later chapters (memory in Chapter 10, multi-tool orchestration in Chapter 12), what specific risks does this topic's separation principle need to guard against?**
A: Any new tool or memory mechanism that could plausibly aggregate or cross-reference information across multiple customers needs the same architectural scrutiny applied here — for example, a "repeat sender" memory feature (flagged in this project's own EDA, 14% repeat senders) that stores facts about past interactions must itself be scoped per-customer, never allowing one customer's interaction history to semantically surface in another customer's session. The general principle: every new capability that touches customer data needs an explicit review answering "can this, even indirectly, allow one customer's information to reach a different customer's interaction" — a checklist item that should be part of this project's standard development process from Chapter 10 onward, not something re-derived from scratch each time.

**Q: A teammate argues that since Chapter 6's Qdrant-level payload filtering already prevents cross-customer leakage even in a unified collection, this topic's tool-level separation is redundant defense that adds unnecessary complexity. How do you respond?**
A: Payload filtering is application-layer logic — Chapter 6 Topic 9 itself already established that a missing or inconsistently-applied filter in any single code path (for example, if a hybrid retrieval implementation filters the dense leg but forgets to filter BM25, exactly as demonstrated in Chapter 7 Topic 8's Module 4) reopens the leak risk. Tool-level architectural separation is a second, independent layer that holds even if the filtering logic has a bug — this is defense-in-depth, not redundancy. A single point of failure (relying on filtering alone) is a meaningfully weaker posture for a regulated financial domain than two independent layers, each of which would need to fail simultaneously for a leak to occur.

**Scenario-based:**

**Q: During a security review, an auditor asks you to prove that customer records can never be reached by `search_knowledge_base`, no matter what query is passed to it. How do you demonstrate this?**
A: Point to the function's implementation — the Qdrant collection name is a hard-coded constant (`POLICY_COLLECTION_NAME`), not a parameter derived from the query or any other input, so no query text, however crafted, can influence which collection is searched. This is a static code-level guarantee, verifiable by code review alone, independent of runtime behavior or model judgment. Additionally, demonstrate that the customer-records collection (`CUSTOMER_COLLECTION_NAME`) is only ever referenced inside `validate_fd_reference`'s exact-match lookup path, with no shared code, shared client configuration, or shared abstraction layer that could inadvertently expose it to the semantic search tool. This combination of static code guarantees plus architectural separation is a stronger, more auditable proof than any amount of runtime testing of query phrasings, since runtime testing can only ever sample the space of possible inputs, while the code-level guarantee holds for all inputs by construction.

---

### 9. Hidden Concepts and Prerequisites

- **This is a specific application of the principle of least privilege**, a foundational security concept — each tool should have access to only the minimum data it genuinely needs to perform its function, and no more; `search_knowledge_base` needs policy knowledge, not customer records, so it should have no code path to the latter, exactly mirroring how a database user account for a reporting tool should have read-only access to only the tables it reports on, not write access to the entire database.
- **The distinction between "the model was instructed not to" and "the system was built so it cannot" recurs throughout this entire project** — Chapter 3's prompt-injection defense, Chapter 6 Topic 9's PII filtering, Chapter 8 Topic 4's hallucination detection, and this topic's tool separation are all instances of the same underlying lesson: instruction-following is a useful first layer, but production-grade safety for a regulated domain requires structural guarantees that don't depend on the model's compliance being perfect.
- **This connects forward to Chapter 20's Security & Responsible AI chapter**, which will formalize data residency, bias/fairness, and audit-trail requirements at a whole-system level — this topic's tool-level separation principle is a concrete, already-implemented instance of the broader security discipline that chapter will cover comprehensively.

---

### 10. Revision Summary

> Semantic search should never be architecturally capable of reaching customer-specific records, regardless of how carefully the system prompt is worded — this is an agent-design decision layered on top of Chapter 6 Topic 9's storage-level PII separation, not a replacement for it. `search_knowledge_base`'s Qdrant collection name must be a hard-coded constant pointing only at the policy/FAQ/SOP collection, with no code path, parameter, or query phrasing capable of redirecting it toward the customer-records collection — `validate_fd_reference`'s exact-match lookup remains the sole, already access-scoped path to customer data. This is defense-in-depth: prompting (soft), storage-layer filtering (Chapter 6), and tool-level architectural separation (this topic) are three independent layers, each of which should hold even if the others fail. "Personalized" features that seem to require blending customer and policy data should be implemented by calling both existing, properly-scoped tools separately and synthesizing their results in the model's final answer — never by building a new tool that searches across both data types in one operation. Every new tool or capability added in later chapters must be reviewed against this same principle before being integrated.

---
