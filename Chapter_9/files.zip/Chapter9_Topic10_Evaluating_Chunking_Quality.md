# Chapter 9: Retrieval — Putting It to Work

## Topic 10: Evaluating Chunking Quality — Recall@K, MRR, Hit Rate, Context Precision

---

### 1. Concept, Intuition, and Why It Exists

- Chapter 5 built several chunking strategies (fixed-size, sentence-aware, semantic, structure-aware) and Chapter 5 Topic 4 compared them conceptually. But no chapter has yet *measured* which chunking strategy actually produces better retrieval outcomes for this project's specific corpus — chunking quality has been discussed qualitatively (does it split mid-sentence, does it preserve semantic coherence) but never quantitatively tied to retrieval performance.
- This topic closes that gap by applying Chapter 7 Topic 9's evaluation methodology (Recall@K, MRR, NDCG@K) specifically as a *chunking* evaluation tool, not just a retrieval-algorithm evaluation tool — holding the retrieval algorithm constant (Chapter 7's best hybrid+rerank+MMR pipeline) while varying only the chunking strategy, isolating chunking's specific contribution to overall system quality.
- Additionally, this topic introduces **Hit Rate** and **Context Precision** — two metrics specifically suited to chunking evaluation that weren't emphasized in Chapter 7 Topic 9's general retrieval evaluation framework, because they answer chunking-specific questions Recall@K and NDCG@K don't directly capture.

---

### 2. Internal Working — Step by Step

**Hit Rate — the simplest, most chunking-relevant metric:**

```text
Hit Rate = (number of queries where AT LEAST ONE correct chunk appears in top-K) / (total number of queries)
```

- Distinct from Recall@K (which measures the *fraction* of all relevant chunks found) — Hit Rate is binary per query: did retrieval find *any* useful chunk at all, yes or no. This is specifically useful for chunking evaluation because a bad chunking strategy (one that splits the correct answer across multiple incoherent fragments, none of which individually contains enough information) can cause Hit Rate to drop even when Recall@K technically finds "some" relevant chunks — the chunks found may be individually useless fragments.

**Context Precision — measuring whether retrieved chunks are usefully complete, not just topically relevant:**

```text
Context Precision (for a single query) = (number of retrieved chunks that are BOTH relevant AND
                                            sufficiently self-contained/complete to be useful) /
                                           (total number of retrieved chunks)
```

- This requires a *graded* judgment beyond simple relevance — a chunk can be topically relevant (it's about the right subject) but chunked so awkwardly (cut off mid-explanation, missing a critical qualifying clause) that it's not actually *usable* for answering the question, even after Chapter 9 Topic 9's contextual retrieval enrichment. Context Precision specifically penalizes this "relevant but unusable" case, which pure topical-relevance metrics (Recall@K) cannot detect.

**Step-by-step evaluation process — isolating chunking's specific contribution:**

1. Take the same source documents (this project's 4 knowledge base files).
2. Produce *multiple versions* of the chunked knowledge base, each using a different chunking strategy from Chapter 5 (fixed-size, sentence-aware with overlap, semantic, structure-aware) — everything else (embedding model, BM25 config, hybrid RRF, reranking, MMR) held identical across all versions.
3. For each chunked version, run the *same* labeled evaluation set (Chapter 7 Topic 9's queries) through the *identical* retrieval pipeline.
4. Compute Hit Rate, Recall@K, MRR, NDCG@K, and Context Precision for each chunking strategy's resulting knowledge base.
5. Compare directly — since only the chunking strategy varies across the comparison, any measured difference in these metrics is attributable specifically to chunking quality, not retrieval algorithm differences.

---

### 3. How It Is Implemented in This Project

```python
def hit_rate(retrieved_ids: list, relevant_ids: set, k: int) -> int:
    """Returns 1 if AT LEAST ONE relevant chunk is in top-K, else 0.
    Distinct from recall_at_k (Chapter 7 Topic 9), which measures the
    FRACTION of relevant chunks found -- Hit Rate is binary per query."""
    top_k = set(retrieved_ids[:k])
    return 1 if len(top_k & relevant_ids) > 0 else 0


def mean_hit_rate(all_queries_results: list) -> float:
    """Averages hit_rate across the full evaluation set."""
    return sum(all_queries_results) / len(all_queries_results)


def context_precision(retrieved_chunks: list, usability_labels: dict) -> float:
    """usability_labels: dict mapping chunk_id -> True/False, indicating
    whether a HUMAN REVIEWER judged this chunk to be both relevant AND
    sufficiently self-contained/complete to actually answer with.
    This requires MANUAL labeling beyond simple relevance -- a genuinely
    graded judgment about chunk USABILITY, not just topical match."""
    if not retrieved_chunks:
        return 0.0
    usable_count = sum(1 for c in retrieved_chunks if usability_labels.get(c["id"], False))
    return usable_count / len(retrieved_chunks)


def evaluate_chunking_strategy(strategy_name: str, chunked_knowledge_base: list,
                                eval_set: list, retrieval_pipeline_fn, k: int = 5) -> dict:
    """Runs the FULL evaluation across one chunking strategy's resulting
    knowledge base, using the retrieval pipeline UNCHANGED across all
    strategies being compared -- isolating chunking's specific contribution."""

    hit_rates, recalls, rrs, ndcgs = [], [], [], []

    for entry in eval_set:
        query = entry["query"]
        relevant_ids = {doc_id for doc_id, grade in entry["relevance"].items() if grade > 0}

        retrieved = retrieval_pipeline_fn(query, chunked_knowledge_base, top_k=10)
        retrieved_ids = [r["id"] for r in retrieved]

        hit_rates.append(hit_rate(retrieved_ids, relevant_ids, k))
        recalls.append(recall_at_k(retrieved_ids, relevant_ids, k))          # Chapter 7 Topic 9
        rrs.append(reciprocal_rank(retrieved_ids, relevant_ids))              # Chapter 7 Topic 9
        ndcgs.append(ndcg_at_k(retrieved_ids, entry["relevance"], k))         # Chapter 7 Topic 9

    return {
        "strategy": strategy_name,
        "hit_rate": mean_hit_rate(hit_rates),
        "recall_at_k": sum(recalls) / len(recalls),
        "mrr": sum(rrs) / len(rrs),
        "ndcg_at_k": sum(ndcgs) / len(ndcgs),
    }


# Comparison across Chapter 5's chunking strategies, same eval set, same retrieval pipeline
CHUNKING_STRATEGIES_TO_COMPARE = {
    "fixed_size_no_overlap": chunk_fixed_size(documents, chunk_size=200, overlap=0),
    "sentence_aware_with_overlap": chunk_text(documents, chunk_size=200, overlap=50),  # Chapter 5's actual chunker
    "semantic_chunking": chunk_semantic(documents),
    "structure_aware": chunk_by_markdown_headers(documents),
}

results = [
    evaluate_chunking_strategy(name, kb, EVAL_SET, hybrid_rerank_mmr_pipeline)
    for name, kb in CHUNKING_STRATEGIES_TO_COMPARE.items()
]
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **Context Precision requires manual labeling — the same labeling bottleneck Chapter 7 Topic 9 already flagged, now applied at a finer grain**: judging whether a chunk is not just relevant but *usably complete* requires a human reviewer reading the actual chunk text, a more time-intensive labeling task than binary relevance judgment — this cost should be budgeted explicitly when planning a chunking-strategy evaluation, not treated as a quick, automatable step.
- **Re-embedding and re-indexing for every chunking strategy variant being compared is a real, non-trivial cost**: unlike comparing BM25 parameter values (Chapter 7 Topic 1, cheap to re-run), comparing chunking strategies means re-running the entire ingestion pipeline (Chapter 4/5) and re-embedding (Chapter 6) for each variant — at this project's 17-page scale this is fast and cheap, but the evaluation methodology itself should be designed with this cost in mind if the knowledge base grows substantially.
- **Confounding factors between chunking strategies**: different chunking strategies naturally produce different numbers of total chunks and different average chunk lengths — a fair comparison must account for this (e.g. reporting average chunk count and length alongside the quality metrics) rather than treating any quality difference as purely attributable to the "conceptual approach" of the strategy without acknowledging these structural differences also plausibly contribute.
- **Monitoring in production**: once a chunking strategy is chosen based on this evaluation, ongoing monitoring should track whether Hit Rate and Context Precision remain stable as new documents are added to the knowledge base over time (Chapter 9 Topic 8's ongoing product-launch scenario) — a strategy that worked well for the original 17-page corpus might behave differently as document types and structures diversify.
- **Interaction with Chapter 9 Topic 9's Contextual Retrieval**: this evaluation should ideally be run both with and without contextual retrieval applied, since contextualization may meaningfully change which chunking strategy performs best — a strategy that previously scored poorly due to ambiguous, context-dependent chunks might improve substantially once contextual retrieval's disambiguating prefixes are added, changing the relative ranking of strategies.
- **Security**: no direct security implications specific to this evaluation methodology.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **How much labeling investment is justified for Context Precision specifically, given it's the most labor-intensive of these metrics**: for this project's current scale, a smaller, carefully-chosen subset of evaluation queries with full Context Precision labeling may be more practical than attempting Context Precision judgments across the entire evaluation set — reserving the cheaper Hit Rate, Recall@K, MRR, NDCG@K for the full evaluation set, and using Context Precision on a representative sample specifically to validate or challenge conclusions the cheaper metrics suggest.
- **Should chunking strategy evaluation be a one-time decision or periodically re-run?**: given Chapter 9 Topic 9's connection (contextual retrieval potentially changing relative strategy performance) and the ongoing knowledge base growth scenario (Topic 8), this evaluation is not a true one-time decision — it should be re-run whenever a major pipeline change (adopting contextual retrieval, a significant knowledge base expansion, an embedding model migration per Chapter 6 Topic 8) is introduced, following the same "measure before and after any significant change" discipline established throughout this project.

---

### 6. Alternatives and When to Use Each

- **Qualitative-only chunking evaluation (Chapter 5 Topic 4's original approach)**: appropriate for initial strategy selection during early development when a full evaluation set doesn't yet exist — a reasonable starting point, but insufficient once the evaluation infrastructure from Chapter 7 Topic 9 exists and can be applied more rigorously.
- **Full quantitative evaluation with Hit Rate, Recall@K, MRR, NDCG@K, and Context Precision (this topic's approach)**: the correct methodology once labeled evaluation data exists — provides genuine, comparable, defensible evidence for a chunking strategy decision.
- **Downstream generation-quality comparison instead of/alongside retrieval-metric comparison**: rather than (or in addition to) measuring retrieval metrics directly, comparing final generated-answer quality (Chapter 8 Topic 3's faithfulness/relevance framework) across chunking strategies tests the full pipeline's end-to-end behavior — more expensive to run (requires full generation, not just retrieval) but closer to what ultimately matters for the customer experience; worth doing as a confirming check once retrieval-metric-based evaluation has narrowed down to a leading candidate strategy.

---

### 7. Common Mistakes and Production Failures

- Choosing a chunking strategy based purely on Chapter 5's qualitative discussion (does it split mid-sentence, is it conceptually appealing) without ever measuring its actual effect on retrieval quality via this topic's methodology.
- Comparing chunking strategies without holding the retrieval pipeline constant, making it impossible to isolate whether an observed quality difference comes from chunking or from an inadvertent difference in the retrieval configuration used for each variant.
- Treating Context Precision's labeling cost as a reason to skip it entirely, missing the specific "relevant but unusable" failure mode that Recall@K and Hit Rate cannot detect on their own.
- Not accounting for differing chunk counts/lengths across strategies when interpreting quality differences, risking incorrect conclusions about which conceptual chunking approach is actually superior versus which happened to produce more favorable chunk granularity for this specific evaluation set.
- Treating a chunking strategy decision as permanent, without re-evaluating after significant pipeline changes like adopting Contextual Retrieval (Topic 9) or substantial knowledge base growth (Topic 8).

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: Why is Hit Rate a useful metric specifically for evaluating chunking strategies, distinct from Recall@K?**
A: Recall@K measures what fraction of all relevant chunks were found — it can register a moderate score even if the chunks found are individually incomplete fragments. Hit Rate asks a simpler, binary question per query: was at least one useful chunk found at all? This is specifically sensitive to a chunking failure mode where poor chunking splits a coherent answer into fragments so incomplete that none of them, even if topically "relevant," genuinely helps answer the question — a failure Recall@K alone might not clearly surface.

**Q: What does Context Precision measure that neither Recall@K nor Hit Rate captures?**
A: Context Precision measures whether retrieved chunks are not just topically relevant but actually usable — sufficiently self-contained and complete to support answering the question. A chunk can be correctly identified as relevant (satisfying Recall@K and Hit Rate) while still being chunked so awkwardly that it's missing a critical qualifying detail, making it relevant-but-unusable — Context Precision specifically penalizes this case, which the other metrics cannot detect since they only judge topical relevance, not usability.

**Intermediate:**

**Q: How would you design a fair comparison between two chunking strategies that produce very different average chunk counts and lengths from the same source documents?**
A: Hold everything except the chunking strategy constant — same embedding model, same BM25 configuration, same hybrid RRF weighting, same reranking model, same MMR settings — and run the identical labeled evaluation set through each resulting knowledge base. Report the chunk count and average chunk length alongside the quality metrics for each strategy, so any observed quality difference can be discussed with awareness of these structural differences, rather than attributing a difference purely to the strategy's "conceptual approach" without acknowledging that granularity differences are also a contributing factor worth understanding.

**Q: Why should this project's chunking strategy evaluation be re-run after adopting Contextual Retrieval (Topic 9), rather than treated as a separate, independent decision?**
A: Contextual Retrieval changes what actually gets embedded and indexed — a chunking strategy that previously scored poorly specifically because its resulting chunks were too context-dependent and ambiguous in isolation might perform substantially better once Contextual Retrieval's disambiguating prefix is added, since the root cause of that strategy's weakness may be directly addressed by the new technique. The two decisions interact, so evaluating them independently and assuming the conclusions compose additively risks missing this interaction effect.

**Advanced:**

**Q: Design a complete chunking-strategy evaluation plan for this project, including how you'd handle the labeling cost trade-offs discussed in this topic.**
A: Use the full labeled evaluation set (extended from Chapter 7 Topic 9, ideally already covering the Hinglish-heavy, exact-reference, and general-policy query patterns established throughout this project) to compute Hit Rate, Recall@K, MRR, and NDCG@K across all candidate chunking strategies (fixed-size, sentence-aware, semantic, structure-aware) with the retrieval pipeline held constant. Then select a smaller, representative subset of queries — prioritizing ones where the cheaper metrics show close or ambiguous results between the top two candidate strategies — and invest the more labor-intensive Context Precision labeling specifically on that subset, using it as a tie-breaking or confirming signal rather than attempting full-set Context Precision labeling for every strategy. Finally, for whichever strategy the retrieval metrics favor, run a smaller confirming check using Chapter 8 Topic 3's end-to-end generation-quality framework (faithfulness, relevance) on a sample of full agent responses, to validate that the retrieval-metric-based winner also translates into better final answer quality, not just better intermediate retrieval scores.

**Q: A colleague argues that since this project's structure-aware chunking (Markdown header splitting, from Chapter 5) conceptually seems like the most sophisticated approach, it should be adopted without further evaluation. How do you respond?**
A: Conceptual sophistication doesn't guarantee superior measured performance for a specific corpus and query distribution — a strategy's fit depends on how well the source documents' actual structure aligns with what the strategy assumes (structure-aware chunking is only as good as the source documents' heading structure is genuinely present, consistent, and semantically meaningful). Given this project already has the evaluation infrastructure (Chapter 7 Topic 9) needed to test this directly and cheaply at the current 17-page scale, adopting a chunking strategy based on conceptual appeal alone — when a rigorous, low-cost measurement is readily available — repeats the exact "picked by intuition, not evidence" mistake this project has consistently avoided for every other tunable parameter (BM25's k1/b, RRF's k, MMR's lambda). I'd run the comparison before committing, even if structure-aware chunking seems like the intuitively favored choice.

**Scenario-based:**

**Q: Your chunking-strategy evaluation shows sentence-aware chunking with overlap has the best Recall@K and NDCG@K, but structure-aware chunking has meaningfully better Context Precision on the labeled subset. How do you decide which to adopt?**
A: This is a genuine trade-off requiring understanding *why* each strategy wins on its respective metric — Recall@K/NDCG@K favor whichever strategy makes it easier for the ranking algorithm to surface relevant content anywhere in the top-K, while Context Precision favors whichever strategy produces more genuinely usable, complete chunks among what's retrieved. If structure-aware chunking's advantage is that its chunks, when retrieved, more reliably contain complete, self-sufficient answers (fewer cases of "relevant but you need the neighboring chunk too to actually answer"), this matters directly for the generation layer (Chapter 8's Stuff pattern, Topic 5, works better with fewer, more complete chunks than more, more fragmentary ones). I would weight Context Precision more heavily for a final decision specifically because it more directly predicts downstream generation quality (Chapter 8 Topic 3's faithfulness/relevance), while Recall@K/NDCG@K primarily predict whether retrieval finds the right general area — but I'd confirm this reasoning with the end-to-end generation-quality check (the previous answer's final validation step) rather than deciding on retrieval metrics alone, since that's the metric that most directly reflects what customers will actually experience.

---

### 9. Hidden Concepts and Prerequisites

- **Context Precision is one of RAGAS's formally defined metrics** (forward reference to Chapter 14) — this project's hand-built version here is the intuitive, from-scratch precursor to adopting RAGAS's standardized implementation later, exactly mirroring how Chapter 8 Topic 4's hand-built two-tier hallucination detection foreshadowed RAGAS's Faithfulness metric.
- **The chunking-evaluation methodology here is a specific instance of "ablation studies," a general machine learning evaluation technique** — systematically varying one component (chunking strategy) while holding everything else constant to isolate that component's specific contribution to overall system performance; recognizing this as a named, general methodology (not an ad hoc comparison technique) strengthens how this evaluation approach transfers to evaluating other pipeline components in the future (embedding models, reranking models, etc.).
- **This topic connects directly to Chapter 5's original chunking discussion and closes a loop left open since then** — Chapter 5 Topic 4 compared strategies qualitatively and explicitly deferred quantitative validation; this topic is where that deferred validation actually happens, once the evaluation infrastructure (Chapter 7 Topic 9) exists to support it — a good example of how this project's chapters build on each other progressively rather than each being fully self-contained.

---

### 10. Revision Summary

> This topic applies Chapter 7 Topic 9's evaluation methodology specifically to Chapter 5's chunking strategies, closing a validation gap left open since Chapter 5 Topic 4's purely qualitative comparison. Hit Rate (did retrieval find at least one useful chunk, binary per query) and Context Precision (are retrieved chunks not just relevant but genuinely usable/complete) supplement Recall@K, MRR, and NDCG@K specifically because they detect chunking-specific failure modes — fragmented, incomplete chunks — that pure topical-relevance metrics can miss. A fair comparison requires holding the entire retrieval pipeline (embedding model, BM25, hybrid RRF, reranking, MMR) constant while varying only the chunking strategy, and accounting for differing chunk counts/lengths across strategies when interpreting results. Context Precision's manual labeling cost is real and should be budgeted for a representative subset rather than the full evaluation set. This evaluation is not a one-time decision — it should be re-run after adopting Contextual Retrieval (Topic 9, since contextualization can change which chunking strategy performs best) and after significant knowledge base growth (Topic 8's ongoing product-launch scenario), following the same evidence-before-and-after-change discipline established throughout this project's retrieval work.

---
