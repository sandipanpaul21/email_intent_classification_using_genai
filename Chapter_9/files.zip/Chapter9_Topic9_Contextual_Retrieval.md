# Chapter 9: Retrieval — Putting It to Work

## Topic 9: Contextual Retrieval — Anthropic's Chunk-Context-Prepending Technique

---

### 1. Concept, Intuition, and Why It Exists

- Chapter 5's chunking established the fundamental tension: chunks must be small enough for focused, precise embeddings, but small chunks can lose the surrounding context that gives them full meaning — a chunk saying "This exemption applies only during the first 90 days" is ambiguous in isolation: exemption from *what*? Applying to *which* product? The answer lives in a neighboring chunk or the document's opening paragraph, not in this chunk itself.
- **Contextual Retrieval** (Anthropic's own published technique) solves this directly: before embedding each chunk, prepend a short, LLM-generated summary of what the chunk is about *in the context of its surrounding document* — so the chunk that gets embedded and indexed isn't just "This exemption applies only during the first 90 days" but something like "This chunk is from the Smart Saver FD policy document, discussing the premature withdrawal penalty exemption period. This exemption applies only during the first 90 days." The embedding now carries the disambiguating context that was previously only available by reading neighboring chunks.
- Why this matters specifically for this project: the 17-page (now potentially growing, per Chapter 9 Topic 8's ongoing product-launch scenario) knowledge base has genuine cross-references between policy, FAQ, and SOP documents — the nominee exception example used throughout Chapter 7 is exactly this kind of context-dependent chunk, where understanding "the exception" requires knowing what general rule it's an exception *to*.

---

### 2. Internal Working — Step by Step

1. **For each chunk produced by Chapter 5's chunking pipeline**, retrieve the *full original document* it came from (not just neighboring chunks — Anthropic's technique specifically uses the whole document for context generation, since a short document-level summary is cheap and captures the necessary framing better than an arbitrary window of neighboring text).
2. **Generate a short (1-2 sentence) contextualizing summary** via an LLM call: "Here is a document: [full document]. Here is a chunk from this document: [chunk text]. Write a short, succinct context that situates this chunk within the overall document, to improve search retrieval of this chunk." This is a distinct, purpose-built prompt, not a general summarization prompt.
3. **Prepend the generated context to the chunk's text** before embedding — the *stored, embedded, and retrieved* version of the chunk is now `[generated context] + [original chunk text]`, while the original chunk text (without the prepended context) can still be what's ultimately shown to the customer or cited (Chapter 8 Topic 2), keeping the context-enrichment purely a retrieval-quality mechanism rather than altering the actual cited source content.
4. **Index the contextualized chunk** in Qdrant/BM25 exactly as before (Chapters 6-7's pipeline is otherwise unchanged) — contextual retrieval is a preprocessing enhancement at the chunking/embedding stage, not a change to the retrieval algorithms themselves.
5. **At query time, nothing changes** — the query is still processed by Chapter 7's hybrid BM25+dense+RRF pipeline exactly as before; the improvement comes entirely from the richer, disambiguated chunk representations now being searched against, not from any query-side change.

---

### 3. How It Is Implemented in This Project

```python
def generate_chunk_context(full_document_text: str, chunk_text: str, client, model_id: str) -> str:
    """Anthropic's Contextual Retrieval technique: generates a short,
    situating summary for a chunk given its full source document.
    Uses this project's own claude-haiku-4-5-20251001 for cost efficiency
    -- this is a preprocessing/ingestion-time cost, not a query-time cost,
    so it's incurred once per chunk at ingestion, not per customer query."""

    context_prompt = f"""<document>
{full_document_text}
</document>

Here is a specific chunk from the above document that we want to situate:
<chunk>
{chunk_text}
</chunk>

Write a short, succinct context (1-2 sentences) that situates this chunk within
the overall document, to improve search retrieval of this chunk. Answer only
with the succinct context, nothing else."""

    response = client.messages.create(
        model=model_id, max_tokens=100,
        messages=[{"role": "user", "content": context_prompt}],
    )
    return response.content[0].text.strip()


def contextualize_knowledge_base(documents: list, chunks: list, client, model_id: str) -> list:
    """Runs contextual retrieval preprocessing over ALL chunks at
    INGESTION time (Chapter 4/5's pipeline), not at query time.
    Returns chunks with a NEW field, 'embedding_text', which is what
    actually gets embedded -- while 'page_content' (Chapter 4's Document
    pattern) remains the ORIGINAL chunk text, used for citation and
    display (Chapter 8 Topic 2), unchanged."""

    contextualized_chunks = []
    for chunk in chunks:
        source_doc = get_full_document_text(chunk["metadata"]["source"], documents)
        context = generate_chunk_context(source_doc, chunk["page_content"], client, model_id)

        contextualized_chunks.append({
            **chunk,
            "embedding_text": f"{context}\\n\\n{chunk['page_content']}",  # what gets embedded/indexed
            # chunk["page_content"] remains UNCHANGED -- still the original
            # text, still what gets cited and shown to the customer
        })
    return contextualized_chunks


# Chapter 6's Qdrant upsert now embeds embedding_text, not page_content directly:
#
#   embeddings = model.encode([c["embedding_text"] for c in contextualized_chunks], ...)
#   points = [PointStruct(..., payload={"text": c["page_content"], ...})  # cite ORIGINAL text
#             for c in contextualized_chunks]
#
# Chapter 7's BM25 index is built the same way -- tokenize embedding_text, not page_content,
# so BOTH retrieval legs benefit from the added context.
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **This is a one-time (or infrequent) ingestion-time cost, not a per-query cost**: critically, contextual retrieval's LLM calls happen once per chunk when the knowledge base is built or updated (Chapter 4's ingestion pipeline), not once per customer query — this is a fundamentally different cost profile from Chapter 8 Topic 7's HyDE (a per-query cost). At this project's 17-page scale, this is a small, one-time or occasional batch cost; even at much larger scale, it remains a fixed cost per document update, not a cost that compounds with query volume (8,000-12,000 emails/day never touches this cost at all).
- **Full-document context generation cost scales with document length and chunk count**: a very long source document means each of its many chunks requires a full-document context-generation call — Anthropic's own published technique specifically recommends using prompt caching (forward reference to Chapter 18) for the document text, since the same full document is sent repeatedly (once per chunk) with only the specific chunk changing, making this an ideal prompt-caching use case to avoid redundant token costs.
- **Re-running contextualization when documents are updated**: exactly like Chapter 6 Topic 8's embedding model migration concern, updating a source document (a policy change) requires regenerating context for every chunk from that document and re-embedding — this must be a required step in Chapter 4's ingestion pipeline whenever a document is updated, not an optional afterthought, since stale prepended context could actually be actively misleading (a new failure mode this technique introduces if not maintained correctly).
- **Monitoring**: track Recall@K and NDCG@K (Chapter 7 Topic 9's methodology) specifically comparing contextualized versus non-contextualized chunks — Anthropic's own published results showed meaningful retrieval improvement from this technique, but this project's own corpus and query patterns should be independently validated, following the evidence-before-adoption discipline used throughout.
- **Debugging a chunk that seems over-contextualized or under-contextualized**: review the specific generated context text for that chunk — since context generation uses an LLM call, it's subject to the same prompt-quality sensitivity as any other LLM-generated content; a poorly-generated context (too generic, or subtly inaccurate) could actually hurt rather than help that specific chunk's retrievability, requiring the same qualitative spot-checking discipline used for reviewing HyDE's hypothetical answers (Chapter 8 Topic 7).
- **Security**: negligible new risk — context generation operates on this project's own trusted, ingested documents (Chapter 4's controlled ingestion pipeline), not on untrusted customer input, so this doesn't introduce a new injection surface the way query-side transformations (Topic 2) or tool calls (Topic 3) do.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **Full-document context vs. neighboring-chunk context**: Anthropic's technique specifically uses the full source document for context generation rather than just a window of neighboring chunks, because a short document-level summary captures the necessary framing (what product, what section, what general topic) more reliably than an arbitrary-sized neighboring window might, and is simpler to implement — no need to decide how many neighboring chunks constitute "enough" context. For very long documents, this trades some cost for that simplicity and reliability.
- **Prepending context to both BM25 and dense retrieval inputs vs. dense-only**: prepending to both (as shown in Section 3) means BM25 also benefits from the added, disambiguating vocabulary the context introduces — plausible additional keywords the original chunk lacked (e.g. "Smart Saver FD" appearing in the prepended context even if the chunk itself only said "this product") directly help BM25's exact-term matching. This is a genuine, project-specific extension of Anthropic's original technique (which focused primarily on the embedding/dense retrieval improvement) worth validating specifically for this project's hybrid pipeline.
- **Storing `embedding_text` separately from `page_content` (this project's design) vs. overwriting the original chunk text**: keeping them separate (as shown) preserves the original, unmodified chunk text for citation purposes (Chapter 8 Topic 2) — citing the LLM-generated context alongside the original text could misrepresent what the source document actually, verbatim, says, undermining the citation mechanism's whole purpose. This separation is a deliberate, important design choice, not an incidental implementation detail.

---

### 6. Alternatives and When to Use Each

- **No contextualization (Chapters 5-7 as originally built)**: acceptable baseline, but leaves ambiguous, context-dependent chunks (like the nominee exception example) more vulnerable to retrieval misses than necessary.
- **Contextual retrieval via full-document LLM-generated summaries (this topic, Anthropic's technique)**: the recommended approach given this project's own use of `claude-haiku-4-5-20251001` (making the ingestion-time cost cheap) and genuine cross-reference-dependent content in the corpus.
- **Larger chunk sizes as an alternative fix for the same underlying problem**: increasing chunk size so more context is naturally included within each chunk directly, rather than prepending a separate summary — simpler, no LLM calls needed, but reintroduces Chapter 5's original tension (larger chunks produce blurrier, less-focused embeddings) that motivated small chunking in the first place; contextual retrieval specifically avoids this trade-off by keeping chunks small while still injecting disambiguating context.
- **Manual, human-authored chunk metadata/summaries during ingestion**: more accurate and controllable than LLM-generated context, but doesn't scale to a growing knowledge base (Chapter 9 Topic 8's ongoing product-launch scenario) the way an automated LLM-based approach does — appropriate only for a very small, slow-changing, high-stakes corpus where manual review of every chunk's context is feasible.

---

### 7. Common Mistakes and Production Failures

- Overwriting the original chunk's `page_content` with the contextualized version, corrupting what gets shown to customers and cited (Chapter 8 Topic 2) with LLM-generated summary text that isn't the verbatim source document content.
- Not re-running contextualization when source documents are updated, leaving stale, now-inaccurate prepended context actively confusing retrieval rather than helping it.
- Generating context using a generic summarization prompt rather than Anthropic's specific, purpose-built "situate this chunk for retrieval" prompt, producing summaries that don't actually add the disambiguating, retrieval-relevant information the technique depends on.
- Not using prompt caching for the repeated full-document text across many chunk-context-generation calls from the same document, incurring unnecessarily high ingestion-time token costs.
- Adopting this technique without validating its actual impact on this project's specific corpus via Chapter 7 Topic 9's evaluation methodology, assuming Anthropic's published general results automatically transfer.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: What problem does Contextual Retrieval solve that Chapter 5's chunking strategy alone doesn't?**
A: Small, focused chunks (necessary for precise embeddings, per Chapter 5) can lose surrounding context that disambiguates their meaning — a chunk stating an exception rule is ambiguous about what general rule it's an exception to, if that information lives in a different chunk or the document's introduction. Contextual Retrieval prepends a short, LLM-generated summary situating the chunk within its source document before embedding, injecting that disambiguating context without having to make the chunk itself larger.

**Q: Why is Contextual Retrieval's cost profile fundamentally different from Chapter 8 Topic 7's HyDE?**
A: Contextual Retrieval's LLM calls happen once per chunk at ingestion time (when the knowledge base is built or updated) — a fixed, one-time or occasional cost independent of query volume. HyDE's LLM call happens once per customer query at retrieval time — a cost that scales directly and continuously with production traffic (8,000-12,000 emails/day for this project). This makes Contextual Retrieval a much cheaper technique to adopt broadly, since it never touches the per-query cost path at all.

**Intermediate:**

**Q: Why does this project keep the original chunk text (`page_content`) separate from the contextualized text used for embedding (`embedding_text`)?**
A: Citation (Chapter 8 Topic 2) depends on being able to show or reference the verbatim source document content — if the LLM-generated context were merged into and citable as part of the "source text," this would misrepresent what the actual policy document says, since the context is a model-generated summary, not the document's own words. Keeping them separate ensures the contextualization technique improves retrieval quality without compromising the accuracy and verbatim-ness of what gets cited to customers.

**Q: Why does Anthropic's technique use the full source document for context generation rather than just the chunks immediately before and after the target chunk?**
A: A full-document-level context generation reliably captures the necessary framing — what product, what section, what overall topic — without requiring a decision about how large a neighboring window would be "enough," which can vary unpredictably depending on document structure. It's also simpler to implement consistently across documents of different structures, at the cost of some added token usage per context-generation call, which prompt caching (Chapter 18) mitigates for documents with many chunks.

**Advanced:**

**Q: Design the ingestion pipeline change needed to properly maintain Contextual Retrieval as this project's knowledge base grows and existing documents get updated (connecting to Chapter 9 Topic 8's ongoing product-launch scenario).**
A: Extend Chapter 4's incremental ingestion manifest (which already tracks content hashes to detect changed files) to also trigger re-contextualization, not just re-chunking and re-embedding, whenever a document's content hash changes. Since contextualization depends on the full document text, any change to that document invalidates every one of its chunks' previously-generated context, requiring all of them to be regenerated — this should be an atomic part of the existing "document changed, re-ingest" workflow, not a separately-triggered process that could be forgotten. Additionally, apply prompt caching for the full document text within a single re-ingestion run, since regenerating context for all of a document's chunks after an update involves the exact same repeated-full-document-per-chunk pattern the original ingestion did.

**Q: A teammate proposes skipping the LLM-based context generation and instead prepending each chunk with a cheap, rule-based header (e.g. the document title and section heading, if available in the source structure). Evaluate this alternative.**
A: This is a legitimate, much cheaper alternative for documents with reliable, informative structural metadata (titles, section headings) already present — Chapter 5's structure-aware chunking (Markdown header splitting) already extracts exactly this kind of metadata for some document types. For documents where structural metadata is rich and genuinely disambiguating (e.g. "Smart Saver FD Policy > Section 3: Premature Withdrawal Exceptions"), this cheap approach may capture most of the retrieval benefit at zero LLM cost. It falls short for documents with poor or generic structural metadata, or where genuine disambiguation requires more nuanced situating than a title/heading alone provides — the LLM-generated approach is more general-purpose and doesn't depend on the source document happening to have well-structured metadata. A reasonable hybrid: use the cheap rule-based header where good structural metadata exists, falling back to LLM-based context generation only for documents lacking it — worth validating both against Chapter 7 Topic 9's evaluation methodology before choosing.

**Scenario-based:**

**Q: After implementing Contextual Retrieval, Chapter 7 Topic 9's evaluation shows improved Recall@K overall, but a specific subset of queries about the nominee exception rule (the recurring example throughout Chapter 7) show no improvement. Diagnose.**
A: Review the actual generated context for the nominee-exception chunk specifically — it's possible the context-generation prompt produced a generic or insufficiently specific summary for this particular chunk (an LLM-generation quality issue, not a fundamental technique failure), or that the exception rule's disambiguating information genuinely isn't well-captured even at the full-document level (e.g. if the "general rule" it's an exception to is itself in a completely different source document, not just a different chunk of the same document — a cross-document context problem Anthropic's single-document-scoped technique doesn't address at all). If it's a generation-quality issue, refining the context-generation prompt or reviewing a sample of generated contexts for quality before broader deployment is the fix. If it's a genuine cross-document limitation, this reveals a boundary of what Contextual Retrieval alone can solve — cross-document relationships may need a different technique entirely (e.g. explicit metadata linking related documents, or a knowledge-graph-style approach), worth flagging as a known limitation rather than expecting this technique to solve every context-dependency pattern in the corpus.

---

### 9. Hidden Concepts and Prerequisites

- **This technique is Anthropic's own published research (September 2024, "Introducing Contextual Retrieval")**, worth knowing by name and origin — being able to cite that this project's implementation follows a specific, published, empirically-validated technique (rather than an ad hoc invention) is a genuine credibility signal in a Lead-level discussion, and situates this project's engineering choices within the broader, evolving RAG research landscape.
- **Contextual Retrieval and Chapter 7 Topic 3's SPLADE both solve a form of the same underlying problem — enriching a chunk's representation beyond its literal surface text** — SPLADE does this via learned vocabulary expansion at the term level; Contextual Retrieval does this via LLM-generated situating context at the passage level. Recognizing this parallel (two different mechanisms addressing the same class of "the literal text alone isn't enough" problem) is valuable systems-thinking connective tissue across this project's retrieval chapters.
- **This connects directly to Chapter 8 Topic 1's token budgeting**: contextualized chunks are slightly longer than their original versions (context prepended), meaning Chapter 8's budget calculations need to account for this small but real increase in per-chunk token count — a minor but real interaction between two chapters' techniques worth being aware of when reasoning about the full pipeline's token economics end to end.

---

### 10. Revision Summary

> Contextual Retrieval, Anthropic's own published technique, prepends a short, LLM-generated summary situating each chunk within its full source document before embedding and indexing — solving Chapter 5's chunking tension (small chunks for precise embeddings vs. losing surrounding disambiguating context) without requiring larger, blurrier chunks. Critically, this is an ingestion-time cost (incurred once per chunk when the knowledge base is built or updated via Chapter 4's pipeline), not a per-query cost, making it far cheaper to adopt broadly than query-time techniques like HyDE (Chapter 8 Topic 7). This project's implementation must keep the contextualized `embedding_text` (used for indexing) strictly separate from the original `page_content` (used for citation, Chapter 8 Topic 2), since citing LLM-generated context rather than verbatim source text would undermine the citation mechanism's integrity. Document updates must trigger re-contextualization of all affected chunks, extending Chapter 4's incremental ingestion manifest logic, and prompt caching (Chapter 18) should be used to avoid redundant token costs from repeatedly sending the same full document text across each of its chunks' context-generation calls. As with every other technique in this project, its actual benefit for this specific corpus should be validated via Chapter 7 Topic 9's evaluation methodology, not assumed from Anthropic's general published results alone.

---
