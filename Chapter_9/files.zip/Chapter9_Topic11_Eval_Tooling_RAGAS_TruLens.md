# Chapter 9: Retrieval — Putting It to Work

## Topic 11: Eval Tooling — RAGAS and TruLens as Standard Libraries for Automating RAG Metrics

---

### 1. Concept, Intuition, and Why It Exists

- This chapter (and Chapter 7 Topic 9, and Chapter 8's faithfulness/relevance/correctness framework) has hand-built every evaluation metric so far: Recall@K, MRR, NDCG@K, Hit Rate, Context Precision, the two-tier hallucination detection pipeline, the citation verification logic. Each was implemented from scratch, deliberately, so the *mechanics* would be fully understood before reaching for a library that hides them.
- This topic exists to close that loop: **RAGAS** and **TruLens** are the standard, widely-adopted open-source libraries that implement exactly these kinds of metrics (and more) as pre-built, tested, maintained components — this topic is an awareness-level introduction, not a deep implementation dive, because the actual value at this project's stage is knowing *what exists*, *why it matters*, and *when hand-built evaluation should give way to standardized tooling* — not re-deriving what's already been learned by building it by hand.
- The pedagogical principle behind building everything from scratch first, then introducing the library: understanding *why* Faithfulness needs claim decomposition and entailment checking (Chapter 8 Topic 4) makes RAGAS's `faithfulness` metric legible as "the standardized version of what we already built," not a mysterious black box — exactly the same principle Chapter 7 applied to BM25 (build the math by hand, then know what `rank_bm25` is actually doing).

---

### 2. Internal Working — Step by Step

**RAGAS (RAG Assessment) — what it actually provides:**

1. **Faithfulness**: automates exactly Chapter 8 Topic 4's claim-decomposition-and-entailment-checking pipeline — given an answer and its retrieved context, RAGAS extracts claims and checks each against the context, producing a 0-1 score, using an LLM internally to do what this project's Tier 2 LLM-as-judge did manually.
2. **Answer Relevancy**: automates Chapter 8 Topic 3's relevance check — generates several hypothetical questions the given answer *would* be a good response to, then measures their embedding similarity to the *actual* original query; a high similarity means the answer is well-targeted at what was actually asked (a more sophisticated version of this project's simple query-answer embedding similarity check).
3. **Context Precision**: automates this chapter's Topic 10's Context Precision metric — using an LLM to judge whether each retrieved chunk is relevant and useful for answering the question, without requiring the extensive manual labeling this project's hand-built version needed.
4. **Context Recall**: measures whether the retrieved context contains all the information needed to produce the ground-truth answer — requires a labeled ground-truth answer (similar to this project's evaluation set), checking whether the *retrieval* stage specifically (not generation) had access to everything necessary.
- These four metrics together directly map onto and formalize Chapter 8 Topic 3's faithfulness/relevance/correctness framework, plus Chapter 7 Topic 9's retrieval-quality metrics — RAGAS essentially packages this project's Chapters 7-9 evaluation work into one coherent, installable library.

**TruLens — a complementary, more observability-oriented tool:**

1. **Tracing and instrumentation**: TruLens focuses heavily on capturing full execution traces of an LLM application — every step, every intermediate input/output — closely related to this project's Chapter 9 Topic 3 discussion of full pipeline-stage logging for debugging `search_knowledge_base` calls, but as a structured, queryable tracing framework rather than ad hoc print statements and manual logging.
2. **Feedback functions**: TruLens's term for what RAGAS calls metrics — programmable functions that score an interaction along some dimension (groundedness, relevance, etc.) — conceptually the same idea as this project's hand-built check functions, but as a pluggable, reusable framework.
3. **Dashboards and continuous monitoring**: TruLens provides built-in visualization for tracking these feedback function scores over time across many production interactions — directly extending this project's repeated emphasis on *monitoring* every metric over time (BM25 zero-score rate, citation compliance rate, hallucination flag rate, etc.), now as a purpose-built tool rather than custom-built dashboards.

---

### 3. How It Is Implemented in This Project — Awareness-Level Code Sketch

```python
# This is an AWARENESS-LEVEL sketch, showing how this project's hand-built
# evaluation set (Chapter 7 Topic 9) would map onto RAGAS's interface --
# NOT a full production migration, which is beyond this topic's scope.

# pip install ragas

from datasets import Dataset
# from ragas import evaluate
# from ragas.metrics import faithfulness, answer_relevancy, context_precision, context_recall

def prepare_ragas_dataset(eval_set: list, agent_responses: list) -> "Dataset":
    """Converts this project's existing evaluation set format (Chapter 7
    Topic 9) into RAGAS's expected input format -- question, retrieved
    contexts, generated answer, and ground-truth answer per example."""
    ragas_format = {
        "question": [e["query"] for e in eval_set],
        "contexts": [r["retrieved_chunk_texts"] for r in agent_responses],  # list of lists
        "answer": [r["final_answer"] for r in agent_responses],
        "ground_truth": [e.get("ground_truth_answer", "") for e in eval_set],
    }
    return Dataset.from_dict(ragas_format)

# result = evaluate(
#     dataset=prepare_ragas_dataset(EVAL_SET, agent_responses),
#     metrics=[faithfulness, answer_relevancy, context_precision, context_recall],
# )
# print(result)  # -> {'faithfulness': 0.91, 'answer_relevancy': 0.87, ...}

# Conceptual mapping to what this project already built by hand:
RAGAS_TO_PROJECT_MAPPING = {
    "faithfulness": "Chapter 8 Topic 4's two-tier embedding+LLM-judge entailment checking",
    "answer_relevancy": "Chapter 8 Topic 3's query-answer embedding similarity check",
    "context_precision": "Chapter 9 Topic 10's hand-labeled Context Precision metric",
    "context_recall": "Chapter 7 Topic 9's Recall@K, but checked against a full ground-truth ANSWER "
                       "rather than just a set of relevant document IDs",
}

for ragas_metric, project_equivalent in RAGAS_TO_PROJECT_MAPPING.items():
    print(f"RAGAS's '{ragas_metric}' automates: {project_equivalent}")
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **RAGAS's metrics are themselves LLM-judge-based internally**, meaning adopting RAGAS doesn't eliminate the LLM-as-judge cost and reliability concerns already discussed in Chapter 8 Topic 4 (Tier 2) and will be discussed formally in Chapter 16 (LLM-as-Judge) — RAGAS packages the *mechanics* conveniently, but the underlying "is an LLM reliably judging another LLM's output" question remains exactly as relevant as it was for this project's hand-built Tier 2 checks.
- **Migrating to RAGAS is a genuine engineering decision with real trade-offs, not a strictly free upgrade**: the hand-built evaluation code (Chapter 7 Topic 9, Chapter 8 Topic 4, this chapter's Topic 10) is fully understood, fully controllable, and has zero external dependency risk — adopting RAGAS introduces a third-party library dependency (versioning, breaking changes, maintenance by an external team) in exchange for reduced maintenance burden and access to a broader, community-validated metric set. This is a genuine build-vs-buy trade-off, similar in spirit to the Chapter 7 Topic 7 discussion of local reranking models versus Cohere's managed API.
- **Cost**: RAGAS's LLM-judge-based metrics incur the same per-evaluation-run API costs as this project's own Tier 2 checks — running RAGAS's full metric suite across a large evaluation set is not free, and cost should be budgeted the same way this project already budgets for its hand-built LLM-as-judge calls.
- **TruLens's tracing overhead**: comprehensive execution tracing, while valuable for debugging (Chapter 9 Topic 3's concern), adds some instrumentation overhead to every request if run in production rather than just during offline evaluation — worth understanding whether TruLens is being used for offline evaluation only (low risk) versus live production tracing (requiring the same latency/overhead consideration given to any other production instrumentation).
- **Data residency for a regulated NBFC**: both RAGAS and TruLens's LLM-judge-based metrics typically call out to an LLM API to perform their scoring — this raises the same data-residency and PII-exposure consideration already flagged in Chapter 7 Topic 7 for Cohere's managed reranking API, requiring the same compliance review before sending customer-derived evaluation data through either tool's default LLM-calling configuration (both tools do support configuring which LLM/provider is used for judging, mitigating but not eliminating this concern).
- **Debugging library-produced scores**: when RAGAS or TruLens returns an unexpected metric score, having built the underlying mechanics by hand in Chapters 7-9 gives this project's team the ability to understand *what specifically* the library is likely doing internally to produce that number, and to sanity-check it — a genuine, durable benefit of the "build it by hand first" pedagogical approach this project has followed throughout.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **When should this project actually migrate from hand-built evaluation to RAGAS/TruLens?**: not automatically or immediately — the hand-built code has already proven itself, is fully understood by the team, and has no external dependency risk. Migration becomes worth considering when: the evaluation surface area grows enough that maintaining custom code for every new metric becomes a genuine burden, when the team wants access to metrics beyond what's been hand-built (RAGAS has several metrics beyond the four discussed here), or when standardized, community-recognized metric names and definitions matter for external communication (e.g. a compliance audit or an investor/stakeholder report referencing "RAGAS Faithfulness" is more immediately legible to an external audience than a custom, project-specific metric name).
- **Full migration vs. selective adoption**: rather than an all-or-nothing switch, this project could adopt RAGAS/TruLens specifically for the metrics where the library's implementation is likely more robust or comprehensive than the hand-built version (e.g. RAGAS's `context_recall`, which checks against a full ground-truth answer rather than just document IDs, may be a genuine improvement over Chapter 7 Topic 9's simpler Recall@K), while retaining hand-built code for metrics specifically tuned to this project's unique needs (e.g. Chapter 9 Topic 7's false-tool-use-claim check, which is specific to this project's multi-tool agent architecture and has no direct RAGAS equivalent).

---

### 6. Alternatives and When to Use Each

- **Fully hand-built evaluation (this project's approach through Chapters 7-9)**: appropriate for the learning stage (full understanding of mechanics), for highly project-specific checks with no standard library equivalent (Chapter 9 Topic 7's false-tool-use-claim detection), and for teams prioritizing zero external dependency risk.
- **RAGAS**: the standard choice once a team wants broader, more standardized RAG-specific metrics with less custom-code maintenance burden, and is comfortable with the LLM-judge-based cost and data-residency considerations.
- **TruLens**: complementary to RAGAS, more focused on tracing/observability and continuous production monitoring dashboards — worth adopting specifically when comprehensive execution tracing (beyond this project's current print-statement-based logging) becomes a genuine operational need.
- **A hybrid — hand-built for project-specific checks, RAGAS/TruLens for standard metrics**: likely the most practical eventual state for this project, following the selective-adoption reasoning above.

---

### 7. Common Mistakes and Production Failures

- Adopting RAGAS or TruLens before understanding what their metrics actually compute internally, treating them as black-box "quality scores" without the ability to sanity-check or debug unexpected results — exactly the failure this project's hand-built-first approach was designed to prevent.
- Assuming RAGAS's LLM-judge-based metrics are free of the same reliability concerns (LLM judging LLM) already identified for this project's own hand-built Tier 2 checks — the underlying epistemic concern doesn't disappear just because it's now inside a well-known library.
- Sending customer-derived evaluation data through RAGAS/TruLens's default LLM-calling configuration without the same data-residency compliance review already required for any other external LLM API call in this regulated domain.
- Treating migration to standardized tooling as strictly beneficial with no trade-offs, ignoring the genuine loss of full understanding and control that comes with depending on external library internals.
- Wholesale replacing all hand-built evaluation code rather than considering the selective-adoption, hybrid approach that preserves project-specific checks with no standard equivalent.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: What is RAGAS, and how does it relate to the evaluation work this project has already built by hand?**
A: RAGAS is a widely-adopted open-source library that implements standardized RAG evaluation metrics — Faithfulness, Answer Relevancy, Context Precision, and Context Recall — as pre-built, tested components. It directly formalizes and automates exactly what this project built from scratch across Chapters 7-9: Chapter 8 Topic 4's claim-decomposition-and-entailment hallucination checking maps to RAGAS's Faithfulness metric, Chapter 8 Topic 3's relevance check maps to Answer Relevancy, and this chapter's Topic 10 Context Precision metric maps directly to RAGAS's metric of the same name.

**Q: Why did this project build these metrics by hand first, rather than adopting RAGAS from the start?**
A: Building the mechanics manually first ensures genuine understanding of what each metric actually computes and why — this makes RAGAS's pre-built metrics legible as "the standardized version of something already understood" rather than an opaque black box, and gives the ability to sanity-check or debug unexpected library output. This mirrors the same pedagogical approach used throughout this project, such as building BM25's math by hand in Chapter 7 before treating `rank_bm25` as a known, trusted tool.

**Intermediate:**

**Q: Does adopting RAGAS eliminate the concerns Chapter 8 Topic 4 raised about LLM-as-judge reliability?**
A: No — RAGAS's Faithfulness and other metrics are themselves implemented using LLM calls internally to perform judgment, meaning the same underlying "is an LLM reliably judging another LLM's output" concern from Chapter 8 Topic 4's Tier 2 discussion (and Chapter 16's formal treatment) applies exactly as much to RAGAS's output as it did to this project's own hand-built Tier 2 checks. Adopting RAGAS changes who wrote the judging code, not whether the fundamental reliability question needs to be taken seriously.

**Q: This project has a project-specific check — false-tool-use-claim detection (Chapter 9 Topic 7) — that has no direct RAGAS equivalent. How should this inform a migration strategy?**
A: This is a strong argument for selective, hybrid adoption rather than wholesale replacement — RAGAS and TruLens should be adopted for the standard, general-purpose metrics they handle well (Faithfulness, Answer Relevancy, Context Precision, Context Recall), while project-specific checks tailored to this project's unique multi-tool agent architecture, with no standard library equivalent, should remain hand-built and maintained directly, since no external library is likely to provide exactly this check out of the box.

**Advanced:**

**Q: Design a decision framework for when this project should actually migrate specific evaluation components from hand-built code to RAGAS/TruLens.**
A: Migrate a specific metric when at least one of these holds: the hand-built version requires ongoing maintenance effort disproportionate to its value (a genuine engineering cost signal); the library's implementation is demonstrably more robust or complete than the hand-built version for that specific metric (e.g. RAGAS's Context Recall checking against a full ground-truth answer, arguably richer than this project's document-ID-based Recall@K); external communication or compliance requirements benefit from using a standardized, externally-recognized metric name and definition; or the evaluation surface area has grown enough that maintaining an increasing number of custom hand-built checks has become a genuine bottleneck to the team's velocity. Do NOT migrate: project-specific checks with no clean library equivalent (false-tool-use-claim detection), or metrics where the team specifically values the full transparency and zero-dependency-risk of hand-built code for a particularly sensitive or high-stakes check.

**Q: A stakeholder asks why this project didn't just use RAGAS from day one, given it exists and would have saved development time. How do you justify the approach actually taken?**
A: The time invested in building these metrics by hand was not solely about producing the metrics themselves — it built deep, durable understanding of exactly what "faithfulness," "relevance," and "context quality" mean mechanically, which pays off in every subsequent debugging session, every design decision about thresholds and tiering, and every future evaluation-related decision this project or its engineers will make, including deciding intelligently *when and how* to now adopt RAGAS with genuine understanding rather than blind trust. This is analogous to why this project built BM25's math from scratch (Chapter 7 Topic 1) before treating `rank_bm25` as a trusted library — the goal was never to avoid using good tools indefinitely, but to reach the point of using them with full understanding of what they do, which is a stronger foundation for a Lead-level engineer than having used the library correctly by luck or documentation-following alone.

**Scenario-based:**

**Q: After adopting RAGAS for Faithfulness scoring in production, the reported Faithfulness scores are consistently higher than what this project's own hand-built Tier 2 LLM-judge checks were finding for the same set of answers. Diagnose the discrepancy.**
A: This requires comparing the actual mechanics, not just the output scores — check whether RAGAS's internal claim-decomposition approach differs from this project's own (perhaps RAGAS extracts fewer, coarser-grained claims per answer, making entailment checking easier to satisfy than this project's more fine-grained, per-claim approach), whether RAGAS's underlying judge model or prompt differs meaningfully from the one used in this project's hand-built Tier 2 (a different model or prompt could produce systematically more lenient judgments), or whether the specific test set used for comparison differs in composition between the two evaluation runs. Given this project built its own version first, it has the diagnostic advantage of being able to run both approaches side by side on the identical set of answers and directly inspect where and why they diverge — exactly the kind of debugging RAGAS's black-box internals alone would make much harder, reinforcing the value of the build-first approach even after adopting the library.

---

### 9. Hidden Concepts and Prerequisites

- **RAGAS and TruLens are part of a broader, rapidly-evolving ecosystem of "LLM observability and evaluation" tooling** (also including tools like LangSmith, Arize Phoenix — forward-referenced in Chapter 14's tracing discussion) — worth knowing this is an active, competitive tooling space, not a single settled standard, meaning the specific library choice may reasonably change over this project's lifetime as the ecosystem matures.
- **The relationship between offline evaluation (running RAGAS against a fixed evaluation set) and online/production monitoring (TruLens-style continuous dashboards) mirrors the same distinction this project has made throughout** between Chapter 7 Topic 9's evaluation-set-based metric computation and the "monitor in production" sections repeated in nearly every topic — these two libraries roughly specialize in these two complementary but distinct evaluation modes.
- **This topic connects directly forward to Chapter 14's RAG Evaluation End-to-End chapter**, which will cover RAGAS in full implementation depth (not just awareness-level), including building a complete evaluation set specifically formatted for RAGAS and integrating tracing/observability into the production pipeline — this topic is deliberately the lighter, conceptual bridge, while Chapter 14 is where hands-on RAGAS implementation actually happens.

---

### 10. Revision Summary

> RAGAS and TruLens are the standard, widely-adopted libraries that automate exactly the evaluation mechanics this project built by hand across Chapters 7-9 — RAGAS's Faithfulness, Answer Relevancy, Context Precision, and Context Recall map directly onto Chapter 8 Topic 4's hallucination detection, Chapter 8 Topic 3's relevance checking, and this chapter's Topic 10 Context Precision and Chapter 7 Topic 9's Recall@K, respectively. Building these metrics by hand first was a deliberate pedagogical choice, ensuring genuine mechanical understanding before treating a library's output as trustworthy — the same principle applied to BM25 in Chapter 7. Adopting RAGAS does not eliminate the LLM-as-judge reliability concerns already raised in Chapter 8 Topic 4, since RAGAS's metrics are themselves LLM-judge-based internally, and migration should be a selective, evidence-based decision (hybrid adoption, keeping project-specific checks like Chapter 9 Topic 7's false-tool-use-claim detection hand-built) rather than a wholesale, assumed-beneficial replacement. This topic is an awareness-level bridge; Chapter 14's RAG Evaluation End-to-End chapter is where full, hands-on RAGAS implementation and production tracing integration actually happens.

---
