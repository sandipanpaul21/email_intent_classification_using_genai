# Chapter 9: Retrieval — Putting It to Work

## Topic 8: The Actual Proof RAG Works — The Smart Saver FD Test

---

### 1. Concept, Intuition, and Why It Exists

- Every chapter since Chapter 4 has been building toward one concrete, falsifiable claim: RAG makes this project's agent meaningfully better at answering questions about content the base model has no training-time knowledge of. This topic is where that claim gets tested directly, not assumed.
- The specific test case, established as the recurring motivating example throughout Chapter 7 (Topics 2, 3, 4, 5): a **newly-launched FD product** — "Smart Saver FD" — with terms and rules that exist only in this project's knowledge base, not in `claude-haiku-4-5-20251001`'s training data. This is the cleanest possible experiment, because the model genuinely cannot know the answer from parametric knowledge alone; any correct, specific answer *must* have come from retrieval.
- Why this is the "actual proof" rather than a hypothetical: Chapter 2 already built v0-v3 prompted classifiers with no RAG at all, measured against the MuRIL baseline. This topic runs the *exact same kind of test* — a real email, a real question — through both the pre-RAG agent (Chapter 2/3's classification-only agent) and the fully-wired post-RAG agent (this chapter's Topics 1-7), and directly compares the outputs side by side. This is the empirical closing argument for why Chapters 4-9 were worth building.

---

### 2. Internal Working — Step by Step

1. **Construct the test artifact**: a synthetic "Smart Saver FD" policy document, ingested into the knowledge base via Chapter 4's pipeline exactly as any real new product document would be — e.g. "Smart Saver FD offers a flexible premature withdrawal option with zero penalty for balances above ₹5,00,000, and a reduced 0.5% penalty for balances below that threshold, applicable only during the first 90 days from account opening."
2. **Construct the test email**: a realistic customer email referencing this product by name, asking a question whose correct answer requires the specific, novel policy detail — e.g. "I have a Smart Saver FD with ₹6 lakhs, if I withdraw next month will I be charged a penalty?"
3. **Run the email through the pre-RAG path**: this project's original Chapter 2/3 agent, with no `search_knowledge_base` tool available at all — it can only classify (FD/Non-FD/Multiple Category) and, at best, generate a generic response using whatever it "knows" about FDs in general, which necessarily does not include "Smart Saver FD" specifics since the product doesn't exist in its training data.
4. **Run the same email through the post-RAG path**: the fully-wired agent from this chapter's Topics 1-7 — `search_knowledge_base` is available, the trigger logic (Topic 1) should recognize this as a policy question, retrieval should surface the ingested Smart Saver FD document, and the final answer should correctly state "no penalty, since the balance is above ₹5,00,000" with a citation to the specific ingested document.
5. **Compare outputs directly, side by side**: this is the entire point — not an aggregate metric, but a literal before-and-after transcript comparison, exactly the kind of concrete evidence that makes an architectural investment defensible in a design review or an interview.

---

### 3. How It Is Implemented in This Project

```python
# Step 1: Ingest the test document (Chapter 4's pipeline, unchanged)
SMART_SAVER_TEST_DOC = {
    "text": ("Smart Saver FD offers a flexible premature withdrawal option with "
             "zero penalty for balances above Rs 5,00,000, and a reduced 0.5 "
             "percent penalty for balances below that threshold, applicable "
             "only during the first 90 days from account opening."),
    "source": "05_Smart_Saver_FD_Launch.pdf",
    "doc_type": "product",
}
# ingest_document(SMART_SAVER_TEST_DOC) -- Chapter 4's ingestion pipeline

TEST_EMAIL = {
    "subject": "Smart Saver FD withdrawal query",
    "content": ("I have a Smart Saver FD with 6 lakhs, if I withdraw next "
                "month will I be charged a penalty?"),
}


def run_pre_rag_agent(email: dict, client, model_id: str) -> str:
    """Chapter 2/3's original agent -- classification tools only,
    NO search_knowledge_base available. Represents this project's
    state BEFORE Chapters 4-9's RAG work."""
    pre_rag_tools = [VALIDATE_FD_REFERENCE_TOOL, FINALIZE_CLASSIFICATION_TOOL, REFUSE_OUT_OF_SCOPE_TOOL]
    # ... runs run_agent() with this restricted toolset, then asks the model
    # to also draft a customer-facing response using ONLY its own knowledge
    # (no retrieval available) -- this simulates the pre-RAG capability ceiling
    response_prompt = (f"A customer asks: '{email['content']}'. Respond as a "
                        f"customer service agent for an NBFC, using your own "
                        f"knowledge of FD products.")
    response = client.messages.create(
        model=model_id, max_tokens=200,
        messages=[{"role": "user", "content": response_prompt}],
    )
    return response.content[0].text


def run_post_rag_agent(email: dict, client, model_id: str, tools_with_rag: list) -> dict:
    """This chapter's fully-wired agent -- search_knowledge_base available,
    retrieval triggering (Topic 1), citation (Chapter 8 Topic 2), the full
    pipeline built across Chapters 4-9."""
    # ... runs run_agent() with the full tools_with_rag list, which includes
    # SEARCH_KNOWLEDGE_BASE_TOOL and FINALIZE_ANSWER_WITH_CITATIONS_TOOL
    # (Chapter 8 Topic 2), letting the model retrieve and cite as needed
    result = run_agent_with_rag(email, client, model_id, tools_with_rag)
    return result


def compare_pre_post_rag(email: dict, client, model_id: str, tools_with_rag: list) -> dict:
    """The actual side-by-side comparison -- this IS the proof artifact."""
    pre_rag_answer = run_pre_rag_agent(email, client, model_id)
    post_rag_result = run_post_rag_agent(email, client, model_id, tools_with_rag)

    return {
        "email": email,
        "pre_rag_answer": pre_rag_answer,
        "post_rag_answer": post_rag_result.get("answer"),
        "post_rag_cited_sources": post_rag_result.get("sources_used", []),
        "post_rag_correctly_cited_new_doc": "05_Smart_Saver_FD_Launch.pdf" in post_rag_result.get("sources_used", []),
    }
```

- The expected, hoped-for outcome: `pre_rag_answer` is generic, hedging, or simply wrong (likely stating a made-up or generic penalty percentage, since the model has no actual knowledge of "Smart Saver FD" and may either admit ignorance or — more concerning, and itself informative — hallucinate a plausible-sounding but fabricated answer, directly illustrating Chapter 8 Topic 4's motivating problem). `post_rag_answer` correctly states "no penalty" with a citation to the newly-ingested document, having never existed in the model's training data at all — proof that the answer's correctness came specifically from retrieval, not the model's general knowledge.

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **The test is only valid if the product name and details are genuinely novel**: if "Smart Saver FD" or a suspiciously similar product happens to exist in publicly available financial content the model was trained on, the pre-RAG agent might coincidentally answer correctly by chance, undermining the experiment's validity — the test document and product name should be verified as sufficiently distinctive (a fictional or clearly project-specific name, with specific numeric terms unlikely to coincidentally match any real product) before treating a pre-RAG failure as proof of anything.
- **A single test case is anecdotal, not statistical evidence**: this topic's value is as a concrete, illustrative demonstration — for a rigorous, defensible claim about RAG's overall impact, this single Smart Saver FD test should be one instance within Chapter 7 Topic 9's broader evaluation harness (extended, per Chapter 8's generation-quality framework, to compare pre-RAG and post-RAG answer quality across many queries, not just one), not treated as sufficient evidence on its own.
- **Monitoring the ongoing validity of this proof over time**: as `claude-haiku-4-5-20251001` or any future model version changes, its training data cutoff and general knowledge shift — a test case that was clean evidence of RAG's necessity today might not remain so if some future model's training data happens to include your test product's name and figures; the specific test artifact needs periodic revalidation, or better, new novel-product test cases should be constructed as new products are actually launched in production (a validation methodology, not a one-time proof, mirroring Chapter 8 Topic 3's discussion of ongoing correctness verification).
- **Cost and latency**: negligible — this is a small number of test API calls, not a production workload concern.
- **Security**: none specific to this topic beyond what's already covered.
- **Deployment**: this comparison methodology should become a standing regression test — every time a new product is genuinely launched and its documentation ingested (Chapter 4), running this same pre-RAG-vs-post-RAG comparison (even informally) provides an ongoing, real-world validation that the RAG pipeline is still doing its job for new content, not just a one-time historical proof.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **Single dramatic test case vs. systematic evaluation-set-based comparison**: the single Smart Saver FD test is more *persuasive* and *interpretable* for a human audience (a stakeholder, an interviewer, a design review) than an aggregate metric — humans understand a concrete before-and-after story better than a Recall@K number. But it is not, by itself, statistically rigorous. The correct approach uses both: the dramatic single-case demonstration for communication and intuition-building, backed by the systematic evaluation-set comparison (extending Chapter 7 Topic 9's methodology) for the actual, defensible engineering justification.
- **Testing against a truly novel product vs. testing against a subtly-updated existing one**: this topic uses a wholly novel product (cleanest signal, easiest to verify the model couldn't have known it), but an equally valuable complementary test uses a policy *update* to an existing, previously-known product (e.g. a rate change) — this tests whether RAG correctly reflects *current* information over the model's potentially stale training-time knowledge, a distinct but related proof point connecting to Chapter 8 Topic 3's correctness/staleness discussion.

---

### 6. Alternatives and When to Use Each

- **Single novel-product test case (this topic's primary method)**: best for building intuitive, communicable proof of RAG's value — ideal for demonstrations, documentation, and interview storytelling.
- **Systematic evaluation-set-based pre/post-RAG comparison**: best for rigorous, statistically defensible engineering justification — should always accompany, not replace, the single dramatic test case.
- **A/B testing in production (comparing RAG-enabled vs. RAG-disabled agent behavior on live traffic)**: the most rigorous, real-world validation, but carries real risk (some live customers receiving the intentionally-worse pre-RAG experience) — appropriate only with careful guardrails and likely only for a small, controlled traffic percentage, and a more advanced technique than this project's current stage requires.

---

### 7. Common Mistakes and Production Failures

- Using a test product name or detail that coincidentally overlaps with real, publicly known financial products, invalidating the "the model couldn't have known this" premise the whole test depends on.
- Treating a single successful demonstration as sufficient, ongoing proof without ever incorporating it into Chapter 7 Topic 9's systematic evaluation methodology for continuous validation.
- Not revalidating the test as the underlying model version changes over time, risking the proof becoming stale or invalid without anyone noticing.
- Only testing the "RAG succeeds" direction (does post-RAG correctly answer) without also carefully examining the "pre-RAG fails informatively" direction — specifically checking whether the pre-RAG agent hallucinates a *confident but wrong* answer (the most compelling, cautionary evidence) versus simply admitting ignorance (a less dramatic but still valid comparison point).

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: Why is a newly-launched, fictional FD product the ideal test case for proving RAG's value, rather than testing with an existing, well-known FD policy question?**
A: A newly-launched product with details invented specifically for this project's knowledge base cannot possibly exist in the base model's training data — any correct, specific answer about it must have come from retrieval, not the model's own parametric knowledge. Testing with an existing, well-known policy question doesn't cleanly separate these two possibilities, since the model might already know the general answer from its training data regardless of whether RAG worked correctly.

**Q: What are the two things you're comparing in this test, concretely?**
A: The agent's response to the same customer email under two conditions — with `search_knowledge_base` unavailable (representing this project's pre-Chapter-4 capability, using only the model's own general knowledge) versus with the full Chapter 4-9 RAG pipeline available and correctly triggered. The comparison directly shows what specific capability the RAG pipeline actually adds, in a concrete, inspectable transcript rather than an abstract metric.

**Intermediate:**

**Q: Why is a single test case, however dramatic, insufficient as the sole justification for RAG's value in a production engineering decision?**
A: A single case is anecdotal — it demonstrates that RAG *can* work for one specific scenario, but says nothing statistically reliable about how often it works correctly across the full range of real customer queries, edge cases, and failure modes. A rigorous justification needs Chapter 7 Topic 9's systematic evaluation-set methodology, extended with generation-quality comparisons (pre-RAG vs. post-RAG) across many queries, to make a statistically defensible claim rather than relying on one compelling anecdote.

**Q: What specific risk exists in choosing your test product's name and details, and how would you mitigate it?**
A: If the chosen name or specific figures happen to coincidentally resemble a real, publicly documented financial product the model might have encountered during training, a correct pre-RAG answer could occur by chance, undermining the premise that the model "couldn't have known" the answer. Mitigate by choosing a distinctive, clearly fictional or project-specific product name and unusual, specific numeric terms (an unlikely-to-coincidentally-match combination of threshold amounts and percentages) and verifying, ideally by directly asking the base model about the product name before running the actual test, that it shows no prior familiarity with it.

**Advanced:**

**Q: Design an ongoing validation process, beyond the one-time Smart Saver FD test, that continues to prove RAG's value as this project evolves in production.**
A: Every time a genuinely new product or policy update is launched and ingested into the knowledge base (Chapter 4's pipeline), run the same pre-RAG-vs-post-RAG comparison methodology as a standing regression check — this naturally produces fresh, uncontaminated test cases over time (since each new product launch is, by construction, something no existing model version could have prior knowledge of), avoiding the staleness risk of relying indefinitely on one original test case as model versions change. Additionally, incorporate a systematic sample of these before/after comparisons into Chapter 7 Topic 9's evaluation harness as a distinct "genuinely novel content" evaluation slice, tracked separately from the general evaluation set, giving an ongoing, quantified signal of RAG's continued necessity and effectiveness specifically for new-content scenarios, not just a historical, one-time demonstration.

**Q: A skeptical stakeholder argues that since `claude-haiku-4-5-20251001` is already highly capable, the RAG infrastructure built across Chapters 4-9 might be unnecessary overhead for a domain the model already understands reasonably well. How does this topic's test directly address that skepticism?**
A: The Smart Saver FD test directly demonstrates the specific, irreducible limitation general model capability cannot solve: no matter how capable a model is at general reasoning and FD-domain concepts broadly, it structurally cannot know facts that postdate its training data or are specific to this project's proprietary product catalog. The test provides a concrete, inspectable transcript showing the pre-RAG agent either admitting ignorance or — more persuasively for a skeptical audience — confidently generating a plausible-sounding but fabricated penalty figure, directly illustrating the hallucination risk Chapter 8's entire verification infrastructure exists to catch. This reframes the stakeholder conversation from an abstract "is RAG worth it" debate into a concrete "here is a real customer question your model would have answered wrong, and here is proof RAG gets it right" demonstration — a materially stronger argument than any amount of architectural reasoning alone.

**Scenario-based:**

**Q: You run the Smart Saver FD test, and to your surprise, the pre-RAG agent's answer is also correct — it happens to state the right penalty structure. Investigate why, and what this means for your test's validity.**
A: First, verify whether this is genuine coincidence (the model's general reasoning about "flexible withdrawal products with balance thresholds" happened to guess plausible-sounding numbers that coincidentally matched your specific invented figures) or a genuine leak (the test product's name or details are less distinctive than intended and may resemble something in the model's actual training data, or the test setup accidentally allowed some information to leak into the pre-RAG condition, such as an overly generic system prompt still containing hints). If it's coincidence, this specific test case is invalidated as clean proof for this specific model, and a new, more distinctively-specified test case should be constructed with less "guessable" numeric details (e.g. a truly unusual, non-round-number threshold that a plausible generic guess would be unlikely to hit). If it's a genuine information leak, this itself is a valuable, if uncomfortable, finding — it reveals a gap in the pre-RAG test harness's isolation, worth fixing before trusting any comparison result from it, echoing this project's broader discipline of always verifying that a test setup is actually testing what it claims to test before trusting its conclusions.

---

### 9. Hidden Concepts and Prerequisites

- **This topic is an instance of "knowledge cutoff" testing, a general and important LLM evaluation technique** — deliberately probing a model with content that postdates or falls outside its training data is a standard way to validate retrieval-augmentation systems generally, not unique to this project; recognizing this as a named, general technique (rather than an ad hoc idea specific to FDs) strengthens how this test can be explained and defended in a broader context.
- **The distinction between "the model doesn't know" (admits ignorance) and "the model confabulates" (confidently fabricates)** is itself a meaningful signal worth capturing during this test — a pre-RAG agent that honestly says "I don't have information about this specific product" is a *better-behaved* failure than one that fabricates a plausible-sounding but wrong answer, even though both represent the same underlying capability gap; this distinction connects directly to Chapter 9 Topic 6's "say you don't know" prompting discussion, since a model well-prompted for honest uncertainty might fail this test more gracefully even without RAG, while a poorly-prompted model's confident fabrication makes the RAG improvement look even more dramatic and necessary by contrast.
- **This connects forward to Chapter 14's RAG Evaluation End-to-End chapter**, where RAGAS-style metrics will formalize exactly this kind of before/after, ground-truth-aware comparison at scale — this topic's single hand-built test case is the intuitive, illustrative precursor to that more systematic, tooled evaluation methodology.

---

### 10. Revision Summary

> This topic provides the concrete, falsifiable proof that Chapters 4-9's RAG investment was worthwhile: a genuinely novel "Smart Saver FD" product, invented specifically so the base model cannot possibly know its terms from training data, run through both a pre-RAG agent (Chapter 2/3's classification-only capability) and the fully-wired post-RAG agent (this chapter's Topics 1-7), with the two responses compared directly. A correct, cited post-RAG answer alongside a generic, hedging, or fabricated pre-RAG answer is the clearest, most communicable evidence of RAG's actual value — more persuasive to stakeholders than any abstract metric, though it must be paired with Chapter 7 Topic 9's systematic evaluation-set methodology for full statistical rigor, not treated as sufficient proof on its own. The test's validity depends on the product name and figures being genuinely distinctive enough that the model couldn't coincidentally guess correctly, and this validation methodology should become an ongoing practice — rerun for every genuinely new product launch — rather than a one-time historical demonstration that risks becoming stale as model versions change over time.

---
