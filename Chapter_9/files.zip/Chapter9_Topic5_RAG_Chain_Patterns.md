# Chapter 9: Retrieval — Putting It to Work

## Topic 5: RAG Chain Patterns — Stuff vs. Map-Reduce vs. Refine vs. Map-Rerank

---

### 1. Concept, Intuition, and Why It Exists

- Every RAG implementation so far in this project (Chapters 6-8, Chapter 9 Topics 1-4) has implicitly used exactly one pattern: retrieve a handful of chunks, put them all in one prompt, generate one answer — the "Stuff" pattern, though it's never been named as such until now. This topic exists to make that choice explicit, name the alternatives, and clarify precisely when Stuff stops being sufficient.
- These four patterns answer the same underlying question in different ways: **how do you generate an answer when the relevant context might be larger than what comfortably fits in one prompt, or when a single-pass synthesis isn't the best way to combine multiple sources?**
- For this project's actual scale — a 17-page knowledge base, `claude-haiku-4-5-20251001`'s 200K token context window — Stuff is not just adequate but clearly correct, and this topic's real value is understanding *why* it's correct here and precisely what would need to change about this project's scale or requirements before a different pattern became necessary.

---

### 2. Internal Working — Step by Step

**Stuff (this project's current, correct pattern):**

1. Retrieve top-k chunks (Chapter 7's full pipeline).
2. "Stuff" all of them into a single prompt's context (Chapter 8 Topic 1's budget-aware construction).
3. One generation call produces the final answer.
- Simplest, fastest, cheapest — but fundamentally bounded by the context window; if retrieved content exceeds the budget, Stuff has no answer beyond "drop chunks" (Chapter 8 Topic 1's mitigation, which is itself an implicit acknowledgment that Stuff has limits).

**Map-Reduce:**

1. Retrieve a potentially large number of chunks — more than could ever fit in one prompt.
2. "Map" step: generate a separate mini-answer or summary for *each* chunk (or small group of chunks) independently, via separate LLM calls.
3. "Reduce" step: combine all the mini-answers/summaries into a final synthesis via one more LLM call.
- Scales to arbitrarily large retrieved-context volumes, since each Map call only ever sees one chunk's worth of content — but costs N+1 LLM calls instead of 1, and loses some cross-chunk reasoning ability since each Map step doesn't see what other chunks contain.

**Refine:**

1. Retrieve chunks, order them (Chapter 7's ranking already does this).
2. Generate an initial answer from the first chunk alone.
3. For each subsequent chunk, in order, feed the *existing* answer plus the new chunk back to the model, asking it to *refine* (improve, correct, or extend) the answer using this additional context.
4. The final refined answer, after all chunks have been incorporated sequentially, is the result.
- Preserves a form of cross-chunk reasoning (each refinement sees the accumulated answer so far) at the cost of being inherently sequential — cannot parallelize across chunks the way Map-Reduce's Map step can, since each refinement step depends on the previous one's output.

**Map-Rerank:**

1. Retrieve chunks.
2. "Map" step: generate a candidate answer *and* a confidence/relevance score from *each* chunk independently (similar to Map-Reduce's Map step, but each call also self-assesses how well it answered the question).
3. "Rerank" step: instead of combining all candidate answers, simply pick the single highest-scoring candidate answer as the final result — no synthesis step at all.
- Useful specifically when the correct answer is very likely to come from a *single* chunk rather than requiring synthesis across several — trades comprehensiveness for simplicity and cost (N calls, no expensive final synthesis call, though also no ability to combine partial information from multiple chunks).

---

### 3. How It Is Implemented in This Project — And Why Stuff Is Correct Here

```python
# STUFF -- what this project already does (Chapters 6-8, Chapter 9 Topics 1-4)
def stuff_pattern_answer(query: str, ranked_chunks: list, client, model_id: str) -> str:
    """This project's existing pattern, now named explicitly. Appropriate
    because: 17-page knowledge base, top-k retrieval (k=5-10) after
    Chapter 7's reranking/MMR narrowing, and a 200K token context window
    (claude-haiku-4-5-20251001) that comfortably fits this volume with
    enormous headroom (per Chapter 8 Topic 1's Module 4 measurements:
    ~199,000+ tokens available for chunks after system prompt and
    reserved output)."""
    context_block = build_context_block(ranked_chunks, token_budget=190_000)
    prompt = f"Context:\\n{context_block}\\n\\nQuestion: {query}"
    response = client.messages.create(
        model=model_id, max_tokens=500,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.content[0].text


# MAP-REDUCE -- shown for comparison, NOT needed at this project's scale
def map_reduce_pattern_answer(query: str, many_chunks: list, client, model_id: str) -> str:
    """Illustrative only -- this project's 17-page corpus never produces
    enough retrieved volume to require this. Shown to make the CONTRAST
    with Stuff concrete."""
    mini_answers = []
    for chunk in many_chunks:  # potentially far more chunks than Stuff could ever hold
        map_prompt = f"Based ONLY on this passage, answer if possible:\\n{chunk['text']}\\n\\nQuestion: {query}"
        response = client.messages.create(
            model=model_id, max_tokens=150,
            messages=[{"role": "user", "content": map_prompt}],
        )
        mini_answers.append(response.content[0].text)

    reduce_prompt = f"Combine these partial answers into one final answer:\\n" + \\
                     "\\n---\\n".join(mini_answers) + f"\\n\\nOriginal question: {query}"
    final_response = client.messages.create(
        model=model_id, max_tokens=500,
        messages=[{"role": "user", "content": reduce_prompt}],
    )
    return final_response.content[0].text


# REFINE -- shown for comparison
def refine_pattern_answer(query: str, ordered_chunks: list, client, model_id: str) -> str:
    """Illustrative only. Sequential, so slower than Map-Reduce for the
    same chunk count, but preserves accumulated-context reasoning."""
    current_answer = None
    for chunk in ordered_chunks:
        if current_answer is None:
            prompt = f"Answer using this context:\\n{chunk['text']}\\n\\nQuestion: {query}"
        else:
            prompt = (f"Existing answer: {current_answer}\\n\\n"
                      f"New context to consider:\\n{chunk['text']}\\n\\n"
                      f"Refine the existing answer if this new context adds or corrects anything. "
                      f"Question: {query}")
        response = client.messages.create(
            model=model_id, max_tokens=300,
            messages=[{"role": "user", "content": prompt}],
        )
        current_answer = response.content[0].text
    return current_answer
```

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **Stuff's failure mode is a hard cliff, not a graceful degradation**: once retrieved content exceeds the available token budget (Chapter 8 Topic 1), Stuff's only recourse is dropping whole chunks — at this project's current scale this essentially never triggers (Chapter 8 Topic 1 Module 4 measured ~199,420 tokens available against a handful of small chunks), but if the knowledge base grew by two orders of magnitude, or if `top_k` were misconfigured to retrieve hundreds of chunks, this cliff would be hit.
- **Map-Reduce's cost scales linearly with chunk count**: N chunks means N+1 LLM calls instead of Stuff's 1 — at any meaningful production volume, this is a substantial, direct cost multiplier that must be weighed against the actual need for it.
- **Map-Reduce loses cross-chunk reasoning**: if the correct answer requires combining a fact from chunk A with a fact from chunk B (e.g. the general penalty rate from one document plus a specific nominee exception from another), each independent Map call only sees one chunk and cannot make that combination — only the Reduce step sees all the mini-answers together, and by then the original source detail may have been lost in each mini-answer's compression.
- **Refine is sequential and therefore slow**: N chunks means N sequential (not parallelizable) LLM calls, each waiting on the previous one's output — for any chunk count beyond a handful, this produces meaningfully worse latency than Map-Reduce's parallelizable Map step.
- **Map-Rerank silently discards potentially useful partial information**: if the true best answer actually needs combining insights from two different chunks, Map-Rerank's "pick the single best candidate" approach cannot represent that — it only works well when questions genuinely have their complete answer in one chunk.
- **Monitoring, if this project ever needed to migrate off Stuff**: the trigger signal would be Chapter 8 Topic 1's chunk-drop-event logging showing a persistent, non-trivial drop rate — that log data is exactly the evidence needed to justify the added cost and complexity of Map-Reduce, Refine, or Map-Rerank, rather than migrating preemptively.
- **Security**: pattern choice has no direct security implications, but Map-Reduce and Refine's additional LLM calls each represent additional surface area where Chapter 3's prompt-injection defenses must be consistently applied — a defense correctly implemented in Stuff's single call must be replicated correctly across every Map/Refine call, not accidentally dropped in the additional intermediate steps.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **The trigger for migrating off Stuff should be evidence, not anticipation**: exactly the same principle applied throughout Chapters 7-8 — this project should not adopt Map-Reduce, Refine, or Map-Rerank preemptively "in case the knowledge base grows," but only once Chapter 8 Topic 1's chunk-drop monitoring shows this is an actual, measured problem, following the same evidence-before-complexity discipline established repeatedly.
- **Map-Reduce vs. Refine when migration eventually becomes necessary**: Map-Reduce's parallelizability makes it faster at scale (all Map calls can run concurrently), but loses cross-chunk reasoning; Refine preserves more cross-chunk reasoning at the cost of sequential latency. For this project's FD policy domain, where cross-referencing a general rule against a specific exception (the nominee case, from Chapter 7's running example) is a realistic need, Refine's accumulated-context approach may actually be more appropriate *if* migration ever becomes necessary, despite its latency cost — a genuine trade-off requiring evaluation against real multi-chunk-synthesis queries, not a default preference for whichever pattern is more famous.
- **Map-Rerank's narrow fit**: only worth considering for a query distribution genuinely dominated by single-fact lookups where synthesis across chunks is rare — this project's actual query patterns (Chapter 1's EDA, Chapter 7's running examples) suggest cross-referencing is common enough (the maturity-plus-nominee-exception pattern recurs throughout this project's own examples) that Map-Rerank's single-best-chunk limitation would likely be a poor fit even if scale eventually demanded a pattern change.

---

### 6. Alternatives and When to Use Each

- **Stuff (this project's correct current choice)**: use whenever retrieved content comfortably fits the model's context window with budget to spare — true for this project's 17-page knowledge base against a 200K token window by a wide margin.
- **Map-Reduce**: use when retrieved content volume genuinely and persistently exceeds context window capacity, and questions are more likely to be answerable from individual chunks independently (less cross-chunk synthesis needed) — appropriate for very large corpora with narrow, focused queries.
- **Refine**: use when content volume exceeds context capacity AND cross-chunk synthesis matters (later chunks need to refine/correct/extend earlier findings) — appropriate when latency is less critical than synthesis quality.
- **Map-Rerank**: use specifically when the query distribution is dominated by single-fact lookups where the correct, complete answer reliably lives in one chunk — a narrower fit than the other three patterns.

---

### 7. Common Mistakes and Production Failures

- Adopting Map-Reduce or Refine preemptively based on anticipated future scale, paying their cost and complexity overhead without evidence the simpler Stuff pattern has actually failed.
- Using Map-Rerank for a query distribution that actually requires cross-chunk synthesis, silently producing incomplete answers that only reflect whichever single chunk scored highest.
- Not replicating prompt-injection defenses consistently across every additional LLM call introduced by Map-Reduce or Refine, creating new, easy-to-overlook attack surface.
- Migrating patterns without re-validating Chapter 8's citation and faithfulness infrastructure against the new pattern's different call structure — Stuff's single-call citation mechanism (Chapter 8 Topic 2) needs rethinking for Map-Reduce's mini-answer-then-synthesis structure, since citation now needs to survive two layers of summarization rather than one direct generation step.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: What RAG chain pattern has this project been using throughout Chapters 6-8, even though it was never explicitly named until now?**
A: The Stuff pattern — retrieve top-k chunks, place all of them directly into one prompt's context, generate the answer in a single LLM call. This has been implicit in every prior chapter's implementation.

**Q: Why is Stuff the correct choice for this project's current scale?**
A: The knowledge base is only 17 pages, and after Chapter 7's retrieval, reranking, and MMR narrow results to a handful of chunks (typically top-5), the resulting context comfortably fits within `claude-haiku-4-5-20251001`'s 200K token context window with enormous headroom — Chapter 8 Topic 1's own measurements showed roughly 199,000+ tokens still available after accounting for the system prompt and reserved output. There is no volume or budget pressure that would justify the added cost and complexity of Map-Reduce, Refine, or Map-Rerank.

**Intermediate:**

**Q: What specific limitation does Map-Reduce have that makes it a poor fit for a query like "what is the penalty, and does it apply differently to nominee-initiated withdrawals?"**
A: Map-Reduce's Map step processes each chunk independently, with no visibility into what other chunks contain — if the general penalty rate is in one chunk and the nominee exception is in a different chunk, each independent Map call can only report on its own chunk's content, and the exception-to-the-general-rule relationship between them may not survive being compressed into two separate mini-answers before the Reduce step ever sees them together. This is exactly the kind of cross-chunk synthesis this project's own FD policy domain frequently requires (as shown throughout Chapter 7's running examples).

**Q: If this project's knowledge base grew substantially — say, to thousands of pages covering many financial products beyond FD — what specific signal would tell you it's time to move off Stuff?**
A: Chapter 8 Topic 1's chunk-drop-event logging would show a persistent, non-trivial rate of retrieved chunks being dropped due to token budget exhaustion — that's the concrete, measured evidence needed, rather than migrating preemptively based on the corpus size alone. Corpus size is a proxy; actual budget pressure, measured directly, is the real trigger, following the same evidence-based principle Chapter 6 Topic 10 established for justifying infrastructure migrations generally.

**Advanced:**

**Q: Design the citation mechanism (Chapter 8 Topic 2) for a Map-Reduce pattern, given that Stuff's single-call citation approach assumed one direct generation step with full visibility into all sources.**
A: Each Map step must produce its own source-tagged mini-answer, tracking which specific chunk it was generated from — trivial since each Map call only ever sees one chunk, so its citation is unambiguous. The harder problem is the Reduce step: when synthesizing multiple mini-answers into a final answer, the Reduce call needs to preserve which final claims trace back to which original mini-answer (and therefore which original chunk) — this requires passing the mini-answers into the Reduce prompt with their source tags still attached, and extending the citation schema so the Reduce step's structured output (mirroring Chapter 8 Topic 2's `finalize_answer_with_citations` tool) can attribute claims through two layers of synthesis rather than one, being explicit that citation fidelity may degrade slightly with each additional synthesis layer — worth validating this degradation empirically rather than assuming it's negligible.

**Q: A teammate proposes using Map-Rerank specifically for this project's exact-FD-reference-number lookup use case, since each customer's answer genuinely comes from one specific record. Evaluate this proposal.**
A: This conflates two different things — Map-Rerank is a RAG generation pattern for combining multiple *semantically retrieved* candidate chunks, while exact FD reference number lookups are already correctly handled by `validate_fd_reference`'s deterministic, exact-match database lookup (Chapter 3, reinforced by Chapter 6 Topic 9 and Chapter 9 Topic 4). There's no ambiguity or multiple-candidate-chunk scenario to rerank in an exact-match lookup — introducing Map-Rerank here would be solving a problem that doesn't exist, replacing a fast, deterministic, single-record lookup with an unnecessarily complex multi-call LLM pattern. Map-Rerank remains relevant only for genuine *semantic* retrieval scenarios with several imperfectly-ranked, ambiguous candidates, which is not what exact-reference lookups are.

**Scenario-based:**

**Q: This project's knowledge base has grown from 17 pages to 500 pages covering FD, loans, and insurance products. Retrieval now regularly returns 30+ highly relevant chunks per query, still within the 200K token budget in raw terms, but the generated answers have become noticeably less focused, sometimes trying to address every retrieved chunk's content even when only 2-3 chunks are truly relevant to the specific question asked. Diagnose and propose a fix.**
A: This isn't actually a Stuff-vs-alternative-pattern problem — the content still fits the budget, so this isn't a chunk-drop scenario requiring Map-Reduce or Refine. This is a symptom of Chapter 7's reranking and MMR (Topics 7 and 6) not narrowing the candidate pool aggressively enough for the new, larger corpus — 30+ chunks reaching the generation prompt likely means the reranking/MMR cutoff (`top_k`) needs re-tuning against Chapter 7 Topic 9's evaluation methodology for this new, larger corpus, since what was an appropriate `top_k` for a 17-page knowledge base may be too permissive for a 500-page one where more chunks pass an initial relevance threshold. The fix is likely tightening `top_k` and/or the reranking score threshold before generation, not changing the RAG chain pattern itself — Stuff remains correct here; the actual problem is one layer upstream in retrieval configuration.

---

### 9. Hidden Concepts and Prerequisites

- **These four patterns originate from classical document summarization research**, predating modern RAG — "map-reduce" and "refine" specifically borrow their names and structure from earlier multi-document summarization techniques, later adapted directly into RAG frameworks (e.g. LangChain's chain abstractions) once retrieval-augmented generation became common; worth knowing this lineage since it clarifies these aren't RAG-specific inventions but general strategies for combining information across multiple sources under context constraints.
- **The trade-off these patterns navigate — parallelizable-but-context-blind (Map-Reduce) versus sequential-but-context-aware (Refine) — is a recurring theme in distributed and incremental computation generally**, not unique to LLM applications; recognizing this as an instance of a broader computational trade-off (rather than a bespoke LLM concept) is a hallmark of transferable systems thinking valuable in a Lead-level interview.
- **This topic connects directly to Chapter 8 Topic 1's token budgeting as the actual trigger mechanism** — the decision to migrate off Stuff should always be driven by that chapter's chunk-drop monitoring data, making Topics 1 (Chapter 8) and 5 (this chapter) two halves of the same underlying architectural decision, split across chapters only for pedagogical clarity.

---

### 10. Revision Summary

> This project has used the Stuff pattern throughout Chapters 6-8 without naming it — retrieve top-k chunks, place them all in one prompt, generate one answer — and this remains the correct choice given the 17-page knowledge base comfortably fitting within `claude-haiku-4-5-20251001`'s 200K token window with enormous headroom (per Chapter 8 Topic 1's measurements). Map-Reduce (parallel independent mini-answers, then synthesized) scales to arbitrarily large retrieved volume but loses cross-chunk reasoning and multiplies LLM call cost. Refine (sequential, accumulated-answer refinement) preserves more cross-chunk reasoning at the cost of sequential latency. Map-Rerank (pick the single best independently-generated candidate) fits only query distributions dominated by single-chunk-sufficient answers, a poor match for this project's frequent general-rule-plus-exception query pattern. Migration off Stuff should be triggered by Chapter 8 Topic 1's chunk-drop-event monitoring showing actual, measured budget pressure — never adopted preemptively based on anticipated future scale, following the evidence-before-complexity discipline established throughout this project's retrieval and generation work.

---
