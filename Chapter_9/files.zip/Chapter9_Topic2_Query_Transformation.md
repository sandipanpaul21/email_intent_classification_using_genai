# Chapter 9: Retrieval — Putting It to Work

## Topic 2: Query Transformation — Rewriting/Expanding Queries for Hinglish, Short, Code-Mixed Emails

---

### 1. Concept, Intuition, and Why It Exists

- Chapter 8 Topic 7 introduced query rewriting and HyDE generally, for any RAG system. This topic is the project-specific deepening: your emails are the input to retrieval, and they are short (~31 words average), 64.4% Hinglish, and code-mixed — this is a fundamentally harder query-quality problem than a typical, well-formed English search query, and it deserves treatment beyond the general technique.
- Critically, this topic exists because **every other topic in Chapters 4-8 improved the document side of the pipeline, never the query side**. Chunking (Chapter 5) improved document granularity. Embedding, BM25, hybrid, reranking (Chapters 6-7) improved how documents are indexed and ranked. Chapter 8's citation and faithfulness work improved how retrieved content gets used. Nothing so far has directly transformed the raw, messy customer email itself before it becomes a retrieval query — and that's exactly the input this project's own data proves is weakest (Chapter 7 Topic 2's measured 0.0393 discrimination gap, Chapter 7 Topic 1's demonstrated zero-BM25-score Hinglish queries).
- The core insight: fixing the query is often cheaper and more targeted than fixing the retrieval algorithm — this project has already built excellent retrieval (BM25 + dense + hybrid + rerank + MMR), but even the best retrieval algorithm cannot recover from a query that, as raw text, bears little resemblance to how the knowledge base expresses the same idea.

---

### 2. Internal Working — Step by Step

**The specific transformation techniques, applied to this project's actual email characteristics:**

1. **Hinglish-to-English term normalization** (the most directly targeted fix, building on Chapter 7 Topic 1's diagnosis): a maintained dictionary mapping common Hinglish FD-domain terms to their English equivalents — "byaj"→"interest", "machurity"→"maturity", "nikalna"→"withdrawal", "band karna"→"close/closure", "paisa"→"amount/money". Applied before the query reaches BM25 (expanding matchable terms) and optionally before dense embedding (though dense retrieval's multilingual model already handles some of this natively, per Chapter 7 Topic 2).
2. **Short-query expansion**: this project's ~31-word average email is already short by general standards, but a genuinely terse fragment like "FD paisa nahi mila" (5 words) benefits from expansion with likely-intended context terms — a similar mechanism to synonym expansion but targeted at *sparse* queries specifically, where there simply isn't enough signal for BM25's term-frequency approach to work well regardless of vocabulary matching.
3. **Removing conversational/non-substantive filler before embedding**: customer emails often open with greetings, sign-offs, and relationship-establishing phrases ("Sir ji, hope you are well, myself Rajesh...") that carry no retrieval signal and dilute the embedding — stripping this filler concentrates the embedding vector on the actual informational content.
4. **Code-mixing normalization**: beyond simple Hinglish word substitution, code-mixed sentences (grammatically mixing Hindi and English structure within one sentence) can confuse both BM25 tokenization and, to a lesser extent, the multilingual dense model — a lightweight normalization pass (consistent transliteration, spacing correction) improves consistency across the corpus even before any semantic transformation happens.

---

### 3. How It Is Implemented in This Project

```python
# Extends the HINGLISH_TO_ENGLISH mapping introduced in Chapter 8 Topic 7,
# now built out as a maintained, project-specific dictionary derived from
# real term-frequency analysis (the same evidence-based approach used to
# build fd_keyword_groups.txt in Chapter 1)

FD_HINGLISH_TERM_MAP = {
    "byaj": "interest",
    "machurity": "maturity", "muchurity": "maturity",
    "nikalna": "withdrawal", "nikal": "withdraw",
    "band karna": "close closure", "band": "close",
    "paisa": "amount money", "paise": "amount money",
    "jama": "deposit",
    "naya": "new",
    "khaata": "account", "khata": "account",
}

FILLER_PATTERNS = [
    r"^(sir|maam|ma\'am|dear sir|dear team|hello|hi|good morning|good evening)[,.]?\s*",
    r"myself\s+\w+[,.]?\s*",
    r"(thanks|thank you|regards|best regards)[\s\S]*$",
]

import re

def strip_conversational_filler(text: str) -> str:
    """Removes greeting/sign-off filler that dilutes embedding signal.
    Applied BEFORE embedding, not before BM25 (BM25's IDF already
    naturally suppresses common filler words via their high document
    frequency, per Chapter 7 Topic 1 -- this step specifically helps
    the DENSE retrieval leg)."""
    cleaned = text.lower()
    for pattern in FILLER_PATTERNS:
        cleaned = re.sub(pattern, "", cleaned, flags=re.IGNORECASE)
    return cleaned.strip()


def expand_hinglish_terms(text: str, term_map: dict) -> str:
    """Expands known Hinglish terms with English equivalents.
    Applied primarily to help the BM25 leg of hybrid retrieval
    (Chapter 7 Topic 4) find exact-term matches in English policy docs."""
    words = text.lower().split()
    expanded = list(words)
    for word in words:
        mapping = term_map.get(word, "")
        for term in mapping.split():
            if term and term not in expanded:
                expanded.append(term)
    return " ".join(expanded)


def transform_query_for_retrieval(raw_email_text: str) -> dict:
    """Full transformation pipeline, producing SEPARATE query variants for
    BM25 and dense retrieval -- these two legs of Chapter 7's hybrid
    pipeline benefit from different transformations."""
    filler_stripped = strip_conversational_filler(raw_email_text)

    bm25_query = expand_hinglish_terms(filler_stripped, FD_HINGLISH_TERM_MAP)
    dense_query = filler_stripped  # multilingual embedding model handles some
                                    # Hinglish natively; expansion less critical here

    return {"bm25_query": bm25_query, "dense_query": dense_query, "original": raw_email_text}
```

- This feeds directly into Chapter 7 Topic 4's hybrid RRF function — instead of passing one raw query string to both BM25 and dense retrieval, this project's pipeline now passes the appropriately-transformed variant to each leg.

---

### 4. Real-World Issues, Edge Cases, Debugging, Monitoring, Scaling, Latency, Cost, Security, Deployment

- **Term-map maintenance is an ongoing, evidence-based process, not a one-time build**: exactly like `fd_keyword_groups.txt` in Chapter 1, `FD_HINGLISH_TERM_MAP` needs periodic review against real production query logs — new spelling variants, regional dialect differences, or emerging slang will appear over time and require additions, following the same "ambiguous rate rising" monitoring pattern established in Chapter 7 Topic 5.
- **Over-aggressive filler stripping risk**: the filler regex patterns must be validated against real emails to ensure they don't accidentally strip substantive content — e.g. "Sir, my FD..." should have "Sir," stripped but not "my FD" mistakenly caught by an overly broad pattern; this requires the same empirical validation discipline as every other regex-based text processing step in this project (Chapter 5's chunking, Chapter 1's rule engine).
- **Separate BM25/dense query variants add pipeline complexity**: maintaining two different transformed versions of the same query (rather than one universal transformation) is more code to maintain and test, but is justified by the genuinely different failure modes each retrieval leg has — conflating them into one "do everything" transformation risks over-optimizing for one leg at the expense of the other.
- **Monitoring**: track BM25 zero-score rate specifically for emails that passed through this transformation pipeline versus emails that didn't (if a gradual rollout or A/B comparison is used) — a direct, measurable signal of whether the transformation is actually reducing the vocabulary-mismatch problem Chapter 7 Topic 1 diagnosed.
- **Cost and latency**: this transformation is pure string processing (regex, dictionary lookup) with no model calls — negligible added latency and zero added API cost, making it one of the cheapest possible interventions in the entire pipeline, which is exactly why it should be tried and measured before considering costlier options like HyDE (Chapter 8 Topic 7) or fine-tuning the embedding model (Chapter 7 Topic 2).
- **Security**: no new attack surface beyond what Chapter 3's existing "treat content as data" principle already covers — transformation operates purely on text content, not on any executable or lookup-triggering logic.

---

### 5. Design Decisions, Trade-offs, and Real-Time Dilemmas

- **Rule-based term mapping vs. a learned normalization model**: a maintained dictionary (this project's approach) is transparent, auditable, and improvable incrementally with zero training cost — but requires manual curation and will always lag behind genuinely novel phrasing. A learned transliteration/normalization model (e.g. a small fine-tuned sequence model, or SPLADE's implicit learned expansion from Chapter 7 Topic 3) can generalize to unseen variants, at the cost of training data requirements and reduced interpretability. Given this project's specific, measured, dictionary-amenable problem (a bounded set of common Hinglish FD terms), the rule-based approach captures most of the value at far lower cost — the same "measure before adding complexity" principle applied throughout Chapters 7-8.
- **Universal query transformation vs. leg-specific transformation (this project's approach)**: applying one transformation to feed both BM25 and dense retrieval is simpler but risks suboptimizing for one leg — dense retrieval's multilingual model may already handle some Hinglish reasonably (per Chapter 7 Topic 2), so aggressively rewriting the dense-leg query could actually remove useful signal the model would otherwise use correctly. Splitting into two variants respects each retriever's actual strengths and weaknesses, at the cost of maintaining two pipelines instead of one.

---

### 6. Alternatives and When to Use Each

- **No query transformation (Chapters 4-7 as originally built)**: acceptable baseline, but leaves Chapter 7 Topic 1's diagnosed Hinglish vocabulary mismatch completely unaddressed at the query-formation stage.
- **Dictionary-based term expansion (this topic's primary recommendation)**: the correct first intervention given this project's specific, bounded, already-diagnosed vocabulary gap — cheap, fast, auditable, directly targeted.
- **HyDE (Chapter 8 Topic 7)**: a more general-purpose, costlier alternative or complement, worth layering on top if dictionary expansion alone proves insufficient per Chapter 7 Topic 9's evaluation methodology.
- **Fine-tuned embedding model (Chapter 7 Topic 2's forward reference)**: the most expensive, most general solution, reserved for after cheaper query-side fixes have been measured and found insufficient.

---

### 7. Common Mistakes and Production Failures

- Building a universal, leg-agnostic query transformation without recognizing that BM25 and dense retrieval benefit from different, sometimes conflicting, transformations.
- Letting the Hinglish term map go stale, missing new spelling variants or slang that emerge in real customer traffic over time.
- Over-aggressive filler stripping that accidentally removes substantive query content, silently degrading retrieval quality in a way that's hard to detect without careful evaluation-set testing.
- Assuming query transformation alone fully solves the vocabulary mismatch problem without ever measuring the actual improvement via Chapter 7 Topic 9's Recall@K/NDCG@K methodology.

---

### 8. Lead-Level Interview Questions

**Basic:**

**Q: Why does this project need query transformation specifically, beyond the general RAG query rewriting covered in Chapter 8?**
A: This project's actual corpus is 64.4% Hinglish with an average email length of only 31 words — every prior chapter's improvements (chunking, embedding, BM25, hybrid, reranking) targeted the document side of the pipeline, leaving the raw, messy customer email itself untransformed as the retrieval query. Chapter 7's own measurements (zero BM25 scores on Hinglish queries, a thin 0.0393 dense-retrieval discrimination gap) prove this is the weakest link, making query-side transformation a specifically high-value intervention for this corpus.

**Q: Why does the term mapping use separate variants for BM25 versus dense retrieval instead of one universal transformation?**
A: BM25 needs exact vocabulary overlap to score anything above zero, so expanding Hinglish terms with their English equivalents directly targets its specific weakness. Dense retrieval's multilingual embedding model already has some native ability to bridge Hinglish and English semantically, so aggressively rewriting the dense-leg query risks removing signal the model would otherwise use correctly — treating both legs identically ignores their genuinely different failure modes.

**Intermediate:**

**Q: How would you validate that the Hinglish term-mapping dictionary is actually improving retrieval, rather than assuming it based on the general problem diagnosis?**
A: Use Chapter 7 Topic 9's evaluation methodology directly — build or extend the labeled evaluation set with Hinglish queries specifically, then measure Recall@K, MRR, and NDCG@K with and without the term-expansion transformation applied. A meaningful improvement on the Hinglish subset of the evaluation set, without regression on the English subset, confirms the fix is working as intended rather than assumed.

**Q: What's the risk of the filler-stripping regex patterns being too aggressive, and how would you catch it in production?**
A: An overly broad pattern could strip substantive query content along with genuine filler, silently degrading dense retrieval's embedding quality for affected emails. This would be hard to notice from aggregate metrics alone since it might affect a minority of unusual phrasings — catching it requires either targeted evaluation-set queries specifically designed to test filler-stripping edge cases, or periodic manual review of a sample of transformed queries compared against their originals, watching for cases where meaningful content was inadvertently removed.

**Advanced:**

**Q: This project's term-mapping dictionary is maintained manually, similar to `fd_keyword_groups.txt` from Chapter 1. Design a process for keeping it current as production traffic evolves.**
A: Establish the same "ambiguous rate rising" style of monitoring used elsewhere in this project (Chapter 7 Topic 5) — but applied to retrieval quality specifically: track the BM25 zero-score rate on production queries over time, and periodically sample zero-scoring queries for manual review. Queries that fail due to a recognizable but unmapped Hinglish term (rather than genuinely novel phrasing the dictionary approach can't help with) are direct candidates for dictionary additions. This creates a feedback loop — production failures identify specific dictionary gaps, which get validated and added, then re-measured against the evaluation set (Chapter 7 Topic 9) before deployment, mirroring the exact evidence-based, iterative process used for the original keyword rule engine's development.

**Q: A teammate proposes replacing the dictionary-based approach entirely with a fine-tuned transliteration model. How do you evaluate this proposal given this project's current stage?**
A: A fine-tuned model could generalize better to novel Hinglish variants the dictionary hasn't seen, but requires labeled training data (Hinglish-English term pairs, ideally derived from this project's own corpus), training infrastructure, and ongoing retraining as the domain vocabulary evolves — meaningfully higher cost and complexity than a maintained dictionary. Given the problem is currently well-bounded (a manageable, if evolving, set of common FD-domain Hinglish terms) and the dictionary approach is cheap to build and iterate on, I'd only pursue the fine-tuned alternative after measuring that the dictionary approach has a persistent, quantified gap the dictionary's incremental maintenance can't keep up with — following the same measure-before-adding-complexity discipline used throughout this project's retrieval work.

**Scenario-based:**

**Q: After deploying query transformation, Chapter 7 Topic 9's evaluation shows improved Recall@K for Hinglish queries but no change for a subset of "code-switched" queries that mix Hindi and English mid-sentence in unusual grammatical patterns. Diagnose.**
A: This suggests the term-mapping dictionary is correctly catching known Hinglish vocabulary but isn't addressing the structural code-mixing problem separately flagged in this topic's internal-working section — grammatically mixed sentences can confuse tokenization and dilute embedding signal in ways that simple word-for-word substitution doesn't fix. The next step is sampling these specific failing queries, checking whether the issue is tokenization-level (BM25's `.lower().split()` producing malformed tokens from irregular code-mixed spacing or punctuation) or genuinely semantic (the dense model struggling with the specific grammatical mixing pattern) — the fix differs depending on which: a tokenization-level issue is a cheap preprocessing fix, while a genuine semantic struggle may require the more expensive interventions (HyDE, fine-tuning) already discussed as escalation paths.

---

### 9. Hidden Concepts and Prerequisites

- **This topic is a concrete instance of "text normalization" as a classical NLP preprocessing step** — predating embeddings and LLMs entirely, text normalization (case folding, filler removal, synonym mapping) has always been part of information retrieval pipelines; this project's Hinglish-specific version is a domain-adapted instance of a much older, general technique.
- **Query transformation and Chapter 8 Topic 6's multi-turn contextualization are related but distinct problems**: both transform a query before retrieval, but Topic 6 addresses missing *conversational* context (a follow-up referencing an earlier turn), while this topic addresses *linguistic* quality problems (vocabulary mismatch, filler, code-mixing) present even in a single, self-contained turn — a system may need both transformations applied in sequence for a multi-turn Hinglish conversation.
- **The dictionary-based approach here directly parallels SPLADE's learned vocabulary expansion (Chapter 7 Topic 3)** — both solve the same underlying vocabulary-bridging problem, one via manual curation, the other via a trained model's implicit learned associations; understanding this parallel clarifies why SPLADE was flagged in Chapter 7 as a natural, more automated evolution of exactly this project-specific manual dictionary work.

---

### 10. Revision Summary

> Query transformation, general in Chapter 8 Topic 7, is deepened here into this project's specific, measured problem: 64.4% Hinglish, 31-word-average, code-mixed customer emails as retrieval queries — the one part of the pipeline every prior chapter left untouched while improving the document side extensively. The concrete techniques are Hinglish-to-English term expansion (targeting BM25's exact-match weakness, per Chapter 7 Topic 1's diagnosis), conversational filler stripping (concentrating dense retrieval's embedding signal), and separate query variants for the BM25 and dense legs of Chapter 7's hybrid pipeline, since each leg has genuinely different vocabulary-handling characteristics. This is a cheap, fast, auditable, dictionary-based intervention that should be measured against Chapter 7 Topic 9's evaluation methodology before considering costlier alternatives like HyDE or embedding model fine-tuning — and like the original keyword rule engine (Chapter 1), the term-mapping dictionary requires ongoing, evidence-based maintenance as production query patterns evolve.

---
